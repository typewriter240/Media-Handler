param([switch]$Nginx)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$python = Start-Process python -ArgumentList (Join-Path $Root 'server.py') -WorkingDirectory $Root -PassThru
$python.Id | Set-Content -LiteralPath (Join-Path $Root 'data\state\python-server.pid')
if ($Nginx) {
    $nginx = Get-ChildItem -LiteralPath $Root -Filter nginx.exe -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $nginx) {
        $nginx = Get-Command nginx -ErrorAction SilentlyContinue
    }
    if (-not $nginx) {
        Write-Warning "Nginx was not found."
        Write-Host "Install with Windows Package Manager:"
        Write-Host "  winget install --id=NGINX.NGINX -e"
        Write-Host "Or with Chocolatey (Administrator PowerShell):"
        Write-Host "  choco install nginx -y"
        throw "Nginx is required when -Nginx is specified."
    }
    $nginxPath = if ($nginx.PSObject.Properties.Name -contains 'FullName') { $nginx.FullName } else { $nginx.Source }
    $nginxDirectory = Split-Path $nginxPath -Parent
    $process = Start-Process $nginxPath -ArgumentList '-c', (Join-Path $Root 'config\nginx-video-retriever.conf') -WorkingDirectory $nginxDirectory -PassThru
    $process.Id | Set-Content -LiteralPath (Join-Path $Root 'data\state\nginx.pid')
}
Write-Host "Services started."
