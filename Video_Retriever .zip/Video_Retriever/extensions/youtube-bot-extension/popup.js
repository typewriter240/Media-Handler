const API_BASES = [
  window.location.protocol.startsWith('http') ? `${window.location.origin}/api` : null,
  'http://127.0.0.1:5000/api',
  'http://localhost:5000/api',
  'http://127.0.0.1:8000/api',
  'http://localhost:8000/api'
].filter(Boolean);

document.addEventListener('DOMContentLoaded', async () => {
  const connected = await checkBotConnection();
  
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const url = tabs[0].url;
  
  if (isYouTubeUrl(url)) {
    const videoId = extractVideoId(url);
    if (videoId) {
      loadVideoInfo(videoId, url);
    }
  }
  
  // Enhanced button behavior: split button and menu
  const downloadBtn = document.getElementById('downloadBtn');
  const downloadMenuBtn = document.getElementById('downloadMenuBtn');
  const downloadMenu = document.getElementById('downloadMenu');

  // Main click: default to queue download
  downloadBtn.addEventListener('click', () => startDownload({ action: 'queue', use_browser_cookies: false }));
  // Toggle menu
  downloadMenuBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    const expanded = downloadMenu.classList.toggle('show');
    downloadMenuBtn.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    downloadMenu.setAttribute('aria-hidden', expanded ? 'false' : 'true');
  });

  // Menu item handlers
  downloadMenu.addEventListener('click', (e) => {
    const btn = e.target.closest('.menu-item');
    if (!btn) return;
    const action = btn.getAttribute('data-action');
    if (action === 'queue') startDownload({ action: 'queue', use_browser_cookies: false });
    if (action === 'inspect') startDownload({ action: 'inspect', use_browser_cookies: false });
    if (action === 'use_cookies') startDownload({ action: 'queue', use_browser_cookies: true });
    // close menu
    downloadMenu.classList.remove('show');
    downloadMenuBtn.setAttribute('aria-expanded', 'false');
    downloadMenu.setAttribute('aria-hidden', 'true');
  });

  // Close menu if clicking outside
  document.addEventListener('click', () => {
    downloadMenu.classList.remove('show');
    downloadMenuBtn.setAttribute('aria-expanded', 'false');
    downloadMenu.setAttribute('aria-hidden', 'true');
  });

  document.getElementById('refreshBtn').addEventListener('click', () => location.reload());

  // Fetch server presets (quality/format) and populate selects. If presets aren't available, keep defaults.
  (async function populatePresets(){
    try{
      const res = await tryApiFetch('/presets', { method: 'GET' });
      if(res && res.response && res.response.ok){
        const data = await res.response.json();
        if(data && (data.qualities || data.formats || data.format_map)){
          const qualitySelect = document.getElementById('quality');
          const formatSelect = document.getElementById('format');
          // Populate qualities
          if(Array.isArray(data.qualities) && data.qualities.length){
            qualitySelect.innerHTML = '';
            data.qualities.forEach(q=>{
              const opt = document.createElement('option'); opt.value = (typeof q === 'object' ? (q.value || q.key || q) : q); opt.textContent = (typeof q === 'object' ? (q.label || q.value || q.key || q) : q);
              qualitySelect.appendChild(opt);
            });
          }
          // Populate formats: prefer explicit 'formats' array, else derive from format_map object
          if(Array.isArray(data.formats) && data.formats.length){
            formatSelect.innerHTML = '';
            data.formats.forEach(f=>{
              const opt = document.createElement('option'); opt.value = (typeof f === 'object' ? (f.value || f.key || f) : f); opt.textContent = (typeof f === 'object' ? (f.label || f.value || f.key || f) : f);
              formatSelect.appendChild(opt);
            });
          } else if (data.format_map && typeof data.format_map === 'object'){
            formatSelect.innerHTML = '';
            // format_map is expected to be an object mapping keys to descriptions
            Object.keys(data.format_map).forEach(k=>{
              const v = data.format_map[k];
              const opt = document.createElement('option'); opt.value = k; opt.textContent = (v && v.label) ? v.label : (typeof v === 'string' ? v : k);
              formatSelect.appendChild(opt);
            });
          }
        }
      }
    }catch(err){
      // Ignore preset fetch errors; keep defaults
      console.debug('Presets not available:', err);
    }
  })();

  // Attach ripple effect to buttons for nicer click feedback
  attachButtonRipples();
});

function buildPathCandidates(path) {
  const normalized = path.startsWith('/') ? path : `/${path}`;
  const candidates = [normalized];
  if (normalized.startsWith('/api/')) {
    candidates.push(normalized.replace(/^\/api/, ''));
  } else if (normalized === '/api') {
    candidates.push('');
  } else {
    candidates.push(`/api${normalized}`);
  }
  return [...new Set(candidates)];
}

async function tryApiFetch(path, options = {}) {
  let lastError = null;
  for (const base of API_BASES) {
    for (const candidate of buildPathCandidates(path)) {
      const url = base.replace(/\/$/, '') + candidate;
      try {
        const response = await fetch(url, options);
        if (!response.ok) {
          const error = new Error(`HTTP ${response.status} from ${url}`);
          error.response = response;
          lastError = error;
          continue;
        }
        return { response, url };
      } catch (error) {
        lastError = error;
      }
    }
  }
  throw lastError || new Error('Unable to reach local API');
}

function isYouTubeUrl(url) {
  return url.includes('youtube.com') || url.includes('youtu.be') || url.includes('music.youtube.com');
}

function extractVideoId(url) {
  const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/);
  return match ? match[1] : null;
}

function showStatus(message, type) {
  const statusEl = document.getElementById('statusMessage');
  statusEl.textContent = message;
  statusEl.className = `status-message show ${type}`;
  
  if (type !== 'info') {
    setTimeout(() => {
      statusEl.classList.remove('show');
    }, 4000);
  }
}

async function checkBotConnection() {
  const statusEl = document.getElementById('status');
  const statusIndicator = statusEl.querySelector('.status-indicator');
  
  try {
    const { response } = await tryApiFetch('/stats', { method: 'GET' });
    if (response.ok) {
      statusEl.innerHTML = '<span class="status-indicator online"></span><span>✓ Bot Connected</span>';
      statusEl.style.color = '#10b981';
      document.getElementById('downloadBtn').disabled = false;
      return true;
    }
  } catch (error) {
    console.log('Bot connection error:', error);
  }
  
  statusEl.innerHTML = '<span class="status-indicator offline"></span><span>✗ Bot Offline</span>';
  statusEl.style.color = '#ef4444';
  document.getElementById('downloadBtn').disabled = true;
  document.getElementById('downloadBtn').textContent = '⚠️ Bot Offline';
  return false;
}

async function loadVideoInfo(videoId, url) {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const title = tabs[0].title.replace(' - YouTube', '').trim();
  const urlEl = document.getElementById('videoUrl');
  urlEl.textContent = url.substring(0, 50) + (url.length > 50 ? '...' : '');
  urlEl.dataset.fullUrl = url;
  document.getElementById('videoTitle').textContent = title || 'YouTube Video';
}

async function startDownload(opts = { action: 'queue', use_browser_cookies: false }) {
  const url = document.getElementById('videoUrl').textContent;
  const quality = document.getElementById('quality').value;
  const format = document.getElementById('format').value;
  const subtitles = document.getElementById('subtitles').checked;
  
  if (!url || url.includes('Loading')) {
    showStatus('❌ Could not detect video URL', 'error');
    return;
  }

  const downloadBtn = document.getElementById('downloadBtn');

  // Prepare UI
  if (opts.action === 'inspect') {
    downloadBtn.disabled = true;
    downloadBtn.textContent = '🔍 Inspecting...';
  } else {
    downloadBtn.disabled = true;
    downloadBtn.textContent = '⏳ Downloading...';
  }
  
  try {
    // Use stored full video URL to avoid truncation or active-tab mismatches.
    const urlEl = document.getElementById('videoUrl');
    const fullUrl = urlEl.dataset.fullUrl || urlEl.textContent;

    if (opts.action === 'inspect') {
      // Call inspect endpoint synchronously for quick metadata (server may fallback to background job)
      const inspectUrl = `/api/video/inspect?url=${encodeURIComponent(fullUrl)}&sync=true`;
      const { response } = await tryApiFetch(inspectUrl, { method: 'GET' });
      const data = await response.json();
      showStatus('🔎 Inspect complete — check dashboard for details.', 'success');
      downloadBtn.textContent = '⬇️ Download';
      downloadBtn.disabled = false;
      return;
    }

    // Queue/download action
    const body = {
      url: fullUrl,
      quality: quality,
      format: format,
      subtitles: subtitles ? 'auto' : 'none',
      subtitle_language: 'en'
    };
    if (opts.use_browser_cookies) body.use_browser_cookies = true;

    const { response } = await tryApiFetch('/download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    
    if (response.status === 202) {
      const result = await response.json();
      showStatus('✅ Download queued! Check your dashboard for progress.', 'success');
      downloadBtn.textContent = '✓ Queued!';
        
      setTimeout(() => {
        downloadBtn.textContent = '⬇️ Download';
        downloadBtn.disabled = false;
      }, 2500);
    } else if (response.status === 400) {
      const error = await response.json();
      showStatus(`❌ Invalid URL: ${error.error || 'Bad request'}`, 'error');
      downloadBtn.textContent = '⬇️ Download';
      downloadBtn.disabled = false;
    } else {
      showStatus('❌ Server error. Try again later.', 'error');
      downloadBtn.textContent = '⬇️ Download';
      downloadBtn.disabled = false;
    }
  } catch (error) {
    console.error('Download error:', error);
    if (error && error.response) {
      try {
        const body = await error.response.json();
        showStatus(`❌ ${body.error || body.message || 'Server error'}`, 'error');
      } catch {
        showStatus(`❌ Connection failed: ${error.message}`, 'error');
      }
    } else {
      showStatus(`❌ Connection failed: ${error.message}`, 'error');
    }
    downloadBtn.textContent = '⬇️ Download';
    downloadBtn.disabled = false;
  }
}

// Simple ripple effect for button feedback
function attachButtonRipples() {
  const buttons = document.querySelectorAll('button');
  buttons.forEach(btn => {
    btn.classList.add('btn-ripple');
    btn.addEventListener('pointerdown', function (e) {
      const rect = this.getBoundingClientRect();
      const ripple = document.createElement('span');
      ripple.className = 'ripple';
      const size = Math.max(rect.width, rect.height) * 0.8;
      ripple.style.width = ripple.style.height = size + 'px';
      ripple.style.left = (e.clientX - rect.left - size / 2) + 'px';
      ripple.style.top = (e.clientY - rect.top - size / 2) + 'px';
      this.appendChild(ripple);
      setTimeout(() => ripple.remove(), 700);
    });
  });
}
