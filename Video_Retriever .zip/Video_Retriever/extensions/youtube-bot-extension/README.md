# YouTube Bot extension

This Manifest V3 extension adds one-click YouTube download and inspection
actions. It communicates with the local Video Retriever API on ports 5000 or
8000.

## Installation

1. Start `server.py`.
2. Open the browser's extensions page.
3. Enable developer mode.
4. Select **Load unpacked**.
5. Choose this directory.

The extension requires access to YouTube and localhost. It does not store
Spotify credentials, YouTube API keys, or server passwords.

## Development

- `background.js` handles API communication and health checks.
- `content.js` reads the active YouTube page.
- `popup.html` and `popup.js` provide the user interface.
- `manifest.json` defines permissions and the service worker.

Reload the extension after editing source files. Keep new permissions limited
to the feature being implemented.

