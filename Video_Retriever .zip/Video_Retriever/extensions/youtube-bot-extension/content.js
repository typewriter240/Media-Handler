console.log('YouTube Bot extension loaded on this page');

// Optional: Inject download button on video pages
function injectDownloadButton() {
  if (document.getElementById('yt-bot-download-btn')) return;
  
  // Wait for YouTube's button container
  const buttonContainer = document.querySelector('.yt-spec-button-shape-next');
  
  if (buttonContainer) {
    // This would inject a button - optional feature
    // For now, users use the popup instead
  }
}

// Run when page loads
window.addEventListener('load', injectDownloadButton);

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getPageInfo') {
    sendResponse({
      url: window.location.href,
      title: document.title
    });
  }
});