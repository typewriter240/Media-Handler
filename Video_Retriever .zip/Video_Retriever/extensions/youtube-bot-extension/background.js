// Service Worker for background tasks
// Handles communication with the Bot API using a resilient multi-base approach

const API_BASES = [
  'http://127.0.0.1:5000/api',
  'http://localhost:5000/api',
  'http://127.0.0.1:8000/api',
  'http://localhost:8000/api'
];

function buildUrl(base, path) {
  const b = base.replace(/\/$/, '');
  return b + path;
}

function buildPathCandidates(path) {
  const normalized = path.startsWith('/') ? path : `/${path}`;
  const candidates = [normalized];
  if (normalized.startsWith('/api/')) {
    candidates.push(normalized.replace(/^\/api/, ''));
  } else if (normalized === '/api') {
    candidates.push('');
  } else {
    candidates.push(`/api${normalized}`);
  }
  return [...new Set(candidates)];
}

async function tryApiFetch(path, options = {}) {
  let lastError = null;
  for (const base of API_BASES) {
    for (const candidate of buildPathCandidates(path)) {
      const url = buildUrl(base, candidate);
      try {
        const resp = await fetch(url, options);
        if (!resp.ok) {
          const err = new Error(`HTTP ${resp.status} from ${url}`);
          err.response = resp;
          lastError = err;
          continue;
        }
        return { response: resp, url };
      } catch (err) {
        lastError = err;
      }
    }
  }
  throw lastError || new Error('Unable to reach local API');
}

// Listen for messages from popup or content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'download') {
    handleDownload(request.data, sendResponse);
    return true; // Keep channel open for async response
  }
  if (request.action === 'inspect') {
    handleInspect(request.data, sendResponse);
    return true;
  }
});

async function handleDownload(data, sendResponse) {
  try {
    const { response, url } = await tryApiFetch('/download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const result = await response.json().catch(() => ({}));
    sendResponse({ success: true, data: result, url });
  } catch (error) {
    const message = (error && error.message) ? error.message : 'Unknown error';
    sendResponse({ success: false, error: message });
  }
}

async function handleInspect(data, sendResponse) {
  try {
    const fullUrl = data && data.url ? data.url : '';
    const inspectPath = `/video/inspect?url=${encodeURIComponent(fullUrl)}&sync=true`;
    const { response } = await tryApiFetch('/' + inspectPath.replace(/^\//, ''), { method: 'GET' });
    const result = await response.json().catch(() => ({}));
    sendResponse({ success: true, data: result });
  } catch (error) {
    sendResponse({ success: false, error: error.message });
  }
}

// Optional: Check bot connection periodically and cache state
setInterval(checkBotHealth, 30000);

async function checkBotHealth() {
  try {
    await tryApiFetch('/stats', { method: 'GET' });
    chrome.storage.local.set({ botOnline: true });
  } catch (error) {
    chrome.storage.local.set({ botOnline: false });
  }
}