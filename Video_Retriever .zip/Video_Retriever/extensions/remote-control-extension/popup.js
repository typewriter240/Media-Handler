const bases = [
  'http://127.0.0.1:5000/api',
  'http://localhost:5000/api',
  'http://127.0.0.1:8000/api',
  'http://localhost:8000/api'
];

async function send(action, videoId) {
  let lastError;
  for (const base of bases) {
    try {
      const response = await fetch(`${base}/download/${action}`, {
        method: 'POST',
        credentials: 'include',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({video_id: videoId})
      });
      if (response.ok) return response.json();
      lastError = new Error(`HTTP ${response.status}`);
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError || new Error('Video Retriever is unreachable');
}

for (const button of document.querySelectorAll('button[data-action]')) {
  button.addEventListener('click', async () => {
    const videoId = document.querySelector('#video-id').value.trim();
    const status = document.querySelector('#status');
    if (!videoId) {
      status.textContent = 'Enter a video ID.';
      return;
    }
    try {
      await send(button.dataset.action, videoId);
      status.textContent = `${button.dataset.action} requested.`;
    } catch (error) {
      status.textContent = error.message;
    }
  });
}
