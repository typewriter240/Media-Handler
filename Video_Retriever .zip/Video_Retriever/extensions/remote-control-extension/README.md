# Remote Control extension

Load this directory as an unpacked Manifest V3 extension. It controls
authenticated downloads through `/api/download/pause`, `/resume`, and
`/cancel`. The Python server must be running and the browser must have an
active Video Retriever session cookie.

