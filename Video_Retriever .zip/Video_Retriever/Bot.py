import os
import sys
import json
import html
import threading
import yt_dlp
import pyperclip
import hashlib
import stat
import urllib.request
import platform
import socket
import shutil
import subprocess
from pathlib import Path
from urllib.parse import quote

try:
    import server as server_module
except Exception:
    server_module = None

try:
    import Proxy_interpreter as proxy_module
except Exception:
    proxy_module = None
from typing import List, Dict, Optional, Tuple
import requests
from urllib.parse import urlparse as _urlparse, parse_qs as _parse_qs
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
try:
    import psutil
except ImportError:
    psutil = None

# Keep this metadata in the script so a copied or moved checkout can be
# distinguished from the directory where this script was originally created.
# Update the value when intentionally distributing a new copy of the project.
PYTHON_FILE_METADATA = {
    'metadata_version': 1,
    'original_absolute_directory': '',
}

PROGRESS_FILE_LOCK = threading.Lock()
PROGRESS_MAX_AGE_SECONDS = 3600
PROGRESS_TERMINAL_MAX_AGE_SECONDS = 300

# Color codes for terminal output
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

# Configuration defaults
DEFAULT_CONFIG = {
    'output_directory': './downloads/Single Videos',
    'downloads_directory': './downloads',
    'spotify_output_directory': './downloads/Spotify',
    'download_pages_directory': './download_pages',
    'thumbnails_directory': './downloads/Single Videos/thumbnails',
    'logs_directory': './logs',
    'nginx_temp_directory': './temp',
    'sql_directory': './data/sql',
    'web_directory': './web',
    'favicon_directory': './web/assets',
    'config_directory': './config',
    'failed_downloads_directory': './data/failed',
    'history_directory': './data/history',
    'state_directory': './data/state',
    'cache_directory': './data/cache',
    'modules_directory': './modules',
    'scripts_directory': './scripts',
    'docs_directory': './docs',
    'extensions_directory': './extensions',
    'quality_preference': 'best',
    'spotify_audio_quality': '320k',
    'enable_proxy_ui': False,
    'proxy_host': '127.0.0.1',
    'proxy_port': 8080,
    'proxy_ui_port': 8081,
    'concurrent_threads': 3,
    'bandwidth_limit_kbps': 0,
    'adaptive_bandwidth_enabled': True,
    'adaptive_bandwidth_throttle_percent': 75,
    'adaptive_bandwidth_critical_percent': 95,
    'adaptive_bandwidth_ceiling_kbps': 10240,
    'smart_quality_selection': True,
    'storage_warning_percent': 10,
    'auto_cleanup_days': 0,
    'auto_skip_duplicates': True,
    'enable_history': True,
    'subtitle_language': 'en',
    'log_level': 'info',
    'enable_thumbnails': True,
    'embed_chapters': True,
    'use_browser_cookies': False,
    'browser_cookies_from': None,
    'cookie_file': None,
    'youtube_api_key': '',
    'spotify_client_id': '',
    'spotify_client_secret': '',
    'ui_theme': 'dark',
    'ui_theme_preset': 'classic',
    'ui_primary_color': '#ff304f',
    'ui_secondary_color': '#6ea8fe',
    'ui_background_color': '#17191d',
    'ui_surface_color': '#202328',
    'ui_text_color': '#f3f5f8',
    'enable_notifications': True,
    'enable_privacy_mode': False,
    'use_proxy': True,
    'proxy_url': '',
    'min_duration': 0,
    'max_duration': 0,
    'min_date': '',
    'min_views': 0
}

LOCKOFF_MODE = False
LOCKOFF_MESSAGE = 'System lock-off active: boot anchor missing or tampered.'
LOCKOFF_REASON = ''
COMPLETE_LOCKOFF_MODE = False
LOCKOFF_STATE_REESTABLISHED = False
RELOCATION_DETECTED = False


def hide_security_path(path: Path) -> None:
    """Mark security storage hidden/system on Windows without changing its path."""
    if os.name != 'nt' or not path.exists():
        return
    try:
        import ctypes

        FILE_ATTRIBUTE_HIDDEN = 0x2
        FILE_ATTRIBUTE_SYSTEM = 0x4
        if not ctypes.windll.kernel32.SetFileAttributesW(
            str(path), FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM
        ):
            raise OSError(ctypes.get_last_error(), 'SetFileAttributesW failed')
    except (OSError, AttributeError):
        print(f'{Colors.WARNING}Unable to hide security path: {path}{Colors.ENDC}')


def write_security_file(path: Path, content: str) -> bool:
    """Replace a security file when possible without bypassing filesystem permissions."""
    temporary_path = path.with_name(f'.{path.name}.new')
    try:
        if path.exists():
            path.chmod(path.stat().st_mode | stat.S_IWRITE)
        temporary_path.write_text(content, encoding='utf-8')
        temporary_path.replace(path)
        hide_security_path(path)
        return True
    except OSError as exc:
        try:
            if temporary_path.exists():
                temporary_path.unlink()
        except OSError:
            pass
        print(
            f'{Colors.FAIL}Security anchor could not be updated: {exc}. '
            f'Recovery will continue with lockoff enabled.{Colors.ENDC}'
        )
        return False


def compute_boot_anchor_payload() -> Dict[str, str]:
    """Create an anchor payload from the stable workspace contents."""
    root = Path(__file__).resolve().parent.resolve()
    metadata_version = str(PYTHON_FILE_METADATA['metadata_version'])
    host_identity = compute_host_identity()
    workspace_fingerprint = compute_workspace_fingerprint(root, host_identity)
    signature_source = (
        f"{root.as_posix()}|{host_identity}|"
        f"{workspace_fingerprint}|{metadata_version}"
    )
    return {
        'workspace_root': str(root),
        'signature': hashlib.sha512(signature_source.encode('utf-8')).hexdigest(),
        'hash_algorithm': 'sha512-v2',
        'metadata_version': metadata_version,
        'host_identity': host_identity,
        'workspace_fingerprint': workspace_fingerprint,
    }


WORKSPACE_FINGERPRINT_EXCLUSIONS = frozenset({
    '.security',
    'data',
    'downloads',
    'download_pages',
    'logs',
    'temp',
    '__pycache__',
})


def compute_host_identity() -> str:
    """Return a stable normalized hostname marker for the current machine."""
    return socket.gethostname().strip().casefold()


def compute_workspace_fingerprint(workspace_root: Path, host_identity: str) -> str:
    """Hash stable workspace files while ignoring mutable runtime/download data."""
    digest = hashlib.sha512()
    digest.update(f'host:{host_identity}\0'.encode('utf-8'))
    files = []
    for path in workspace_root.rglob('*'):
        if not path.is_file():
            continue
        relative = path.relative_to(workspace_root)
        if any(part in WORKSPACE_FINGERPRINT_EXCLUSIONS for part in relative.parts):
            continue
        files.append(relative)
    for relative in sorted(files, key=lambda item: item.as_posix().casefold()):
        path = workspace_root / relative
        digest.update(relative.as_posix().encode('utf-8'))
        digest.update(b'\0')
        digest.update(path.read_bytes())
        digest.update(b'\0')
    return digest.hexdigest()


def compute_anchor_signature(workspace_root: str, metadata_version: str) -> str:
    root = Path(workspace_root).resolve()
    host_identity = compute_host_identity()
    workspace_fingerprint = compute_workspace_fingerprint(root, host_identity)
    signature_source = (
        f"{root.as_posix()}|{host_identity}|"
        f"{workspace_fingerprint}|{metadata_version}"
    )
    return hashlib.sha512(signature_source.encode('utf-8')).hexdigest()


def compute_stored_anchor_signature(
    workspace_root: str,
    host_identity: str,
    workspace_fingerprint: str,
    metadata_version: str,
) -> str:
    """Validate a copied anchor using its recorded route and content hash."""
    signature_source = (
        f"{Path(workspace_root).resolve().as_posix()}|{host_identity}|"
        f"{workspace_fingerprint}|{metadata_version}"
    )
    return hashlib.sha512(signature_source.encode('utf-8')).hexdigest()


def compute_legacy_anchor_signature(workspace_root: str, metadata_version: str) -> str:
    signature_source = (
        f"{Path(workspace_root).resolve().as_posix()}|"
        f"{hashlib.sha256(str(Path(workspace_root).resolve()).encode('utf-8')).hexdigest()}|"
        f"{metadata_version}"
    )
    return hashlib.sha256(signature_source.encode('utf-8')).hexdigest()


def compute_path_anchor_signature(workspace_root: str, metadata_version: str) -> str:
    """Validate the immediately previous SHA-512 path-based anchor format."""
    signature_source = f"{Path(workspace_root).resolve().as_posix()}|{metadata_version}"
    return hashlib.sha512(signature_source.encode('utf-8')).hexdigest()


def ensure_boot_anchor() -> bool:
    """Create or migrate the anchor, while locking on invalid security data."""
    global LOCKOFF_MODE, LOCKOFF_REASON, COMPLETE_LOCKOFF_MODE, RELOCATION_DETECTED
    workspace = Path(__file__).resolve().parent.resolve()
    anchor_dir = workspace / '.security'
    anchor_dir.mkdir(parents=True, exist_ok=True)
    anchor_path = anchor_dir / '.boot-anchor.json'
    hide_security_path(anchor_dir)
    expected = compute_boot_anchor_payload()
    if not anchor_path.exists():
        if not write_security_file(anchor_path, json.dumps(expected, indent=2)):
            LOCKOFF_MODE = True
            COMPLETE_LOCKOFF_MODE = True
            LOCKOFF_REASON = 'Boot anchor could not be created or secured.'
            return False
        LOCKOFF_MODE = False
        COMPLETE_LOCKOFF_MODE = False
        LOCKOFF_REASON = ''
        return True
    try:
        existing = json.loads(anchor_path.read_text(encoding='utf-8'))
        existing_root = str(existing['workspace_root'])
        existing_version = str(existing['metadata_version'])
        existing_host = str(existing['host_identity'])
        existing_fingerprint = str(existing['workspace_fingerprint'])
        valid_version = existing_version == str(PYTHON_FILE_METADATA['metadata_version'])
        valid_existing = valid_version and (
            existing.get('hash_algorithm') == 'sha512-v2'
            and existing_host == compute_host_identity()
            and existing.get('signature') == compute_stored_anchor_signature(
                existing_root,
                existing_host,
                existing_fingerprint,
                existing_version,
            )
        )
    except (OSError, KeyError, TypeError, ValueError):
        valid_existing = False
    allowed_security_files = {anchor_path.name, '.config-integrity.json'}
    unexpected_security_files = {
        path.name for path in anchor_dir.iterdir()
        if path.name not in allowed_security_files
    }
    if not valid_existing or unexpected_security_files:
        LOCKOFF_MODE = True
        COMPLETE_LOCKOFF_MODE = True
        LOCKOFF_REASON = (
            'Boot anchor was tampered with, replaced, malformed, or accompanied '
            'by unexpected security data.'
        )
        print(f'{Colors.FAIL}{LOCKOFF_MESSAGE}{Colors.ENDC}')
        return False

    # A valid anchor copied with the application is a legitimate relocation.
    current_fingerprint = compute_workspace_fingerprint(
        Path(__file__).resolve().parent.resolve(),
        compute_host_identity(),
    )
    workspace_changed = existing_fingerprint != current_fingerprint
    if existing_root != expected['workspace_root']:
        RELOCATION_DETECTED = True
        if not write_security_file(anchor_path, json.dumps(expected, indent=2)):
            LOCKOFF_MODE = True
            COMPLETE_LOCKOFF_MODE = True
            LOCKOFF_REASON = 'Boot anchor could not be re-established after relocation.'
            return False
    elif workspace_changed:
        # A valid, unchanged anchor with a new application fingerprint is a
        # normal update; refresh the baseline without entering lockoff.
        if not write_security_file(anchor_path, json.dumps(expected, indent=2)):
            LOCKOFF_MODE = True
            COMPLETE_LOCKOFF_MODE = True
            LOCKOFF_REASON = 'Updated workspace baseline could not be persisted.'
            return False
    elif existing.get('hash_algorithm') != expected['hash_algorithm']:
        if not write_security_file(anchor_path, json.dumps(expected, indent=2)):
            LOCKOFF_MODE = True
            COMPLETE_LOCKOFF_MODE = True
            LOCKOFF_REASON = 'Boot anchor hash upgrade could not be persisted.'
            return False
    else:
        hide_security_path(anchor_path)
    LOCKOFF_MODE = False
    COMPLETE_LOCKOFF_MODE = False
    LOCKOFF_REASON = ''
    return True


def resolve_workspace_root(start_path: Optional[Path] = None) -> Path:
    """Locate the project root, including a bash-based fallback for shell-driven launches."""
    base = (start_path or Path.cwd()).resolve()
    candidates = []

    env_root = os.environ.get('VIDEO_BOT_ROOT', '').strip()
    if env_root:
        candidates.append(Path(env_root).expanduser().resolve())

    current = base
    for _ in range(6):
        candidates.append(current)
        if current.parent == current:
            break
        current = current.parent

    seen = set()
    for candidate in candidates:
        key = str(candidate)
        if key in seen:
            continue
        seen.add(key)
        if (candidate / 'Bot.py').exists() and (candidate / 'server.py').exists():
            return candidate
        if (candidate / 'download_pages').exists() and (candidate / 'downloads').exists():
            return candidate

    try:
        result = subprocess.run(
            [
                'bash', '-lc',
                'for d in "$PWD" "$(dirname "$PWD")" "$(dirname "$(dirname "$PWD")")"; do '
                'if [ -f "$d/Bot.py" ] && [ -f "$d/server.py" ]; then echo "$d"; break; fi; '
                'done'
            ],
            capture_output=True,
            text=True,
            cwd=str(base),
            check=False,
        )
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                candidate = Path(line.strip()).expanduser().resolve()
                if candidate.exists() and (candidate / 'Bot.py').exists() and (candidate / 'server.py').exists():
                    return candidate
    except Exception:
        pass

    return base


WORKSPACE_ROOT = resolve_workspace_root(Path(__file__).resolve().parent)
ensure_boot_anchor()


def load_persisted_instance_location() -> None:
    """Use the validated anchor location as the persistent instance location."""
    workspace = Path(__file__).resolve().parent.resolve()
    anchor_path = workspace / '.security' / '.boot-anchor.json'
    if LOCKOFF_MODE or not anchor_path.is_file():
        return
    try:
        anchor = json.loads(anchor_path.read_text(encoding='utf-8'))
        anchor_root = Path(str(anchor['workspace_root'])).resolve()
    except (OSError, KeyError, TypeError, ValueError):
        return
    if anchor_root == workspace:
        PYTHON_FILE_METADATA['original_absolute_directory'] = str(anchor_root)


load_persisted_instance_location()


def get_script_location_status() -> Dict[str, object]:
    """Report whether this Python file is running from its embedded directory."""
    current_directory = Path(__file__).resolve().parent
    embedded_path = str(PYTHON_FILE_METADATA.get('original_absolute_directory') or '').strip()
    embedded_directory = (
        Path(embedded_path).expanduser().resolve()
        if embedded_path else current_directory
    )
    moved = os.path.normcase(str(current_directory)) != os.path.normcase(
        str(embedded_directory)
    )
    return {
        'moved': moved,
        'current_absolute_directory': str(current_directory),
        'embedded_absolute_directory': str(embedded_directory),
        'metadata_version': PYTHON_FILE_METADATA['metadata_version'],
    }


SCRIPT_LOCATION_STATUS = get_script_location_status()


SENSITIVE_CONFIG_KEYS = frozenset({
    'youtube_api_key',
    'spotify_client_id',
    'spotify_client_secret',
})


def redact_sensitive_config_values(value: object) -> object:
    """Blank known credential fields recursively while preserving every key."""
    if isinstance(value, dict):
        for key in list(value):
            if str(key).lower() in SENSITIVE_CONFIG_KEYS:
                value[key] = ''
            else:
                redact_sensitive_config_values(value[key])
    elif isinstance(value, list):
        for item in value:
            redact_sensitive_config_values(item)
    return value


def reset_relocated_runtime_data() -> None:
    """Refresh copied-instance configuration and traceable runtime state."""
    if not RELOCATION_DETECTED and not SCRIPT_LOCATION_STATUS['moved']:
        return

    workspace = Path(__file__).resolve().parent
    config_path = workspace / 'config'
    legacy_config_path = workspace / 'config.json'
    integrity_path = workspace / '.security' / '.config-integrity.json'
    print(f'{Colors.WARNING}Copied instance detected. Configuration and '
          f'traceable runtime data will be refreshed to defaults. '
          f'Downloaded media will be preserved.{Colors.ENDC}')

    runtime_directories = (
        workspace / 'data',
        workspace / 'logs',
        workspace / 'temp',
        workspace / 'download_pages',
    )

    # Read structured JSON so colons inside values cannot affect key names.
    existing_config_path = config_path / 'config.json'
    if existing_config_path.exists():
        try:
            existing_config = json.loads(
                existing_config_path.read_text(encoding='utf-8')
            )
        except (OSError, json.JSONDecodeError):
            existing_config = {}
        cookie_file = str(existing_config.get('cookie_file') or '').strip()
        if cookie_file:
            cookie_path = Path(os.path.expandvars(os.path.expanduser(cookie_file)))
            if cookie_path.is_file():
                cookie_path.unlink()
        existing_config_path.unlink(missing_ok=True)

    for directory in runtime_directories:
        if directory.is_dir():
            shutil.rmtree(directory)
    if legacy_config_path.is_file():
        legacy_config_path.unlink()
    relocation_marker = workspace / '.relocation-reset.json'
    if relocation_marker.is_file():
        relocation_marker.unlink()

    for variable in (
        'VIDEO_RETRIEVER_YOUTUBE_API_KEY',
        'VIDEO_RETRIEVER_SPOTIFY_CLIENT_ID',
        'VIDEO_RETRIEVER_SPOTIFY_CLIENT_SECRET',
    ):
        os.environ.pop(variable, None)
    for artifact in (
        workspace / 'security-recovery-report.txt',
        workspace / '.relocation-reset.json',
        workspace / 'failed_downloads.json',
    ):
        try:
            if artifact.is_file():
                artifact.unlink()
        except OSError as exc:
            print(f'{Colors.WARNING}Could not remove recovery artifact {artifact}: {exc}{Colors.ENDC}')
    if integrity_path.is_file():
        integrity_path.unlink()

reset_relocated_runtime_data()


def ensure_config_integrity_baseline() -> None:
    """Persist hashes for the two monitored configuration files."""
    workspace = Path(__file__).resolve().parent
    integrity_path = workspace / '.security' / '.config-integrity.json'
    if integrity_path.exists():
        try:
            existing = json.loads(integrity_path.read_text(encoding='utf-8'))
            if isinstance(existing, dict) and len(existing) == 2:
                return
        except (OSError, json.JSONDecodeError):
            pass
    config_directory = workspace / 'config'
    monitored_paths = (
        config_directory / 'config.json',
        config_directory / 'nginx-video-retriever.conf',
    )
    hashes = {
        path.relative_to(workspace).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in monitored_paths if path.is_file()
    }
    if len(hashes) == 2:
        write_security_file(integrity_path, json.dumps(hashes, indent=2))


ensure_config_integrity_baseline()

# The embedded path is a distribution hint, not persistent owner identity.
# Once a valid moved copy has been reset, treat its current directory as the
# new instance location for the remainder of this process.
if SCRIPT_LOCATION_STATUS['moved'] and not LOCKOFF_MODE:
    PYTHON_FILE_METADATA['original_absolute_directory'] = (
        SCRIPT_LOCATION_STATUS['current_absolute_directory']
    )
    SCRIPT_LOCATION_STATUS = get_script_location_status()


def ensure_server_directories(root: Optional[Path] = None) -> Dict[str, Path]:
    """Create or confirm the directories needed by the web server and download pages."""
    project_root = root or WORKSPACE_ROOT
    paths = {
        'workspace': project_root,
        'download_pages': project_root / 'download_pages',
        'downloads': project_root / 'downloads',
        'thumbnails': project_root / 'downloads' / 'Single Videos' / 'thumbnails',
        'sql': project_root / 'data' / 'sql',
        'web': project_root / 'web',
        'favicon': project_root / 'web' / 'assets',
        'config': project_root / 'config',
        'failed_downloads': project_root / 'data' / 'failed',
        'history': project_root / 'data' / 'history',
        'state': project_root / 'data' / 'state',
        'cache': project_root / 'data' / 'cache',
        'modules': project_root / 'modules',
        'scripts': project_root / 'scripts',
        'docs': project_root / 'docs',
        'extensions': project_root / 'extensions',
    }
    for path in paths.values():
        path.mkdir(parents=True, exist_ok=True)
    return paths


REQUIRED_DIRECTORIES = ensure_server_directories(WORKSPACE_ROOT)

# ======================== CONFIG SYSTEM ========================

def load_config() -> Dict:
    """Load configuration from the managed directory, migrating the legacy file."""
    config_directory = WORKSPACE_ROOT / 'config'
    config_directory.mkdir(parents=True, exist_ok=True)
    config_path = config_directory / 'config.json'
    legacy_path = WORKSPACE_ROOT / 'config.json'
    if not config_path.exists() and legacy_path.exists():
        shutil.copy2(legacy_path, config_path)
    if config_path.exists():
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
                # Merge missing default values so older configs stay compatible.
                for key, value in DEFAULT_CONFIG.items():
                    config.setdefault(key, value)
                # Secrets supplied by the service environment take precedence over
                # file-based settings without rewriting credentials to disk.
                for setting, environment_name in (
                    ('youtube_api_key', 'VIDEO_RETRIEVER_YOUTUBE_API_KEY'),
                    ('spotify_client_id', 'VIDEO_RETRIEVER_SPOTIFY_CLIENT_ID'),
                    ('spotify_client_secret', 'VIDEO_RETRIEVER_SPOTIFY_CLIENT_SECRET'),
                ):
                    environment_value = os.environ.get(environment_name, '').strip()
                    if environment_value:
                        config[setting] = environment_value
                ensure_configured_directories(config)
                failed_directory = resolve_configured_directory(
                    config.get('failed_downloads_directory'),
                    './data/failed',
                )
                legacy_failed = WORKSPACE_ROOT / 'failed_downloads.json'
                managed_failed = failed_directory / 'failed_downloads.json'
                if not managed_failed.exists() and legacy_failed.exists():
                    shutil.copy2(legacy_failed, managed_failed)
                for filename, setting, default in (
                    ('download_history.json', 'history_directory', './data/history'),
                    ('download_progress.json', 'state_directory', './data/state'),
                ):
                    managed_file = resolve_configured_directory(config.get(setting), default) / filename
                    legacy_file = WORKSPACE_ROOT / filename
                    if not managed_file.exists() and legacy_file.exists():
                        shutil.copy2(legacy_file, managed_file)
                return config
        except Exception as e:
            print(f'{Colors.WARNING}Error loading config: {e}. Using defaults.{Colors.ENDC}')
    
    # Create default config
    with open(config_path, 'w') as f:
        json.dump(DEFAULT_CONFIG, f, indent=2)
    ensure_configured_directories(DEFAULT_CONFIG)
    print(f'{Colors.OKGREEN}✓ Created default config.json{Colors.ENDC}')
    return DEFAULT_CONFIG


def resolve_configured_directory(value: Optional[str], default_relative: str) -> Path:
    """Resolve a configured directory relative to the project root when needed."""
    configured = str(value or default_relative).strip()
    path = Path(os.path.expandvars(os.path.expanduser(configured)))
    return (path if path.is_absolute() else WORKSPACE_ROOT / path).resolve()


def ensure_configured_directories(config: Optional[Dict] = None) -> Dict[str, Path]:
    """Create all configured runtime directories and return their resolved paths."""
    settings = config or DEFAULT_CONFIG
    paths = {
        'downloads': resolve_configured_directory(settings.get('downloads_directory'), './downloads'),
        'output': resolve_configured_directory(settings.get('output_directory'), './downloads/Single Videos'),
        'spotify': resolve_configured_directory(settings.get('spotify_output_directory'), './downloads/Spotify'),
        'download_pages': resolve_configured_directory(settings.get('download_pages_directory'), './download_pages'),
        'thumbnails': resolve_configured_directory(settings.get('thumbnails_directory'), './downloads/Single Videos/thumbnails'),
        'logs': resolve_configured_directory(settings.get('logs_directory'), './logs'),
        'nginx_temp': resolve_configured_directory(settings.get('nginx_temp_directory'), './temp'),
        'sql': resolve_configured_directory(settings.get('sql_directory'), './data/sql'),
        'web': resolve_configured_directory(settings.get('web_directory'), './web'),
        'favicon': resolve_configured_directory(settings.get('favicon_directory'), './web/assets'),
        'config': resolve_configured_directory(settings.get('config_directory'), './config'),
        'failed_downloads': resolve_configured_directory(settings.get('failed_downloads_directory'), './data/failed'),
        'history': resolve_configured_directory(settings.get('history_directory'), './data/history'),
        'state': resolve_configured_directory(settings.get('state_directory'), './data/state'),
        'cache': resolve_configured_directory(settings.get('cache_directory'), './data/cache'),
        'modules': resolve_configured_directory(settings.get('modules_directory'), './modules'),
        'scripts': resolve_configured_directory(settings.get('scripts_directory'), './scripts'),
        'docs': resolve_configured_directory(settings.get('docs_directory'), './docs'),
        'extensions': resolve_configured_directory(settings.get('extensions_directory'), './extensions'),
    }
    for path in paths.values():
        path.mkdir(parents=True, exist_ok=True)
    return paths


def refresh_lockoff_runtime_state() -> None:
    """Reset mutable runtime/config state without destroying security evidence."""
    global LOCKOFF_STATE_REESTABLISHED
    if not LOCKOFF_MODE:
        return
    if COMPLETE_LOCKOFF_MODE:
        print(
            f'{Colors.FAIL}Complete lockoff active: {LOCKOFF_REASON or LOCKOFF_MESSAGE} '
            f'No security files will be rewritten.{Colors.ENDC}'
        )
        return
    workspace = Path(__file__).resolve().parent
    print(
        f'{Colors.FAIL}{LOCKOFF_MESSAGE} '
        f'Mutable configuration and runtime records will be reset to defaults; '
        f'downloaded media and security evidence will be preserved.{Colors.ENDC}'
    )
    for directory in (
        workspace / 'data',
        workspace / 'logs',
        workspace / 'temp',
        workspace / 'download_pages',
        workspace / 'config' / 'logs',
        workspace / 'config' / 'temp',
    ):
        if directory.is_dir():
            shutil.rmtree(directory)
    for path in (
        workspace / 'config' / 'config.json',
        workspace / 'config.json',
    ):
        if path.is_file():
            path.unlink()
    workspace_config = workspace / 'config'
    workspace_config.mkdir(parents=True, exist_ok=True)
    (workspace_config / 'config.json').write_text(
        json.dumps(DEFAULT_CONFIG, indent=2) + '\n',
        encoding='utf-8',
    )
    ensure_configured_directories(DEFAULT_CONFIG)
    LOCKOFF_STATE_REESTABLISHED = True
    print(
        f'{Colors.OKGREEN}Lockoff recovery completed: mutable configuration '
        f'and runtime files were restored to defaults. Security files were preserved '
        f'and remain under lockoff protection.{Colors.ENDC}'
    )


refresh_lockoff_runtime_state()

def save_config(config: Dict) -> None:
    """Save configuration to the managed configuration directory."""
    try:
        config_path = WORKSPACE_ROOT / 'config'
        config_path.mkdir(parents=True, exist_ok=True)
        with open(config_path / 'config.json', 'w') as f:
            json.dump(config, f, indent=2)
    except Exception as e:
        print(f'{Colors.FAIL}Error saving config: {e}{Colors.ENDC}')


def ensure_output_directory(base_path: str, playlist_name: Optional[str] = None) -> str:
    """Create a deterministic output directory for downloads and return it."""
    root = Path(base_path or str(WORKSPACE_ROOT))
    try:
        if root.resolve() == WORKSPACE_ROOT.resolve():
            root = resolve_configured_directory(
                load_config().get('output_directory'),
                './downloads/Single Videos',
            )
    except OSError:
        pass
    if playlist_name:
        folder = root / slugify(str(playlist_name))
    else:
        folder = root
    folder.mkdir(parents=True, exist_ok=True)
    return str(folder)


def managed_history_path() -> Path:
    return resolve_configured_directory(load_config().get('history_directory'), './data/history') / 'download_history.json'


def managed_progress_path() -> Path:
    return resolve_configured_directory(load_config().get('state_directory'), './data/state') / 'download_progress.json'


def get_dashboard_data() -> Dict:
    """Return a minimal dashboard payload compatible with the server API."""
    history = load_history() if managed_history_path().exists() else {'downloads': []}
    stats = get_download_statistics(history)
    return {
        'history': history,
        'stats': stats,
        'downloads': history.get('downloads', []),
        'script_location': get_script_location_status(),
    }


def get_all_download_progress() -> Dict:
    """Return a dictionary of in-flight download progress, if any."""
    state_path = managed_progress_path()
    if not state_path.exists():
        return {}
    try:
        raw = json.loads(state_path.read_text(encoding='utf-8'))
        if not isinstance(raw, dict):
            return {}
        now = time.time()
        active = {}
        terminal = {'completed', 'finished', 'failed', 'error', 'cancelled'}
        for key, value in raw.items():
            if not isinstance(value, dict):
                continue
            if set(value) <= {'requested_action'}:
                continue
            updated_at = value.get('updated_at')
            if not isinstance(updated_at, (int, float)):
                continue
            age = max(0, now - float(updated_at))
            limit = PROGRESS_TERMINAL_MAX_AGE_SECONDS if str(value.get('status', '')).lower() in terminal else PROGRESS_MAX_AGE_SECONDS
            if age <= limit:
                active[str(key)] = value
        return active
    except Exception:
        return {}


def set_download_progress(video_id: str, payload: Dict) -> None:
    """Persist simplified download-progress state for the HTTP API."""
    if not video_id:
        return
    try:
        with PROGRESS_FILE_LOCK:
            progress = get_all_download_progress()
            state = dict(payload or {})
            state['updated_at'] = time.time()
            progress[str(video_id)] = state
            managed_progress_path().write_text(json.dumps(progress, indent=2), encoding='utf-8')
    except Exception:
        pass


def download_cancel_requested(progress_id: Optional[str]) -> bool:
    """Check the server-owned cancellation flag for a running download."""
    if not progress_id:
        return False
    progress = get_all_download_progress().get(str(progress_id), {})
    return isinstance(progress, dict) and progress.get('requested_action') == 'cancel'


def clear_download_progress() -> None:
    """Clear the progress file used by the server UI."""
    try:
        managed_progress_path().unlink(missing_ok=True)
    except Exception:
        pass


def adaptive_bandwidth_limit(config: Dict) -> Optional[int]:
    """Scale the configured download rate when CPU or memory pressure is high."""
    if not config.get('adaptive_bandwidth_enabled', True) or psutil is None:
        return None
    try:
        cpu = float(psutil.cpu_percent(interval=0.05))
        memory = float(psutil.virtual_memory().percent)
        pressure = max(cpu, memory)
        throttle = float(config.get('adaptive_bandwidth_throttle_percent', 75))
        critical = float(config.get('adaptive_bandwidth_critical_percent', 95))
        if critical <= throttle:
            critical = throttle + 1
        if pressure < throttle:
            return None
        if pressure >= critical:
            return 1
        factor = max(0.05, (critical - pressure) / (critical - throttle))
        original = int(config.get('bandwidth_limit_kbps') or 0)
        if original <= 0:
            original = int(config.get('adaptive_bandwidth_ceiling_kbps') or 0)
        return max(1, int(original * factor))
    except (OSError, TypeError, ValueError):
        return None


def download_videos(video_list: List[Dict], output_dir: str, format_code: str, output_type: str, quality_label: str, history: Dict, config: Dict, download_subs: bool = False, sub_lang: str = 'en', progress_id: Optional[str] = None) -> List[Dict]:
    """Download videos with configurable concurrency and optional bandwidth limiting."""
    if not video_list:
        return []
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    def download_one(item: Dict) -> Dict:
        url = item.get('url') or item.get('video_url') or ''
        if not url:
            return {'status': 'skipped'}
        video_id = item.get('video_id') or get_video_id_from_url(url) or slugify(str(item.get('title') or url))
        if download_cancel_requested(progress_id):
            return {'video_id': video_id, 'title': item.get('title') or '', 'url': url, 'status': 'cancelled'}
        # Let yt-dlp use the resolved YouTube title so the saved file matches the
        # video name, while retaining the ID to avoid collisions between videos
        # with identical titles.
        target = out_dir / '%(title)s [%(id)s].%(ext)s'
        ydl_opts = {
            'outtmpl': str(target),
            'format': format_code,
            'quiet': True,
            'no_warnings': True,
            'noplaylist': True,
            'skip_download': False,
            'merge_output_format': 'mp4' if output_type == 'video' else None,
            'windowsfilenames': True,
            'trim_file_name': 180,
        }
        if progress_id:
            def progress_hook(status: Dict) -> None:
                if download_cancel_requested(progress_id):
                    raise yt_dlp.utils.DownloadError('Download cancelled by user')
                state = str(status.get('status') or '')
                percent = status.get('_percent_str') or ''
                if state == 'finished':
                    percent = '100%'
                set_download_progress(progress_id, {
                    'status': 'downloading' if state != 'finished' else 'processing',
                    'stage': state or 'downloading',
                    'title': item.get('title') or video_id,
                    'video_id': video_id,
                    'url': url,
                    'percent': percent,
                    'eta': status.get('_eta_str') or '',
                    'speed': status.get('_speed_str') or '',
                    'downloaded_bytes': status.get('downloaded_bytes') or 0,
                    'total_bytes': status.get('total_bytes') or status.get('total_bytes_estimate') or 0,
                })
            ydl_opts['progress_hooks'] = [progress_hook]
        if output_type == 'video' and config.get('embed_chapters', True):
            # Ask yt-dlp/FFmpeg to write YouTube chapter markers into the container.
            ydl_opts['embedchapters'] = True
        bandwidth_limit = adaptive_bandwidth_limit(config)
        if bandwidth_limit is None:
            bandwidth_limit = int(config.get('bandwidth_limit_kbps') or 0)
        if bandwidth_limit > 0:
            ydl_opts['ratelimit'] = bandwidth_limit * 1024
        if download_subs:
            ydl_opts['writesubtitles'] = True
            ydl_opts['writeautomaticsub'] = True
            ydl_opts['subtitleslangs'] = [sub_lang] if sub_lang and sub_lang != 'all' else ['en']
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
            return {'video_id': video_id, 'title': item.get('title') or (info.get('title') if isinstance(info, dict) else ''), 'url': url, 'status': 'downloaded'}
        except Exception as exc:
            if download_cancel_requested(progress_id) or 'Download cancelled by user' in str(exc):
                return {'video_id': video_id, 'title': item.get('title') or '', 'url': url, 'status': 'cancelled'}
            return {'video_id': video_id, 'title': item.get('title') or '', 'url': url, 'status': 'failed'}

    max_workers = max(1, min(8, int(config.get('concurrent_threads') or 1)))
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        completed = [result for result in executor.map(download_one, video_list) if result.get('status') != 'skipped']
    return completed


def maybe_start_proxy(config: Optional[Dict] = None) -> Optional[object]:
    """Start the proxy interpreter if enabled in config and the module is available."""
    config = config or load_config()
    if not config.get('enable_proxy_ui', False):
        return None
    if proxy_module is None:
        print(f'{Colors.WARNING}Proxy integration module is unavailable.{Colors.ENDC}')
        return None

    try:
        proxy = proxy_module.ProxyInterpreter(host=config.get('proxy_host', '127.0.0.1'), port=int(config.get('proxy_port', 8080)))
        proxy.ui_port = int(config.get('proxy_ui_port', 8081))
        proxy.rule_engine.add_rule(r'User-Agent', 'ProxyInterpreter/1.0')
        proxy.register_extension(proxy_module.SampleExtension())
        thread = threading.Thread(target=lambda: __import__('asyncio').run(proxy.start()), daemon=True)
        thread.start()
        print(f'{Colors.OKGREEN}Proxy UI started at http://{proxy.ui_host}:{proxy.ui_port}{Colors.ENDC}')
        return proxy
    except Exception as exc:
        print(f'{Colors.WARNING}Could not start proxy: {exc}{Colors.ENDC}')
        return None


def notify_proxy_event(proxy: Optional[object], event_type: str, payload: Optional[Dict] = None) -> None:
    """Send a lightweight event into the proxy's in-memory scan/captcha lists when available."""
    if proxy is None or not hasattr(proxy, 'scan_results'):
        return
    payload = payload or {}
    event = {'event_type': event_type, 'timestamp': __import__('time').time(), **payload}
    proxy.scan_results.append(event)

# ======================== PHASE 1: QUICK WIN FEATURES ========================

# FEATURE 1: DESKTOP NOTIFICATIONS
def send_desktop_notification(title: str, message: str, timeout: int = 5) -> None:
    """Send desktop notification when download completes."""
    try:
        system = platform.system()
        
        if system == 'Windows':
            try:
                from win10toast import ToastNotifier
                toaster = ToastNotifier()
                toaster.show_toast(title, message, duration=timeout, threaded=True)
            except ImportError:
                print(f'{Colors.WARNING}⚠ Install win10toast for notifications: pip install win10toast{Colors.ENDC}')
        
        elif system == 'Darwin':  # macOS
            os.system(f'osascript -e \'display notification "{message}" with title "{title}"\'')
        
        elif system == 'Linux':
            try:
                os.system(f'notify-send "{title}" "{message}" -t {timeout * 1000}')
            except:
                pass  # notify-send might not be available
    except Exception:
        pass

# FEATURE 2: ADVANCED FILTERING (Duration, Date, Views, Channel)
def apply_advanced_filters(videos: List[Dict], config: Dict) -> List[Dict]:
    """Apply advanced filters based on user preferences."""
    filtered = videos.copy()
    
    # Duration filter
    min_dur = config.get('min_duration', 0)
    max_dur = config.get('max_duration', 0)
    if min_dur > 0 or max_dur > 0:
        filtered = [v for v in filtered if (
            (min_dur == 0 or v.get('duration', 0) >= min_dur * 60) and
            (max_dur == 0 or v.get('duration', 0) <= max_dur * 60)
        )]
    
    # View count filter
    min_views = config.get('min_views', 0)
    if min_views > 0:
        filtered = [v for v in filtered if v.get('view_count', 0) >= min_views]
    
    # Upload date filter
    min_date = config.get('min_date', '')
    if min_date:
        try:
            from datetime import datetime
            cutoff = datetime.strptime(min_date, '%Y-%m-%d')
            filtered = [v for v in filtered if datetime.strptime(
                v.get('upload_date', '19700101')[:8], '%Y%m%d') >= cutoff]
        except:
            pass
    
    return filtered

def ask_advanced_filters() -> Dict:
    """Ask user for advanced filter preferences."""
    print(f'\n{Colors.BOLD}🔍 ADVANCED FILTERS (Optional){Colors.ENDC}')
    print('  Leave blank to skip filtering\n')
    
    filters = {}
    
    try:
        min_dur = input(f'{Colors.OKCYAN}Min duration (minutes, default: 0): {Colors.ENDC}').strip()
        filters['min_duration'] = int(min_dur) if min_dur else 0
    except:
        filters['min_duration'] = 0
    
    try:
        max_dur = input(f'{Colors.OKCYAN}Max duration (minutes, 0=unlimited): {Colors.ENDC}').strip()
        filters['max_duration'] = int(max_dur) if max_dur else 0
    except:
        filters['max_duration'] = 0
    
    try:
        min_views = input(f'{Colors.OKCYAN}Min view count (0=any): {Colors.ENDC}').strip()
        filters['min_views'] = int(min_views) if min_views else 0
    except:
        filters['min_views'] = 0
    
    min_date = input(f'{Colors.OKCYAN}Upload date (YYYY-MM-DD, blank=any): {Colors.ENDC}').strip()
    filters['min_date'] = min_date if min_date else ''
    
    return filters

# FEATURE 3: PRIVACY MODE
def ask_privacy_mode() -> bool:
    """Ask user if they want privacy mode enabled."""
    print(f'\n{Colors.BOLD}🔒 PRIVACY MODE{Colors.ENDC}')
    print('  Disables: History tracking, Metadata logging, Analytics')
    choice = input(f'{Colors.OKCYAN}Enable privacy mode? (y/n, default n): {Colors.ENDC}').strip().lower()
    return choice == 'y'

def clear_sensitive_logs(privacy_mode: bool) -> None:
    """Clear logs if privacy mode is enabled."""
    if privacy_mode:
        try:
            history_path = managed_history_path()
            if history_path.exists():
                history_path.unlink()
                print(f'{Colors.OKGREEN}✓ Cleared download history{Colors.ENDC}')
        except:
            pass

# FEATURE 4: PROXY SUPPORT (SOCKS5, VPN, etc)
def ask_proxy_config() -> Dict:
    """Ask user for proxy configuration."""
    print(f'\n{Colors.BOLD}🌐 PROXY CONFIGURATION (Optional){Colors.ENDC}')
    print('  Examples: socks5://127.0.0.1:1080, http://proxy.example.com:8080')
    
    use_proxy = input(f'{Colors.OKCYAN}Use proxy? (y/n, default n): {Colors.ENDC}').strip().lower() == 'y'
    
    if use_proxy:
        proxy_url = input(f'{Colors.OKCYAN}Enter proxy URL: {Colors.ENDC}').strip()
        return {'use_proxy': True, 'proxy_url': proxy_url}
    
    return {'use_proxy': False, 'proxy_url': ''}

def apply_proxy_settings(ydl_opts: Dict, config: Dict) -> Dict:
    """Apply proxy settings to yt-dlp options."""
    if config.get('use_proxy') and config.get('proxy_url'):
        ydl_opts['proxy'] = config['proxy_url']
    return ydl_opts

# FEATURE 5: CLI ENHANCEMENTS (Silent mode, Script-friendly output, No menu)
def apply_cli_enhancements(args: Optional[List[str]] = None) -> Dict:
    """Parse CLI arguments for script-friendly operation."""
    cli_opts = {
        'silent_mode': False,
        'no_menu': False,
        'json_output': False,
        'auto_start': False,
        'config_file': None,
        'start_server': False,
        'server_host': '127.0.0.1',
        'server_port': 5000,
    }
    
    if args:
        index = 0
        while index < len(args):
            arg = args[index]
            if arg == '--silent':
                cli_opts['silent_mode'] = True
            elif arg == '--no-menu':
                cli_opts['no_menu'] = True
            elif arg == '--json':
                cli_opts['json_output'] = True
            elif arg == '--auto-start':
                cli_opts['auto_start'] = True
            elif arg.startswith('--config='):
                cli_opts['config_file'] = arg.split('=')[1]
            elif arg == '--start-server':
                cli_opts['start_server'] = True
            elif arg == '--server-host':
                if index + 1 < len(args):
                    cli_opts['server_host'] = args[index + 1]
                    index += 1
            elif arg.startswith('--server-host='):
                cli_opts['server_host'] = arg.split('=', 1)[1]
            elif arg == '--server-port':
                if index + 1 < len(args):
                    try:
                        cli_opts['server_port'] = int(args[index + 1])
                    except ValueError:
                        cli_opts['server_port'] = 5000
                    index += 1
            elif arg.startswith('--server-port='):
                try:
                    cli_opts['server_port'] = int(arg.split('=', 1)[1])
                except ValueError:
                    cli_opts['server_port'] = 5000
            index += 1
    
    return cli_opts

def print_cli_output(data: Dict, cli_opts: Dict) -> None:
    """Print output in CLI-friendly format (JSON or human-readable)."""
    if cli_opts['json_output']:
        print(json.dumps(data, indent=2))
    elif not cli_opts['silent_mode']:
        for key, value in data.items():
            print(f'{key}: {value}')

# ======================== ENHANCED YOUTUBE AUTHENTICATION FIX ========================

def get_enhanced_ydl_options(base_format: str, base_options: Dict = None) -> Dict:
    """
    Create enhanced yt-dlp options with authentication bypass.
    Fixes: "Sign in to confirm you're not a bot" errors
    """
    options = base_options.copy() if base_options else {}
    
    options.update({
        'format': base_format,
        'merge_output_format': 'webm' if 'webm' in base_format else 'mp4',
        
        # ===== ANTI-BOT AUTHENTICATION MEASURES =====
        # Browser cookies are enabled in the download options builder when
        # config['use_browser_cookies'] is True.
        
        # Proper User-Agent (appears as real browser)
        'http_headers': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept-Language': 'en-US,en;q=0.9',
        },
        
        # Connection resilience
        'socket_timeout': 30,
        'retries': 15,
        'fragment_retries': 15,
        'skip_unavailable_fragments': True,
        
        # YouTube-specific settings
        'extractor_args': {
            'youtube': {
                'skip_unavailable_fragments': True
            }
        },
        
        # Rate limiting (be respectful)
        'sleep_interval': 2,
        'max_sleep_interval': 10,
        'geo_bypass': True,
    })
    
    return options

def download_video_thumbnail(video_id: str, output_dir: str) -> Optional[str]:
    """
    Download video thumbnail for preview on dashboard.
    Returns path to thumbnail file or None if failed.
    """
    try:
        thumbnail_dir = Path(output_dir) / 'thumbnails'
        thumbnail_dir.mkdir(parents=True, exist_ok=True)
        
        thumbnail_path = thumbnail_dir / f'{video_id}.jpg'
        if thumbnail_path.exists():
            return str(thumbnail_path)
        
        # YouTube thumbnail URL (high quality)
        thumbnail_url = f'https://i.ytimg.com/vi/{video_id}/maxresdefault.jpg'
        
        urllib.request.urlretrieve(thumbnail_url, thumbnail_path)
        return str(thumbnail_path)
    except Exception:
        # Fallback to standard quality thumbnail
        try:
            thumbnail_path = Path(output_dir) / 'thumbnails' / f'{video_id}_fallback.jpg'
            thumbnail_url = f'https://i.ytimg.com/vi/{video_id}/hqdefault.jpg'
            urllib.request.urlretrieve(thumbnail_url, thumbnail_path)
            return str(thumbnail_path)
        except Exception:
            return None


def to_web_path(file_path: Optional[str]) -> str:
    """Convert an absolute filesystem path to a relative web path."""
    if not file_path:
        return ''

    path = Path(file_path)
    try:
        resolved = path.resolve()
        if WORKSPACE_ROOT in resolved.parents or resolved == WORKSPACE_ROOT:
            return resolved.relative_to(WORKSPACE_ROOT).as_posix()
    except Exception:
        pass

    return str(path).replace('\\', '/')


def slugify(value: str) -> str:
    """Create a filesystem-safe slug from a label."""
    text = (value or 'download').lower()
    cleaned = ''.join(ch if ch.isalnum() else '-' for ch in text)
    parts = [part for part in cleaned.split('-') if part]
    slug = '-'.join(parts)[:60]
    return slug or 'download'


def build_download_page_url(download: Dict) -> str:
    """Build a stable relative URL for a single download page."""
    title = str(download.get('title') or 'download')
    video_id = str(download.get('video_id') or 'unknown')
    return f'download_pages/{slugify(title)}-{video_id[:12]}.html'


def _yt_dlp_dashboard_options(config: Optional[Dict] = None, comments: bool = False) -> Dict:
    """Build safe yt-dlp options for dashboard metadata requests."""
    config = config or load_config()
    opts = {
        'quiet': True,
        'no_warnings': True,
        'skip_download': True,
        'noplaylist': True,
        'extract_flat': False,
    }

    if comments:
        # YouTube comment extraction is best-effort and can be unavailable
        # depending on the video/account/session.
        opts['getcomments'] = True

    if config.get('cookie_file'):
        opts['cookiefile'] = config.get('cookie_file')
    elif config.get('use_browser_cookies'):
        browser = config.get('browser_cookies_from') or (
            'safari' if platform.system() == 'Darwin' else 'chrome'
        )
        opts['cookiesfrombrowser'] = (browser,)

    return apply_proxy_settings(opts, config)


def extract_video_intelligence(video_url: str, include_comments: bool = True) -> Dict:
    """Extract a dashboard-ready YouTube metadata snapshot.

    Preferred order: YouTube Data API (when a key is configured), then yt-dlp. pytube is kept as a
    last-resort fallback only because it is less reliable against YouTube's anti-bot changes.
    """
    video_url = (video_url or '').strip()
    if not video_url:
        raise ValueError('Missing video URL')

    try:
        normalized_url = normalize_video_url(video_url)
        if normalized_url:
            video_url = normalized_url
    except Exception:
        pass

    config = load_config()
    api_key = (config or {}).get('youtube_api_key')

    if api_key:
        try:
            api_result = fetch_youtube_video_metadata(video_url, api_key=api_key, include_comments=include_comments)
            if isinstance(api_result, dict) and 'video' in api_result and not api_result.get('error'):
                video = api_result.get('video', {})
                snippet = video.get('snippet', {}) if isinstance(video, dict) else {}
                stats = video.get('statistics', {}) if isinstance(video, dict) else {}
                comments = api_result.get('comments', [])
                return {
                    'video': {
                        'id': video.get('id') or get_video_id_from_url(video_url) or '',
                        'url': video_url,
                        'title': snippet.get('title') or '',
                        'channel': snippet.get('channelTitle') or '',
                        'channel_title': snippet.get('channelTitle') or '',
                        'thumbnail': (snippet.get('thumbnails') or {}).get('maxres', {}).get('url') or (snippet.get('thumbnails') or {}).get('high', {}).get('url') or '',
                        'duration': 0,
                        'description': snippet.get('description') or '',
                        'published_at': snippet.get('publishedAt') or '',
                        'category': snippet.get('categoryId') or '',
                        'tags': snippet.get('tags', [])[:20],
                    },
                    'metrics': {
                        'views': int(stats.get('viewCount') or 0),
                        'likes': int(stats.get('likeCount') or 0),
                        'comments': int(stats.get('commentCount') or 0),
                        'subscribers': 0,
                    },
                    'comments': comments,
                    'source': 'youtube-data-api',
                    'updated_at': datetime.utcnow().isoformat(timespec='seconds') + 'Z',
                }
        except Exception as exc:
            print(f'YouTube Data API metadata failed; falling back to yt-dlp: {exc}')

    # Preferred robust metadata backend: yt-dlp
    opts = _yt_dlp_dashboard_options(config, comments=include_comments)
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(video_url, download=False)
        if info:
            comments = []
            for item in (info.get('comments') or [])[:30]:
                if not isinstance(item, dict):
                    continue
                comments.append({
                    'author': item.get('author') or item.get('uploader') or 'YouTube user',
                    'text': item.get('text') or item.get('content') or '',
                    'published_at': item.get('timestamp') or item.get('time_text') or '',
                    'like_count': item.get('like_count') or 0,
                })

            upload_date = info.get('upload_date') or ''
            if len(upload_date) == 8 and upload_date.isdigit():
                upload_date = f'{upload_date[:4]}-{upload_date[4:6]}-{upload_date[6:8]}'

            tags = info.get('tags') or info.get('keywords') or []
            if not isinstance(tags, list):
                tags = []

            result = {
                'video': {
                    'id': info.get('id') or '',
                    'url': info.get('webpage_url') or video_url,
                    'title': info.get('title') or '',
                    'channel': info.get('channel') or info.get('uploader') or '',
                    'channel_title': info.get('channel') or info.get('uploader') or '',
                    'thumbnail': info.get('thumbnail') or '',
                    'duration': info.get('duration') or 0,
                    'description': info.get('description') or '',
                    'published_at': upload_date,
                    'category': info.get('categories', [None])[0] if info.get('categories') else '',
                    'tags': tags[:20],
                },
                'metrics': {
                    'views': info.get('view_count') or 0,
                    'likes': info.get('like_count') or 0,
                    'comments': info.get('comment_count') or len(comments),
                    'subscribers': info.get('channel_follower_count') or info.get('uploader_follower_count') or 0,
                },
                'comments': comments,
                'source': 'yt-dlp',
                'updated_at': datetime.utcnow().isoformat(timespec='seconds') + 'Z',
            }
            return result
    except Exception as e:
        print('yt-dlp metadata extraction failed; attempting final pytube fallback:', str(e))

    # Final legacy fallback: only used when yt-dlp and the API are unavailable.
    try:
        from pytube import YouTube

        yt = YouTube(video_url)
        video_id = yt.video_id or ''
        publish_date = ''
        if getattr(yt, 'publish_date', None):
            try:
                publish_date = yt.publish_date.isoformat()
            except Exception:
                publish_date = str(yt.publish_date)

        def safe_attr(obj, attr_name, default=None):
            try:
                value = getattr(obj, attr_name)
                return default if value is None else value
            except Exception:
                return default

        tags = []
        try:
            tags = list(yt.keywords or [])
        except Exception:
            tags = []

        return {
            'video': {
                'id': video_id,
                'url': safe_attr(yt, 'watch_url', video_url) or video_url,
                'title': safe_attr(yt, 'title', '') or '',
                'channel': safe_attr(yt, 'author', '') or '',
                'channel_title': safe_attr(yt, 'author', '') or '',
                'thumbnail': safe_attr(yt, 'thumbnail_url', '') or '',
                'duration': safe_attr(yt, 'length', 0) or 0,
                'description': safe_attr(yt, 'description', '') or '',
                'published_at': publish_date,
                'category': '',
                'tags': tags[:20],
            },
            'metrics': {
                'views': safe_attr(yt, 'views', 0) or 0,
                'likes': 0,
                'comments': 0,
                'subscribers': 0,
            },
            'comments': [],
            'source': 'pytube-fallback',
            'updated_at': datetime.utcnow().isoformat(timespec='seconds') + 'Z',
        }
    except Exception as e:
        raise RuntimeError(f'Unable to inspect video metadata via YouTube API, yt-dlp, or pytube fallback: {e}')


def fetch_live_video_metadata(video_url: str) -> Dict:
    """Backward-compatible lightweight metadata helper."""
    try:
        data = extract_video_intelligence(video_url, include_comments=False)
        video = data.get('video', {})
        metrics = data.get('metrics', {})
        return {
            'title': video.get('title', ''),
            'channel': video.get('channel', ''),
            'duration': video.get('duration', 0),
            'views': metrics.get('views', 0),
            'likes': metrics.get('likes', 0),
            'url': video.get('url', video_url),
        }
    except Exception:
        return {}


def create_download_detail_page(download: Dict) -> str:
    """Generate a single-download HTML page and return its relative URL."""
    page_url = download.get('page_url') or build_download_page_url(download)
    page_path = (WORKSPACE_ROOT / page_url).resolve()
    page_path.parent.mkdir(parents=True, exist_ok=True)

    thumbnail_html = ''
    thumbnail_path = download.get('thumbnail_path') or ''
    if thumbnail_path:
        normalized_thumb = str(thumbnail_path).replace('\\', '/')
        if not normalized_thumb.startswith('/'):
            normalized_thumb = f'/{normalized_thumb}'
        normalized_thumb = quote(normalized_thumb, safe='/')
        thumbnail_html = (
            f'<img src="{html.escape(normalized_thumb)}" '
            f'alt="{html.escape(str(download.get("title", "Download")))}">'
        )
    else:
        thumbnail_html = '<div class="thumbnail-placeholder">🎬</div>'

    def format_metric(value: object, kind: str = 'value') -> str:
        if value in (None, '', 'Unknown', 'unknown'):
            return 'Unknown'

        if isinstance(value, str):
            cleaned = value.strip().replace(',', '')
            if cleaned.isdigit():
                value = int(cleaned)
            elif cleaned.replace('.', '', 1).isdigit():
                value = float(cleaned)
            else:
                return value

        if kind == 'duration' and isinstance(value, (int, float)):
            if value >= 3600:
                hours = int(value // 3600)
                minutes = int((value % 3600) // 60)
                seconds = int(value % 60)
                return f'{hours}h {minutes}m {seconds}s'
            if value >= 60:
                minutes = int(value // 60)
                seconds = int(value % 60)
                return f'{minutes}m {seconds}s'
            return f'{int(value)}s'

        if isinstance(value, (int, float)):
            if isinstance(value, float) and value.is_integer():
                value = int(value)
            if isinstance(value, int):
                return f'{value:,}'
            return f'{value:,.2f}'.rstrip('0').rstrip('.')

        return str(value)

    live_metadata = fetch_live_video_metadata(str(download.get('url') or '')) or {}

    def resolve_value(primary: object, fallback: object) -> object:
        if primary not in (None, '', 0, '0', 'Unknown', 'unknown'):
            return primary
        if fallback not in (None, '', 0, '0', 'Unknown', 'unknown'):
            return fallback
        return primary

    title = html.escape(str(resolve_value(download.get('title'), live_metadata.get('title')) or 'Download'))
    channel = html.escape(str(resolve_value(download.get('channel'), live_metadata.get('channel')) or 'Unknown'))
    quality = html.escape(str(download.get('quality') or 'Unknown'))
    timestamp = html.escape(str(download.get('timestamp') or datetime.now().isoformat()))
    file_path = html.escape(str(download.get('file_path') or 'Unknown'))
    duration = format_metric(resolve_value(download.get('duration'), live_metadata.get('duration')), kind='duration')
    views = format_metric(resolve_value(download.get('views'), live_metadata.get('views')))
    likes = format_metric(resolve_value(download.get('likes'), live_metadata.get('likes')))
    url = html.escape(str(resolve_value(download.get('url'), live_metadata.get('url')) or ''))
    file_size = download.get('file_size') or 0

    # Attempt to reuse the dashboard's stylesheet so download pages visually match the app.
    style_block = None
    try:
        dashboard_path = resolve_configured_directory(
            load_config().get('web_directory'),
            './web',
        ) / 'dashboard.html'
        if not dashboard_path.exists():
            dashboard_path = WORKSPACE_ROOT / 'dashboard.html'
        if dashboard_path.exists():
            raw = dashboard_path.read_text(encoding='utf-8')
            start = raw.find('<style>')
            end = raw.find('</style>', start + 1)
            if start != -1 and end != -1:
                # extract inner content of the first style tag
                style_block = raw[start + len('<style>'):end].strip()
    except Exception:
        style_block = None

    # Fallback minimal style if dashboard.css can't be read
    if not style_block:
        style_block = '''
:root{--bg:#17191d;--surface:#202328;--text:#f3f5f8}
*{box-sizing:border-box}
body{margin:0;min-height:100vh;background:var(--bg);color:var(--text);font:14px/1.5 Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
.container{width:min(100%,1200px);margin:30px auto;padding:24px;background:var(--surface);border-radius:12px}
.card{background:var(--surface);border-radius:10px;padding:18px;border:1px solid rgba(255,255,255,0.03)}
.thumbnail{border-radius:8px;overflow:hidden;background:#06070a}
'''

    html_doc = f'''<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{title} • Multimedia Handler Download</title>
  <style>
{style_block}
  </style>
</head>
<body>
  <div class="app">
    <aside class="sidebar" aria-hidden="true">
      <div class="brand"><span class="brand-mark" aria-hidden="true"><span></span></span>
        <div><strong>Multimedia Handler</strong><small>Local control center</small></div>
      </div>
      <nav class="nav" aria-label="Secondary">
        <button class="subtle" onclick="location.href='dashboard_sync.html'">Back to dashboard</button>
      </nav>
    </aside>
    <main class="main">
      <div class="header">
        <div class="breadcrumb"><b>Download</b></div>
        <div class="header-actions"></div>
      </div>
      <div class="content">
        <div class="card video-intel wide">
          <div class="card-head">
            <div>
              <h2>Download detail</h2>
              <p class="secondary">{channel}</p>
            </div>
            <div class="kicker">{timestamp}</div>
          </div>
          <div class="card-body video-intel-body">
            <div class="video-preview">
              <div class="thumbnail-wrap">{thumbnail_html}</div>
              <div class="video-preview-info">
                <h3>{title}</h3>
                <div class="video-channel">{channel} <span class="channel-sep">•</span> <span class="secondary">{url}</span></div>
                <p class="video-description">{html.escape(download.get('description') or '')}</p>
                <div class="video-actions">
                  <a class="btn primary" href="{download.get('file_url') or '#'}" download>Open file</a>
                  <a class="btn" href="../dashboard_sync.html">Back to dashboard</a>
                </div>
              </div>
            </div>

            <div class="download-summary">
              <div class="download-meta"><span>Quality</span><b>{quality}</b></div>
              <div class="download-meta"><span>Download size</span><b>{file_size} bytes</b></div>
              <div class="download-meta"><span>Duration</span><b>{duration}</b></div>
              <div class="download-meta"><span>Views</span><b>{views}</b></div>
            </div>

            <div style="margin-top:16px" class="comments-panel">
              <div class="section-title">File location</div>
              <div class="card-body"><code>{file_path}</code></div>
            </div>

          </div>
        </div>
      </div>
    </main>
  </div>
</body>
</html>'''

    page_path.write_text(html_doc, encoding='utf-8')
    return page_url


def build_download_record(video_id: str, title: str, url: str, file_path: str, file_size: int, quality: str, output_type: str, thumbnail_path: Optional[str], metadata: Dict) -> Dict:
    """Create a normalized download history record with web-safe links."""
    page_url = build_download_page_url({
        'title': title,
        'video_id': video_id,
    })

    return {
        'video_id': video_id,
        'title': title,
        'url': url,
        'file_path': file_path,
        'file_url': to_web_path(file_path),
        'file_size': file_size,
        'quality': quality,
        'output_type': output_type,
        'thumbnail_path': to_web_path(thumbnail_path) if thumbnail_path else '',
        'page_url': page_url,
        'timestamp': datetime.now().isoformat(),
        'channel': metadata.get('channel', ''),
        'duration': metadata.get('duration', 0),
        'views': metadata.get('views', 0),
        'likes': metadata.get('likes', 0),
        'description': metadata.get('description', ''),
        'upload_date': metadata.get('upload_date', ''),
    }


def normalize_download_entry(download: Dict) -> Dict:
    """Ensure history entries contain web-safe URLs and metadata defaults."""
    normalized = dict(download)
    normalized['title'] = str(normalized.get('title') or 'Unknown')
    normalized['quality'] = str(normalized.get('quality') or 'Unknown')
    normalized['video_id'] = str(normalized.get('video_id') or '')
    normalized['id'] = normalized['video_id']
    normalized['file_path'] = str(normalized.get('file_path') or '')
    normalized['file_url'] = to_web_path(normalized.get('file_path'))
    normalized['thumbnail_path'] = to_web_path(normalized.get('thumbnail_path'))
    if not normalized.get('page_url'):
        normalized['page_url'] = build_download_page_url(normalized)
    if not normalized.get('timestamp'):
        normalized['timestamp'] = datetime.now().isoformat()
    try:
        create_download_detail_page(normalized)
    except Exception:
        pass
    return normalized


def build_history_from_filesystem(config: Dict) -> Dict:
    """Fallback: build download history records from the local downloads folder."""
    output_dir_value = Path(config.get('output_directory', './downloads'))
    output_dir = output_dir_value if output_dir_value.is_absolute() else WORKSPACE_ROOT / output_dir_value
    if not output_dir.exists():
        return {'downloads': []}

    downloads = []
    allowed_exts = {'.mp4', '.mkv', '.webm', '.mov', '.avi', '.mp3', '.m4a', '.flac', '.wav'}

    for file_path in sorted(output_dir.rglob('*')):
        if file_path.is_dir() or file_path.suffix.lower() not in allowed_exts:
            continue

        stem = file_path.stem
        video_id = ''
        title = stem
        if '[' in stem and ']' in stem:
            maybe_id = stem.rsplit('[', 1)[-1].rsplit(']', 1)[0]
            if maybe_id:
                video_id = maybe_id
                title = stem.rsplit('[', 1)[0].rstrip(' ._-')

        if not video_id:
            video_id = stem[:12] or file_path.stem

        quality = 'MP3' if file_path.suffix.lower() in {'.mp3', '.m4a', '.flac', '.wav'} else 'Best'
        if '1080p' in stem.lower():
            quality = '1080p'
        elif '720p' in stem.lower():
            quality = '720p'
        elif '480p' in stem.lower():
            quality = '480p'

        thumbnail_candidates = [file_path.parent / 'thumbnails' / f'{video_id}.jpg']
        thumbnail_path = next((str(path) for path in thumbnail_candidates if path.exists()), '')

        record = build_download_record(
            video_id=video_id,
            title=title or file_path.name,
            url='',
            file_path=str(file_path),
            file_size=file_path.stat().st_size,
            quality=quality,
            output_type='audio' if file_path.suffix.lower() in {'.mp3', '.m4a', '.flac', '.wav'} else 'video',
            thumbnail_path=thumbnail_path,
            metadata={
                'channel': 'Local download',
                'duration': 0,
                'views': 0,
                'likes': 0,
                'description': '',
                'upload_date': datetime.fromtimestamp(file_path.stat().st_mtime).date().isoformat(),
            },
        )
        downloads.append(normalize_download_entry(record))

    return {'downloads': downloads}

# ======================== HISTORY SYSTEM ========================

def load_history() -> Dict:
    """Load download history from download_history.json."""
    history_path = managed_history_path()
    if history_path.exists():
        try:
            with open(history_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f'{Colors.WARNING}Error loading history: {e}{Colors.ENDC}')
    return {'downloads': []}

def save_history(history: Dict) -> None:
    """Save download history."""
    try:
        history_path = managed_history_path()
        with open(history_path, 'w') as f:
            json.dump(history, f, indent=2)
    except Exception as e:
        print(f'{Colors.FAIL}Error saving history: {e}{Colors.ENDC}')


def add_to_history(history: Dict, download_record: Dict) -> None:
    """Add a normalized download entry to history."""
    history['downloads'].append(download_record)


def is_duplicate(history: Dict, video_id: str) -> bool:
    """Check if video is already in history."""
    return any(d['video_id'] == video_id for d in history.get('downloads', []))

def get_download_state() -> Dict:
    """Load pause/resume state."""
    state_path = managed_progress_path().with_name('download_state.json')
    if state_path.exists():
        try:
            with open(state_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f'{Colors.WARNING}Error loading download state: {e}{Colors.ENDC}')
    return {}

# ======================== STATISTICS & ANALYTICS ========================

def get_download_statistics(history: Dict) -> Dict:
    """Calculate comprehensive download statistics."""
    downloads = history.get('downloads', [])
    output_path = Path(load_config().get('output_directory', './downloads'))
    if not output_path.is_absolute():
        output_path = WORKSPACE_ROOT / output_path
    try:
        disk = shutil.disk_usage(output_path if output_path.exists() else WORKSPACE_ROOT)
        free_bytes = disk.free
        total_bytes = disk.total
        used_bytes = disk.used
    except OSError:
        free_bytes = total_bytes = used_bytes = 0
    if not downloads:
        return {
            'total_videos': 0,
            'total_size_gb': 0,
            'total_storage_bytes': 0,
            'disk_free_bytes': free_bytes,
            'disk_total_bytes': total_bytes,
            'disk_used_bytes': used_bytes,
            'storage_warning': bool(total_bytes and free_bytes / total_bytes <= (load_config().get('storage_warning_percent', 10) / 100)),
            'success_rate': 0,
            'average_quality': 'N/A',
            'most_common_quality': 'N/A',
            'top_channels': [],
            'quality_breakdown': {},
        }
    
    # Calculate basic stats
    total_videos = len(downloads)
    total_size = sum(d.get('file_size', 0) for d in downloads)
    total_size_gb = total_size / (1024 ** 3)
    
    # Quality breakdown
    quality_counts = {}
    for d in downloads:
        q = d.get('quality', 'Unknown')
        quality_counts[q] = quality_counts.get(q, 0) + 1
    
    # Channel extraction and counting
    channel_counts = {}
    for d in downloads:
        # Extract channel from URL if available
        url = d.get('url', '')
        try:
            if 'youtube.com' in url:
                # For now, we'll track video count
                channel_counts['YouTube'] = channel_counts.get('YouTube', 0) + 1
        except:
            pass
    
    return {
        'total_videos': total_videos,
        'total_size_gb': round(total_size_gb, 2),
        'total_storage_bytes': total_size,
        'disk_free_bytes': free_bytes,
        'disk_total_bytes': total_bytes,
        'disk_used_bytes': used_bytes,
        'storage_warning': bool(total_bytes and free_bytes / total_bytes <= (load_config().get('storage_warning_percent', 10) / 100)),
        'success_rate': 100.0,
        'quality_breakdown': quality_counts,
        'most_common_quality': max(quality_counts, key=quality_counts.get) if quality_counts else 'N/A',
    }

def print_statistics(history: Dict) -> None:
    """Print download statistics in a formatted table."""
    stats = get_download_statistics(history)
    
    print(f'\n{Colors.BOLD}{Colors.HEADER}📊 DOWNLOAD STATISTICS{Colors.ENDC}')
    print('=' * 50)
    print(f'Total Videos Downloaded: {Colors.OKBLUE}{stats["total_videos"]}{Colors.ENDC}')
    print(f'Total Storage Used: {Colors.OKBLUE}{stats["total_size_gb"]} GB{Colors.ENDC}')
    print(f'Success Rate: {Colors.OKGREEN}{stats["success_rate"]:.1f}%{Colors.ENDC}')
    
    if stats['quality_breakdown']:
        print(f'\n{Colors.OKCYAN}Quality Breakdown:{Colors.ENDC}')
        for quality, count in sorted(stats['quality_breakdown'].items(), key=lambda x: x[1], reverse=True):
            percentage = (count / stats['total_videos']) * 100
            print(f'  • {quality}: {count} videos ({percentage:.1f}%)')
    
    print('=' * 50)

def save_download_state(state: Dict) -> None:
    """Save pause/resume state."""
    try:
        with open(managed_progress_path().with_name('download_state.json'), 'w') as f:
            json.dump(state, f, indent=2)
    except Exception as e:
        print(f'{Colors.FAIL}Error saving download state: {e}{Colors.ENDC}')

# ======================== QUALITY SELECTOR ========================

def select_quality() -> Tuple[str, str, str]:
    """Let user select download quality."""
    qualities = {
        '1': ('bestvideo[height<=1080]+bestaudio/best', '1080p', 'video'),
        '2': ('bestvideo[height<=720]+bestaudio/best', '720p', 'video'),
        '3': ('bestvideo[height<=480]+bestaudio/best', '480p', 'video'),
        '4': ('bestaudio/best', 'Audio Only (MP3)', 'audio'),
        '5': ('best', 'Best Available', 'video'),
    }
    
    print(f'\n{Colors.BOLD}{Colors.OKCYAN}Quality Options:{Colors.ENDC}')
    print('  1. 1080p (Best quality, larger file)')
    print('  2. 720p (Good quality, medium file)')
    print('  3. 480p (Lower quality, smaller file)')
    print('  4. Audio Only (MP3 format)')
    print('  5. Best Available (default)')
    
    choice = input(f'{Colors.OKCYAN}Select quality (1-5, default 5): {Colors.ENDC}').strip() or '5'
    
    if choice not in qualities:
        print(f'{Colors.WARNING}Invalid choice, using best available.{Colors.ENDC}')
        choice = '5'
    
    format_code, quality_label, output_type = qualities[choice]
    return format_code, quality_label, output_type

# ======================== FILTERING SYSTEM ========================

def apply_filters(videos: List[Dict]) -> List[Dict]:
    """Apply advanced filters to videos."""
    print(f'\n{Colors.BOLD}{Colors.OKCYAN}Filtering Options:{Colors.ENDC}')
    print('  1. No filtering')
    print('  2. Filter by duration')
    print('  3. Search by keyword')
    print('  4. Both duration and keyword')
    
    choice = input(f'{Colors.OKCYAN}Select filter (1-4, default 1): {Colors.ENDC}').strip() or '1'
    
    filtered = videos.copy()
    
    if choice in ('2', '4'):
        min_duration = input(f'{Colors.OKCYAN}Minimum duration (minutes, default 0): {Colors.ENDC}').strip()
        max_duration = input(f'{Colors.OKCYAN}Maximum duration (minutes, default 999): {Colors.ENDC}').strip()
        
        try:
            min_secs = int(min_duration) * 60 if min_duration else 0
            max_secs = int(max_duration) * 60 if max_duration else 999 * 60
            filtered = [v for v in filtered if min_secs <= v['duration'] <= max_secs]
            print(f'{Colors.OKGREEN}Filtered to {len(filtered)} videos by duration.{Colors.ENDC}')
        except ValueError:
            print(f'{Colors.WARNING}Invalid duration input, skipping.{Colors.ENDC}')
    
    if choice in ('3', '4'):
        keyword = input(f'{Colors.OKCYAN}Search keyword: {Colors.ENDC}').strip().lower()
        if keyword:
            filtered = [v for v in filtered if keyword in v['title'].lower()]
            print(f'{Colors.OKGREEN}Filtered to {len(filtered)} videos by keyword.{Colors.ENDC}')
    
    return filtered if filtered else videos

# ======================== ADVANCED FEATURES ========================

def search_downloads(history: Dict, keyword: str) -> List[Dict]:
    """Search through download history."""
    keyword = keyword.lower()
    results = []
    for download in history.get('downloads', []):
        if (keyword in download.get('title', '').lower() or 
            keyword in download.get('url', '').lower()):
            results.append(download)
    return results

def get_failed_downloads() -> List[Dict]:
    """Get list of videos to retry from failed downloads."""
    failed_path = resolve_configured_directory(
        load_config().get('failed_downloads_directory'),
        './data/failed',
    ) / 'failed_downloads.json'
    if failed_path.exists():
        try:
            with open(failed_path, 'r', encoding='utf-8') as f:
                return json.load(f).get('failed', [])
        except Exception:
            pass
    return []

def retry_failed_downloads(history: Dict, config: Dict) -> None:
    """Retry previously failed downloads."""
    failed = get_failed_downloads()
    if not failed:
        print(f'{Colors.WARNING}No failed downloads to retry.{Colors.ENDC}')
        return

    print(f'{Colors.OKCYAN}Retrying {len(failed)} failed download(s)...{Colors.ENDC}')
    videos = []
    for item in failed:
        videos.append({
            'url': item.get('url', ''),
            'title': item.get('title', item.get('url', 'Unknown')),
            'id': item.get('video_id', ''),
            'duration': 0,
        })

    format_code, quality_label, output_type = select_quality()
    download_subs, sub_lang = should_download_subtitles()
    output_dir = ensure_output_directory(os.getcwd(), None)
    download_videos(videos, output_dir, format_code, output_type, quality_label, history, config, download_subs, sub_lang)

    if config.get('enable_history', True):
        save_history(history)
        print(f'{Colors.OKGREEN}✓ History updated after retry.{Colors.ENDC}')

    print(f'{Colors.OKGREEN}Retry attempt complete. Check failed_downloads.json for any remaining failures.{Colors.ENDC}')


def add_failed_download(video_id: str, title: str, url: str, error: str = '') -> None:
    """Track failed downloads for retry."""
    failed_path = resolve_configured_directory(
        load_config().get('failed_downloads_directory'),
        './data/failed',
    ) / 'failed_downloads.json'
    failed_list = get_failed_downloads()
    
    # Avoid duplicates by video ID and title
    if not any(f['video_id'] == video_id and f.get('title') == title for f in failed_list):
        failed_list.append({
            'video_id': video_id,
            'title': title,
            'url': url,
            'error': error[:500],
            'timestamp': datetime.now().isoformat()
        })
    
    try:
        with open(failed_path, 'w', encoding='utf-8') as f:
            json.dump({'failed': failed_list}, f, indent=2)
    except Exception as e:
        print(f'{Colors.FAIL}Error saving failed download: {e}{Colors.ENDC}')

def extract_subtitles_info(video_url: str) -> Dict:
    """Extract available subtitle languages."""
    try:
        with yt_dlp.YoutubeDL({'quiet': True, 'no_warnings': True}) as ydl:
            info = ydl.extract_info(video_url, download=False)
            subtitles = info.get('subtitles', {})
            auto_captions = info.get('automatic_captions', {})
            return {
                'available_subtitles': list(subtitles.keys()),
                'available_auto_captions': list(auto_captions.keys()),
            }
    except:
        return {'available_subtitles': [], 'available_auto_captions': []}

def should_download_subtitles() -> Tuple[bool, str]:
    """Ask user if they want to download subtitles and which language."""
    print(f'\n{Colors.BOLD}{Colors.OKCYAN}Subtitle Options:{Colors.ENDC}')
    print('  1. No subtitles')
    print('  2. Download all available languages')
    print('  3. Download specific language')
    
    choice = input(f'{Colors.OKCYAN}Select option (1-3, default 1): {Colors.ENDC}').strip() or '1'
    
    if choice == '1':
        return False, ''
    elif choice == '2':
        return True, 'all'
    elif choice == '3':
        lang = input(f'{Colors.OKCYAN}Enter language code (en, es, fr, de, etc., default en): {Colors.ENDC}').strip() or 'en'
        return True, lang
    
    return False, ''

def organize_subtitles(output_dir: str) -> None:
    """Organize downloaded subtitles into a dedicated folder."""
    try:
        output_path = Path(output_dir)
        subtitles_dir = output_path / 'subtitles'
        subtitles_dir.mkdir(exist_ok=True)
        
        # Move .vtt files to subtitles folder
        for vtt_file in output_path.glob('*.vtt'):
            new_path = subtitles_dir / vtt_file.name
            vtt_file.rename(new_path)
            print(f'{Colors.OKGREEN}  ✓ Organized: {vtt_file.name}{Colors.ENDC}')
    except Exception as e:
        print(f'{Colors.WARNING}  Could not organize subtitles: {e}{Colors.ENDC}')

def get_quality_recommendation(connection_speed_mbps: float) -> str:
    """Recommend quality based on connection speed."""
    if connection_speed_mbps < 2:
        return '480p'
    elif connection_speed_mbps < 5:
        return '720p'
    else:
        return '1080p'

# ======================== INPUT & DETECTION ========================

def get_user_url() -> str:
    """Get YouTube URL from user with clipboard validation."""
    print(f"{Colors.BOLD}{Colors.HEADER}=== YouTube Video Downloader ==={Colors.ENDC}\n")
    video_url = input(f'{Colors.OKCYAN}Paste the YouTube link and press Enter: {Colors.ENDC}')
    
    if not video_url.strip():
        print(f'{Colors.FAIL}Error: Empty URL provided. Please try again.{Colors.ENDC}')
        return get_user_url()
    
    # Validate clipboard matches input
    try:
        clipboard_content = pyperclip.paste()
        if clipboard_content != video_url:
            print(f'{Colors.WARNING}Warning: Pasted content does not match clipboard.{Colors.ENDC}')
            confirm = input(f'{Colors.OKCYAN}Continue with the entered URL? (y/n): {Colors.ENDC}').lower()
            if confirm != 'y':
                return get_user_url()
    except Exception as e:
        print(f'{Colors.WARNING}Warning: Could not validate clipboard: {e}{Colors.ENDC}')
    
    return video_url

def detect_playlist(url: str) -> Tuple[bool, Optional[str]]:
    """Detect if URL is a playlist and return playlist ID if applicable."""
    try:
        with yt_dlp.YoutubeDL({'quiet': True, 'no_warnings': True}) as ydl:
            info = ydl.extract_info(url, download=False)

            if isinstance(info, dict) and info.get('_type') == 'playlist':
                return True, info.get('title', 'Playlist')
            return False, None
    except Exception as e:
        print(f'{Colors.FAIL}Error detecting URL type: {e}{Colors.ENDC}')
        return False, None


def extract_playlist_videos(url: str, max_videos: Optional[int] = None) -> List[Dict]:
    """Return a normalized list of video dictionaries from a playlist or single-video URL."""
    if not url:
        return []

    target = normalize_video_url(url) or url
    try:
        with yt_dlp.YoutubeDL({
            'quiet': True,
            'no_warnings': True,
            'skip_download': True,
            'extract_flat': False,
            'noplaylist': False,
        }) as ydl:
            info = ydl.extract_info(target, download=False)
    except Exception:
        return []

    if not info:
        return []

    entries = []
    if isinstance(info, dict):
        if info.get('_type') == 'playlist':
            entries = info.get('entries') or []
        elif info.get('id'):
            entries = [info]

    videos = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        video_url = entry.get('webpage_url') or entry.get('url') or target
        if max_videos and len(videos) >= max_videos:
            break
        video_id = entry.get('id') or get_video_id_from_url(video_url) or ''
        videos.append({
            'title': entry.get('title') or 'Untitled video',
            'url': video_url,
            'video_id': video_id,
            'duration': entry.get('duration') or 0,
            'channel': entry.get('channel') or entry.get('uploader') or '',
            'thumbnail': entry.get('thumbnail') or '',
            'views': entry.get('view_count') or 0,
            'description': entry.get('description') or '',
        })

    return videos


import re
from urllib.parse import urlparse as _urlparse, parse_qs as _parse_qs


def normalize_video_url(url: str) -> Optional[str]:
    """
    Normalize various YouTube URL forms to a canonical watch or playlist URL that yt-dlp understands.
    Returns a canonical URL string or None if the URL is not recognized as YouTube.
    Examples handled:
      - https://youtu.be/VIDEOID -> https://www.youtube.com/watch?v=VIDEOID
      - https://www.youtube.com/watch?v=VIDEOID
      - https://www.youtube.com/embed/VIDEOID
      - https://www.youtube.com/shorts/VIDEOID
      - playlist URLs with list=LISTID -> https://www.youtube.com/playlist?list=LISTID
    """
    if not url:
        return None
    url = str(url).strip()
    # Allow passing just an ID
    if re.fullmatch(r'[A-Za-z0-9_-]{11}', url):
        return f'https://www.youtube.com/watch?v={url}'
    try:
        p = _urlparse(url)
    except Exception:
        return None
    netloc = (p.netloc or '').lower()
    path = p.path or ''
    # Short links: youtu.be/VIDEOID
    if 'youtu.be' in netloc:
        vid = path.lstrip('/')
        if vid:
            return f'https://www.youtube.com/watch?v={vid}'
        return None
    # Regular youtube domains
    if 'youtube.com' in netloc or 'youtube-nocookie.com' in netloc:
        qs = _parse_qs(p.query or '')
        v = qs.get('v', [None])[0]
        listid = qs.get('list', [None])[0]
        if v:
            return f'https://www.youtube.com/watch?v={v}'
        # embed path /embed/VIDEOID
        m = re.match(r'^/embed/([^/?]+)', path)
        if m:
            return f'https://www.youtube.com/watch?v={m.group(1)}'
        # shorts path
        m2 = re.match(r'^/shorts/([^/?]+)', path)
        if m2:
            return f'https://www.youtube.com/watch?v={m2.group(1)}'
        # playlist-only
        if listid:
            return f'https://www.youtube.com/playlist?list={listid}'
        # some legacy /v/VIDEOID
        m3 = re.match(r'^/v/([^/?]+)', path)
        if m3:
            return f'https://www.youtube.com/watch?v={m3.group(1)}'
    return None


    """Detect if URL is a playlist and return playlist ID if applicable."""
    try:
        with yt_dlp.YoutubeDL({'quiet': True, 'no_warnings': True}) as ydl:
            info = ydl.extract_info(url, download=False)
            
            # Check if it's a playlist
            if info.get('_type') == 'playlist':
                playlist_id = info.get('id')
                playlist_title = info.get('title', 'Playlist')
                return True, playlist_title
            else:
                return False, None
    except Exception as e:
        print(f'{Colors.FAIL}Error detecting URL type: {e}{Colors.ENDC}')
        return False, None

def get_video_id_from_url(url: str) -> Optional[str]:
    """
    Extract a YouTube video ID (11-character) or playlist ID (list=...) from a normalized URL.
    Returns the video ID if present, otherwise None.
    """
    if not url:
        return None
    try:
        p = _urlparse(url)
    except Exception:
        return None
    qs = _parse_qs(p.query or '')
    v = qs.get('v', [None])[0]
    if v:
        return v
    # playlist id
    lst = qs.get('list', [None])[0]
    if lst:
        return lst
    # check path (/watch?v= handled), /embed/ and /shorts/ handled by normalize
    path = (p.path or '').lstrip('/')
    # youtu.be short id in path
    if path and len(path) in (11,):
        return path
    return None


def fetch_youtube_video_metadata(url: str, api_key: Optional[str] = None, include_comments: bool = False, max_comments: int = 20) -> Dict:
    """
    Fetch metadata (and optionally top comments) for a YouTube video using YouTube Data API v3.
    Returns a dict with keys 'video' and optionally 'comments'. On error returns a dict with 'error'.
    """
    if not api_key:
        return {'error': 'No API key provided'}

    vid = get_video_id_from_url(url)
    if not vid:
        return {'error': 'Unable to extract video id from URL'}

    base_videos = 'https://www.googleapis.com/youtube/v3/videos'
    params = {
        'part': 'snippet,contentDetails,statistics',
        'id': vid,
        'key': api_key,
    }
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
        'Accept': 'application/json',
    }
    api_config = load_config()
    api_proxies = None
    configured_proxy = str(api_config.get('proxy_url') or '').strip()
    if api_config.get('use_proxy') and configured_proxy:
        api_proxies = {'http': configured_proxy, 'https': configured_proxy}
    api_session = requests.Session()
    # Do not silently inherit a stale HTTP(S)_PROXY from the host environment.
    api_session.trust_env = False

    last_error = None
    resp = None
    for attempt in range(1, 4):
        try:
            resp = api_session.get(
                base_videos,
                params=params,
                headers=headers,
                proxies=api_proxies,
                timeout=20,
            )
            if resp.status_code == 200:
                break
            last_error = f'YouTube Data API returned {resp.status_code}: {resp.text[:200]}'
            if resp.status_code in (403, 429):
                break
        except requests.exceptions.Timeout as exc:
            last_error = f'HTTP timeout contacting YouTube Data API (attempt {attempt}/3): {exc}'
        except Exception as exc:
            last_error = f'HTTP error contacting YouTube Data API (attempt {attempt}/3): {exc}'

        if attempt < 3:
            time.sleep(2 ** (attempt - 1))

    if resp is None or resp.status_code != 200:
        return {'error': last_error or 'YouTube Data API request failed without a response'}

    try:
        body = resp.json()
    except Exception as e:
        return {'error': f'Invalid JSON from YouTube Data API: {e}'}

    items = body.get('items', [])
    if not items:
        return {'error': 'Video not found via YouTube Data API'}

    video_info = items[0]
    result = {'video': video_info, 'comments': []}

    if include_comments:
        comments = []
        base_comments = 'https://www.googleapis.com/youtube/v3/commentThreads'
        cparams = {
            'part': 'snippet,replies',
            'videoId': vid,
            'key': api_key,
            'maxResults': min(max_comments, 20),
            'textFormat': 'plainText',
            'order': 'relevance',
        }
        cerr = None
        try:
            cresp = api_session.get(
                base_comments,
                params=cparams,
                headers=headers,
                proxies=api_proxies,
                timeout=15,
            )
            if cresp.status_code == 200:
                cbody = cresp.json()
                for item in cbody.get('items', [])[:max_comments]:
                    snippet = item.get('snippet', {})
                    top = snippet.get('topLevelComment', {})
                    comment = top.get('snippet', {})
                    comments.append({
                        'author': comment.get('authorDisplayName') or 'YouTube user',
                        'text': comment.get('textDisplay') or '',
                        'published_at': comment.get('publishedAt') or '',
                        'like_count': int(snippet.get('likeCount') or comment.get('likeCount') or 0),
                    })
                comments.sort(key=lambda x: x.get('like_count', 0), reverse=True)
                comments = comments[:max_comments]
            else:
                cerr = f'Comment API returned {cresp.status_code}'
        except Exception as exc:
            cerr = str(exc)
        if cerr:
            result['comments_error'] = cerr
        result['comments'] = comments

    return result


def search_youtube_video_candidates(
    query: str,
    api_key: Optional[str] = None,
    max_results: int = 10,
) -> List[Dict]:
    """Search YouTube Data API v3 for video candidates matching a track query."""
    if not api_key:
        return []
    params = {
        'part': 'snippet',
        'q': query,
        'type': 'video',
        'order': 'relevance',
        'maxResults': max(1, min(25, int(max_results))),
        'key': api_key,
    }
    headers = {'User-Agent': 'Video-Retriever/1.0', 'Accept': 'application/json'}
    config = load_config()
    configured_proxy = str(config.get('proxy_url') or '').strip()
    proxies = (
        {'http': configured_proxy, 'https': configured_proxy}
        if config.get('use_proxy') and configured_proxy else None
    )
    session = requests.Session()
    session.trust_env = False
    last_error = None
    for attempt in range(1, 4):
        try:
            response = session.get(
                'https://www.googleapis.com/youtube/v3/search',
                params=params,
                headers=headers,
                proxies=proxies,
                timeout=20,
            )
            if response.status_code == 200:
                body = response.json()
                return [
                    {
                        'video_id': item.get('id', {}).get('videoId', ''),
                        'title': item.get('snippet', {}).get('title', ''),
                        'channel': item.get('snippet', {}).get('channelTitle', ''),
                        'description': item.get('snippet', {}).get('description', ''),
                        'published_at': item.get('snippet', {}).get('publishedAt', ''),
                    }
                    for item in body.get('items', [])
                    if item.get('id', {}).get('videoId')
                ]
            last_error = f'YouTube search API returned {response.status_code}: {response.text[:200]}'
            if response.status_code in (400, 403, 429):
                break
        except requests.exceptions.RequestException as exc:
            last_error = f'YouTube search API request failed (attempt {attempt}/3): {exc}'
        if attempt < 3:
            time.sleep(2 ** (attempt - 1))
    raise RuntimeError(last_error or 'YouTube search API request failed')
def main():
    """Main execution function with Tier 3 advanced features + Phase 1 Quick Wins."""
    try:
        # Load configuration
        config = load_config()
        history = load_history() if config.get('enable_history', True) else {'downloads': []}
        
        # ===== PHASE 1: CLI ENHANCEMENTS =====
        cli_opts = apply_cli_enhancements(sys.argv[1:] if len(sys.argv) > 1 else None)

        if cli_opts['start_server']:
            start_server_from_bot(cli_opts['server_host'], cli_opts['server_port'])
            return
        
        # ===== PHASE 1: PRIVACY MODE =====
        privacy_mode = ask_privacy_mode() if not cli_opts['silent_mode'] else config.get('enable_privacy_mode', False)
        config['enable_privacy_mode'] = privacy_mode
        
        if privacy_mode:
            config['enable_history'] = False
            clear_sensitive_logs(privacy_mode)
            print(f'{Colors.OKGREEN}✓ Privacy mode enabled{Colors.ENDC}')
        
        # ===== PHASE 1: PROXY CONFIGURATION =====
        if not cli_opts['silent_mode']:
            proxy_config = ask_proxy_config()
            config.update(proxy_config)
        
        # ===== TIER 3: PRE-DOWNLOAD OPTIONS =====
        if not cli_opts['no_menu']:
            print(f'\n{Colors.BOLD}{Colors.HEADER}🚀 MAIN MENU{Colors.ENDC}')
            print('  1. Download Videos')
            print('  2. Generate Dashboard')
            print('  3. View Analytics')
            print('  4. Export Analytics')
            print('  5. Setup Cloud Sync')
            print('  6. View Recommendations')
            print('  7. Retry Failed Downloads')
            print('  8. Settings ⚙️')
            
            advanced_choice = input(f'{Colors.OKCYAN}Select option (1-8, default 1): {Colors.ENDC}').strip() or '1'
            
            if advanced_choice == '2':
                # Generate and open dashboard
                dashboard = WebDashboard(history, config)
                dashboard.generate_dashboard_file()
                return
            elif advanced_choice == '3':
                # View analytics
                generate_analytics_report(history)
                return
            elif advanced_choice == '4':
                # Export analytics
                export_analytics_csv(history)
                return
            elif advanced_choice == '5':
                # Setup cloud sync
                cloud_sync = CloudSync(config)
                cloud_sync.setup_cloud_sync()
                return
            elif advanced_choice == '6':
                # View recommendations
                recommend_content(history)
                return
            elif advanced_choice == '7':
                # Retry failed downloads
                retry_failed_downloads(history, config)
                return
            elif advanced_choice == '8':
                # Settings menu
                config = show_settings_menu(config)
                return
        
        # Continue with normal download
        # Get URL from user
        url = get_user_url()
        
        # Detect if playlist
        is_playlist, playlist_name = detect_playlist(url)
        
        if is_playlist:
            print(f'{Colors.OKGREEN}✓ Detected as playlist: {playlist_name}{Colors.ENDC}')
        else:
            print(f'{Colors.OKGREEN}✓ Single video detected{Colors.ENDC}')
            playlist_name = None
        
        # Extract video information
        videos = extract_playlist_videos(url)
        if not videos:
            print(f'{Colors.FAIL}Could not extract video information. Exiting.{Colors.ENDC}')
            return
        
        # ===== PHASE 1: APPLY ADVANCED FILTERS =====
        original_count = len(videos)
        videos = apply_advanced_filters(videos, config)
        if len(videos) < original_count:
            print(f'{Colors.OKGREEN}✓ Config filters applied: {original_count} → {len(videos)} videos{Colors.ENDC}')
        
        # Apply interactive filters for playlists
        if is_playlist and len(videos) > 1:
            print(f'\n{Colors.BOLD}{Colors.OKCYAN}Filter Options:{Colors.ENDC}')
            print('  1. No additional filtering')
            print('  2. Filter by duration')
            print('  3. Search by keyword')
            print('  4. Both duration and keyword')
            
            filter_choice = input(f'{Colors.OKCYAN}Apply filters? (1-4, default 1): {Colors.ENDC}').strip() or '1'
            
            if filter_choice in ('2', '3', '4'):
                pre_filter_count = len(videos)
                videos = apply_filters(videos)
                post_filter_count = len(videos)
                if post_filter_count < pre_filter_count:
                    print(f'{Colors.OKGREEN}✓ Interactive filters applied: {pre_filter_count} → {post_filter_count} videos{Colors.ENDC}')
        
        # Get user selection
        selected_videos = get_user_selection(videos)
        
        # ===== TIER 3: DUPLICATE DETECTION =====
        if config.get('enable_history', True):
            for video in selected_videos[:3]:  # Check first 3 videos
                if not check_duplicate_before_download(video, history):
                    selected_videos.remove(video)
        
        if not selected_videos:
            print(f'{Colors.WARNING}No videos to download.{Colors.ENDC}')
            return
        
        # Quality selection
        format_code, quality_label, output_type = select_quality()
        print(f'{Colors.OKGREEN}✓ Selected quality: {quality_label}{Colors.ENDC}')
        
        # Subtitle selection
        download_subs, sub_lang = should_download_subtitles()
        if download_subs:
            if sub_lang == 'all':
                print(f'{Colors.OKGREEN}✓ Will download all available subtitle languages{Colors.ENDC}')
            else:
                print(f'{Colors.OKGREEN}✓ Will download subtitles in: {sub_lang}{Colors.ENDC}')
        
        # Setup output directory
        output_dir = ensure_output_directory(os.getcwd(), playlist_name)
        print(f'{Colors.OKCYAN}Output directory: {output_dir}{Colors.ENDC}\n')
        
        # Download videos
        download_videos(selected_videos, output_dir, format_code, output_type, quality_label, history, config, download_subs, sub_lang)
        
        # Save history
        if config.get('enable_history', True):
            save_history(history)
            print(f'{Colors.OKGREEN}✓ Download history saved.{Colors.ENDC}')
        
        # ===== PHASE 1: DESKTOP NOTIFICATIONS =====
        if config.get('enable_notifications', True):
            total_videos = len(selected_videos)
            send_desktop_notification(
                'Video Bot Download Complete',
                f'Successfully downloaded {total_videos} video(s)!',
                timeout=5
            )
        
        # ===== TIER 3: POST-DOWNLOAD OPTIONS =====
        print(f'\n{Colors.BOLD}{Colors.OKGREEN}=== All downloads completed! ==={Colors.ENDC}')
        print(f'{Colors.OKCYAN}Videos saved to: {output_dir}{Colors.ENDC}')
        
        print(f'\n{Colors.BOLD}{Colors.HEADER}📊 POST-DOWNLOAD OPTIONS{Colors.ENDC}')
        print('  1. Return to menu')
        print('  2. Generate updated dashboard')
        print('  3. View updated analytics')
        print('  4. Sync to cloud')
        
        post_choice = input(f'{Colors.OKCYAN}Select option (1-4, default 1): {Colors.ENDC}').strip() or '1'
        
        if post_choice == '2':
            dashboard = WebDashboard(history, config)
            dashboard.generate_dashboard_file()
        elif post_choice == '3':
            generate_analytics_report(history)
        elif post_choice == '4':
            cloud_sync = CloudSync(config)
            cloud_sync.sync_downloads(output_dir)
        
    except KeyboardInterrupt:
        print(f'\n{Colors.WARNING}Download interrupted by user.{Colors.ENDC}')
        sys.exit(0)
    except Exception as e:
        print(f'{Colors.FAIL}Fatal error: {e}{Colors.ENDC}')
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
