import os
import sqlite3
import json
import tempfile
from pathlib import Path
from typing import Optional
import base64
import binascii

# Minimal DPAPI decrypt using ctypes to avoid external dependencies
import ctypes
from ctypes import wintypes

class DATA_BLOB(ctypes.Structure):
    _fields_ = [('cbData', wintypes.DWORD), ('pbData', ctypes.POINTER(ctypes.c_char))]

def _dpapi_decrypt(encrypted_bytes: bytes) -> Optional[bytes]:
    if not encrypted_bytes:
        return None
    CryptUnprotectData = ctypes.windll.crypt32.CryptUnprotectData
    LocalFree = ctypes.windll.kernel32.LocalFree
    blob_in = DATA_BLOB()
    blob_in.cbData = len(encrypted_bytes)
    blob_in.pbData = ctypes.cast(ctypes.create_string_buffer(encrypted_bytes, len(encrypted_bytes)), ctypes.POINTER(ctypes.c_char))
    blob_out = DATA_BLOB()
    if CryptUnprotectData(ctypes.byref(blob_in), None, None, None, None, 0, ctypes.byref(blob_out)):
        ptr = ctypes.cast(blob_out.pbData, ctypes.POINTER(ctypes.c_char * blob_out.cbData))
        buffer = ptr.contents.raw
        LocalFree(blob_out.pbData)
        return buffer
    return None


def _chrome_time_to_epoch(expires_utc: int) -> int:
    try:
        if not expires_utc:
            return 0
        # expires_utc in microseconds since 1601-01-01
        return int(int(expires_utc) / 1000000 - 11644473600)
    except Exception:
        return 0


def _get_local_state_key(db_path: Optional[Path] = None) -> Optional[bytes]:
    """Find and extract the AES key from Local State for the given profile (best-effort).

    The Chrome/Chromium/Opera Local State contains os_crypt.encrypted_key which is base64-encoded
    and DPAPI-encrypted on Windows. This function attempts to load Local State from locations
    near the cookies DB (db_path) or from common Opera profile locations.
    """
    candidates = []
    try:
        if db_path:
            # Common: Local State in the same profile directory or parent
            candidates.append(db_path.parent / 'Local State')
            candidates.append(db_path.parent.parent / 'Local State')
        appdata = os.environ.get('APPDATA')
        localappdata = os.environ.get('LOCALAPPDATA')
        if appdata:
            candidates += [
                Path(appdata) / 'Opera Software' / 'Opera GX Stable' / 'Local State',
                Path(appdata) / 'Opera Software' / 'Opera Stable' / 'Local State',
                Path(appdata) / 'Opera Software' / 'Opera' / 'Local State',
            ]
        if localappdata:
            candidates += [
                Path(localappdata) / 'Opera Software' / 'Opera GX Stable' / 'Local State',
                Path(localappdata) / 'Opera Software' / 'Opera Stable' / 'Local State',
                Path(localappdata) / 'Opera Software' / 'Opera' / 'Local State',
            ]
    except Exception:
        pass

    for p in candidates:
        try:
            if not p or not p.exists():
                continue
            data = json.loads(p.read_text(encoding='utf-8'))
            enc_b64 = data.get('os_crypt', {}).get('encrypted_key')
            if not enc_b64:
                continue
            enc_key = base64.b64decode(enc_b64)
            # Strip "DPAPI" prefix if present
            if enc_key.startswith(b'DPAPI'):
                enc_key = enc_key[5:]
            # Decrypt with DPAPI
            key = _dpapi_decrypt(enc_key)
            if key:
                return key
        except Exception:
            continue
    return None


def _aes_gcm_decrypt(encrypted_bytes: bytes, key: bytes) -> Optional[bytes]:
    """Decrypt Chromium AES-GCM encrypted value (nonce + ciphertext + tag).

    encrypted_bytes is expected to be: nonce (12) + ciphertext + tag (16).
    Attempts to use cryptography (preferred) or PyCryptodome as a fallback.
    """
    try:
        if not encrypted_bytes or not key:
            return None
        if len(encrypted_bytes) < 12 + 16:
            return None
        nonce = encrypted_bytes[:12]
        ct_tag = encrypted_bytes[12:]
        # Try cryptography.io
        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            aesgcm = AESGCM(key)
            plain = aesgcm.decrypt(nonce, ct_tag, None)
            return plain
        except Exception:
            pass
        # Try PyCryptodome
        try:
            from Crypto.Cipher import AES
            if len(ct_tag) < 16:
                return None
            ciphertext = ct_tag[:-16]
            tag = ct_tag[-16:]
            cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
            plain = cipher.decrypt_and_verify(ciphertext, tag)
            return plain
        except Exception:
            pass
    except Exception:
        pass
    return None


def find_opera_cookies_db() -> Optional[Path]:

    appdata = os.environ.get('APPDATA')
    localappdata = os.environ.get('LOCALAPPDATA')
    candidates = []
    if appdata:
        candidates += [
            Path(appdata) / 'Opera Software' / 'Opera GX Stable' / 'Cookies',
            Path(appdata) / 'Opera Software' / 'Opera Stable' / 'Cookies',
            Path(appdata) / 'Opera Software' / 'Opera' / 'Cookies',
        ]
    if localappdata:
        candidates += [
            Path(localappdata) / 'Opera Software' / 'Opera GX Stable' / 'Cookies',
            Path(localappdata) / 'Opera Software' / 'Opera Stable' / 'Cookies',
            Path(localappdata) / 'Opera Software' / 'Opera' / 'Cookies',
        ]
    for p in candidates:
        if p.exists():
            return p
    return None


def export_opera_cookies_netscape(domains=('.', 'youtube.com', 'googlevideo.com')) -> Optional[str]:
    """Export Opera (Chromium) cookies for given domains to a Netscape cookies.txt file.
    Returns path to cookiefile or None on failure.
    """
    db_path = find_opera_cookies_db()
    if not db_path:
        return None
    try:
        tmp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        tmp_db.close()
        # copy DB to temp (avoid lock)
        with open(db_path, 'rb') as src, open(tmp_db.name, 'wb') as dst:
            dst.write(src.read())
        conn = sqlite3.connect(tmp_db.name)
        cur = conn.cursor()
        pattern = '%' + '%'.join(domains) + '%'
        # Query cookies for youtube & googlevideo hosts
        sql = "SELECT host_key, name, path, expires_utc, is_secure, encrypted_value FROM cookies WHERE (host_key LIKE '%youtube.com' OR host_key LIKE '%googlevideo.com' OR host_key LIKE '%youtube-nocookie.com')"
        cur.execute(sql)
        rows = cur.fetchall()
        cookies = []
        for host_key, name, pathc, expires_utc, is_secure, encrypted_value in rows:
            # Decrypt
            try:
                value = None
                if encrypted_value and encrypted_value[:3] == b'v10':
                    # AES-GCM encrypted with profile key stored in Local State
                    try:
                        key = _get_local_state_key(db_path)
                    except Exception:
                        key = None
                    if key:
                        try:
                            dec = _aes_gcm_decrypt(encrypted_value[3:], key)
                            if dec is None:
                                # decryption failed for this cookie
                                continue
                            value = dec.decode('utf-8', errors='ignore')
                        except Exception:
                            continue
                    else:
                        # No key available; cannot decrypt v10 entries
                        continue
                else:
                    # Older DPAPI-encrypted value (directly decryptable)
                    dec = _dpapi_decrypt(encrypted_value)
                    if dec is None:
                        continue
                    value = dec.decode('utf-8', errors='ignore')

                expiry = _chrome_time_to_epoch(expires_utc)
                cookies.append((host_key, name, pathc, is_secure, expiry, value))
            except Exception:
                continue
        conn.close()
        os.unlink(tmp_db.name)
        if not cookies:
            return None
        # Write netscape cookie file
        cookiefile = tempfile.NamedTemporaryFile(delete=False, suffix='.cookies.txt')
        cookiefile.close()
        with open(cookiefile.name, 'w', encoding='utf-8') as f:
            f.write('# Netscape HTTP Cookie File
')
            for host_key, name, pathc, is_secure, expiry, value in cookies:
                domain = host_key
                flag = 'TRUE' if domain.startswith('.') else 'FALSE'
                secure = 'TRUE' if is_secure else 'FALSE'
                f.write(f"{domain}\t{flag}\t{pathc}\t{secure}\t{expiry}\t{name}\t{value}\n")
        return cookiefile.name
    except Exception:
        return None
