# Media integrations

The server uses `yt-dlp` for public media URLs, so the generic download API
supports supported URLs from YouTube, SoundCloud, Bandcamp, Twitch, TikTok,
and Instagram without separate downloader binaries. Submit them to
`POST /api/download` with a JSON body containing `url`, `format`, and the
desired download options.

Spotify uses the dedicated `POST /api/spotify/download` workflow. It supports
tracks, albums, playlists, and artists where public metadata is available.
Podcast imports should use the RSS episode URL or media enclosure URL through
the generic download API; RSS feed discovery can be added without changing
the downloader.

These services can change access rules or require cookies. The server reports
the source error instead of bypassing authentication or access controls.
