# Multimedia Handler documentation

`read.md` is the quick-start guide. This directory contains deeper reference
material for operating and extending the application.

- [API reference](api.md)
- [Architecture and directories](architecture.md)
- [Nginx deployment](nginx.md)
- [Troubleshooting](troubleshooting.md)
- [Extension development](extensions.md)
- [Media integrations](integrations.md)
- [Resource monitor](resource-monitor.md)
- [Security, backup, and recovery](operations.md)
