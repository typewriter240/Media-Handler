# Architecture and directory responsibilities

```text
Bot.py                 Core download and configuration logic
server.py              HTTP API, authentication, jobs, and static routing
config/                JSON runtime configuration and Nginx configuration
data/                  SQLite, state, history, cache, and failed-download data
web/                   Dashboard and browser-facing assets
modules/               Reusable application modules
scripts/               PowerShell operations and maintenance scripts
docs/                  Project documentation
extensions/            Optional browser and service integrations
downloads/             Generated media output
logs/                  Runtime logs
```

Keep generated data out of `modules`, `docs`, and `extensions`. Those
directories should remain portable and safe to back up with the source.

