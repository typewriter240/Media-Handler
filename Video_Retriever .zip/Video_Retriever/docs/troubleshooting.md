# Troubleshooting

## Dashboard does not load

Confirm `python .\server.py` is running, then check
`http://127.0.0.1:5000/api/health`. If Nginx is used, validate its upstream
address and firewall rule.

## Spotify returns HTTP 403

`Active premium subscription required for the owner of the app` is a Spotify
Web API entitlement restriction. The server automatically tries the public
Spotify metadata and YouTube matching fallback for supported links. Rotate
invalid or exposed credentials and use an eligible Spotify developer account.

## Extension reports the server is offline

Start the Python service, confirm the extension has permission to access
`localhost`, and reload the unpacked extension. The extension tries ports 5000
and 8000.

The remote-control extension also requires a logged-in dashboard session,
because pause, resume, and cancel endpoints require authentication.

## Downloads fail

Run `.\scripts\health-check.ps1` and verify `yt-dlp` and FFmpeg are available.
Review the failed-download data under `data\failed`.

## Album files are not grouped

Album jobs use Spotify's public album metadata to create a safe directory name
under `downloads\Spotify`. If metadata cannot be read, the server uses an
`album-<id>` directory so files are still isolated from other jobs.

If Spotify returns a 403 entitlement error, the fallback first searches with
the artist and title, then retries with the exact title alone. This handles
tracks whose YouTube listing is not indexed under the Spotify artist name
while still requiring strong title-token agreement before downloading.

## MP3 has no album cover

Artwork is attached to the MP3 as an ID3 picture stream. Confirm FFmpeg is on
`PATH` with `ffmpeg -version`, then inspect a file with:

```powershell
ffprobe -v error -select_streams v:0 `
  -show_entries stream=codec_name:stream_disposition=attached_pic `
  -of default=nw=1 .\downloads\Spotify\file.mp3
```

The expected result includes `DISPOSITION:attached_pic=1`.

For complete ID3 fields, install the Python metadata dependency:

```powershell
python -m pip install mutagen
```
