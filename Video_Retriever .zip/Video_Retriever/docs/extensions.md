# Extension development

Each integration belongs in its own directory under `extensions`, for example:

```text
extensions/
  youtube-bot-extension/
    manifest.json
    background.js
    content.js
    popup.html
    popup.js
    README.md
  remote-control-extension/
    manifest.json
    popup.html
    popup.js
    README.md
```

Extensions may call the authenticated local API, but must not contain API
secrets. Keep permissions narrow, validate all server responses, and document
installation and supported browsers in the extension's README.

To test the YouTube extension:

1. Open the browser extensions page.
2. Enable developer mode.
3. Choose **Load unpacked**.
4. Select `extensions\youtube-bot-extension`.
5. Start the Python server and reload the extension after source changes.

Nginx intentionally blocks direct `/extensions/` access. Browser extensions
are loaded from disk and do not need Nginx to serve their source files.

The bundled remote-control extension calls the existing authenticated pause,
resume, and cancel endpoints. It requires an active dashboard session cookie.
