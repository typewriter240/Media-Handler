# Nginx deployment

Use `config\nginx-video-retriever.conf` as the site configuration. Nginx serves
the dashboard page and static web assets directly; Python is used for the API,
authenticated downloads, proxy, and other dynamic routes. It serves
the `web` directory and proxies API, download, and generated-page requests to
the Python service.

1. Start `server.py` (it binds the backend to `0.0.0.0:5000` by default so Nginx
   can accept requests from other computers on the LAN).
2. Validate the configuration with `nginx -t -c <path-to-config>`.
3. Start or reload Nginx.
4. Open `http://Tobi-Benson/dashboard` or
   `http://172.20.10.6/dashboard` from another computer. The Nginx server block
   accepts the hostname and the host's current IPv4 interfaces; use the LAN
   address if the client cannot resolve the hostname.

The dashboard displays its current host URL dynamically from the browser
origin, so opening it through `http://172.20.10.6/dashboard` automatically
uses that host IP for API and dashboard links.

The networking graph uses Nginx's `X-Real-IP`/`X-Forwarded-For` headers to
identify each LAN client. Keep those proxy headers enabled when changing the
site configuration.

If Nginx is missing, `server.py` prints an installation prompt. On Windows,
run one of these in PowerShell:

```powershell
winget install --id=NGINX.NGINX -e
# or, with Chocolatey in an Administrator PowerShell:
choco install nginx -y
```

On Debian/Ubuntu:

```bash
sudo apt-get update && sudo apt-get install -y nginx
```

The configuration denies direct access to `config`, `data`, `logs`, `modules`,
`scripts`, and `extensions`. Keep this deny behavior unless a deliberately
authenticated download route is added.
