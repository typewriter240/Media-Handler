# Resource monitor

The dashboard includes a **Resource monitor** workspace that provides
Webmin-style read-only host telemetry:

- CPU utilization
- Memory utilization
- Disk utilization for the project volume
- Process count
- Hostname and platform

The endpoint is authenticated at `GET /api/resource-monitor`. It does not
provide arbitrary shell execution or process termination. Install the Python
dependency with `python -m pip install -r requirements.txt`, then restart the
server to enable CPU, memory, and process metrics.

On startup, the Python service also checks for `psutil` and runs
`python -m pip install psutil` automatically when it is missing. If automatic
installation is blocked, install it manually with the command above.

The service starts a non-blocking dependency audit in the background. It
compares packages listed in `requirements.txt` with the active Python
environment using `pip list --outdated`; results are available to authenticated
clients at `GET /api/dependencies/status`. The dashboard reports automatic
installations, missing packages, available updates, and audit failures. The
audit never upgrades packages automatically.

After updating the application, restart the existing Python process so the new
route is loaded. A request without a dashboard session returns `401
Authentication required`; that is expected.
