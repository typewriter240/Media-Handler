# Security, backup, and recovery

Prefer `SPOTIFY_CLIENT_ID`, `SPOTIFY_CLIENT_SECRET`, and the YouTube API key
through a protected environment or local secret store. Do not commit secrets
from `config\config.json`.

Use the supplied scripts:

```powershell
.\scripts\backup-data.ps1
.\scripts\validate-config.ps1
.\scripts\health-check.ps1
```

Back up `config`, `data`, and any required downloaded media. To recover,
restore configuration and data, run `setup.ps1`, validate the configuration,
and restart the Python service and Nginx.

# Local media playback

History entries with a managed file can be opened through the **Play in MPV**
button. The authenticated server launches `mpvnet` on Windows when available,
then falls back to `mpv`; Linux and macOS use `mpv`. Only files inside the
configured downloads directory are accepted.

If the player is not found, the playback action attempts an automatic
OS-specific install using an available package manager. If that is blocked,
install it manually and restart the server or add it to `PATH`:

- Windows: install mpv.net and ensure `mpvnet.exe` is available.
- Linux: `sudo apt install mpv`
- macOS: `brew install mpv`
