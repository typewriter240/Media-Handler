# API reference

The Python service listens on port `5000` by default. Nginx proxies `/api/`
requests to it. Authenticated endpoints require the session cookie created by
the dashboard login.

## Public diagnostics

| Method | Endpoint | Purpose |
| --- | --- | --- |
| GET | `/api/health` | Returns a lightweight health response |
| GET | `/api/auth/status` | Returns the current session state |

## Authenticated endpoints

| Method | Endpoint | Purpose |
| --- | --- | --- |
| POST | `/api/download` | Queue a YouTube download |
| GET | `/api/video/inspect?url=...` | Inspect a video |
| POST | `/api/video/analyze` | Start video analysis |
| POST | `/api/spotify/download` | Start a Spotify download |
| GET | `/api/spotify/jobs/{id}` | Read Spotify job status |
| GET | `/api/extensions/status` | Check the managed extension installation |

The browser extension uses `/download`, `/video/inspect`, and `/stats` through
its local API fallback list. Do not expose the Python port directly to the
internet; use firewall rules and Nginx access controls.

