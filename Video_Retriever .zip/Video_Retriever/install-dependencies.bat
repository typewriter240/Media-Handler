@echo off
setlocal

cd /d "%~dp0"
if errorlevel 1 (
    echo Failed to switch to the Video Retriever directory.
    exit /b 1
)

where python >nul 2>&1
if errorlevel 1 (
    echo Python was not found on PATH.
    echo Install Python 3.10 or newer and enable "Add Python to PATH".
    exit /b 1
)

echo Upgrading pip...
python -m pip install --upgrade pip
if errorlevel 1 (
    echo Failed to upgrade pip.
    exit /b 1
)

echo Installing Python packages from requirements.txt...
python -m pip install --upgrade -r requirements.txt
if errorlevel 1 (
    echo Failed to install one or more Python packages.
    exit /b 1
)

echo.
echo Python dependencies installed successfully.
echo FFmpeg is required separately and must be available on PATH.
echo Verify it with: ffmpeg -version
exit /b 0
