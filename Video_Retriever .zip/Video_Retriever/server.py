import argparse
import csv
import io
import ipaddress
import os
import re
import json
import difflib
import mimetypes
import threading
import subprocess
import shlex
import shutil
import socket
import socketserver
import urllib.request
import urllib.error
import html
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer, HTTPServer
import uuid
import time
import base64
import tempfile
import secrets
import hashlib
import sqlite3
import sys
import platform
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FuturesTimeoutError
from collections import deque
from importlib import metadata as importlib_metadata
from contextlib import contextmanager
from urllib.parse import urlparse, unquote, parse_qs, quote, urljoin
from pathlib import Path
from typing import Optional
AUTO_INSTALL_EVENTS = []
try:
    import psutil
except ImportError:
    psutil = None
try:
    import wmi
except ImportError:
    wmi = None

RESOURCE_WMI_LOCK = threading.Lock()
RESOURCE_WMI_CACHE = None
RESOURCE_WMI_REFRESHING = False


def ensure_psutil() -> bool:
    """Install psutil with this interpreter when Resource monitor support is missing."""
    global psutil
    if psutil is not None:
        return True
    print('Resource monitor dependency psutil is missing; installing it with Python...')
    try:
        subprocess.run(
            [sys.executable, '-m', 'pip', 'install', '--disable-pip-version-check', 'psutil'],
            cwd=str(WORKSPACE_ROOT),
            check=True,
            timeout=300,
            shell=False,
        )
        import psutil as installed_psutil
        psutil = installed_psutil
        AUTO_INSTALL_EVENTS.append({'package': 'psutil', 'version': psutil.__version__, 'installed_at': time.time()})
        print(f'psutil installed: {psutil.__version__}')
        return True
    except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired, ImportError) as exc:
        print(f'Unable to install psutil automatically: {exc}')
        return False


try:
    from mutagen.id3 import (
        APIC,
        COMM,
        TALB,
        TBPM,
        TCOM,
        TDRC,
        TIT2,
        TPE1,
        TPE2,
        TPOS,
        TRCK,
        TSRC,
        TXXX,
        ID3,
        ID3NoHeaderError,
    )
except ImportError:
    APIC = COMM = TALB = TBPM = TCOM = TDRC = TIT2 = TPE1 = TPE2 = TPOS = TRCK = TSRC = TXXX = ID3 = ID3NoHeaderError = None

from Bot import (
    load_config,
    load_history,
    save_history,
    extract_playlist_videos,
    ensure_output_directory,
    download_videos,
    adaptive_bandwidth_limit,
    get_dashboard_data,
    WORKSPACE_ROOT,
    ensure_server_directories,
    extract_video_intelligence,
    normalize_video_url,
    fetch_youtube_video_metadata,
    search_youtube_video_candidates,
    get_video_id_from_url,
    get_all_download_progress,
    set_download_progress,
    download_cancel_requested,
    clear_download_progress,
    resolve_configured_directory,
    ensure_configured_directories,
    LOCKOFF_MODE,
    LOCKOFF_MESSAGE,
)
ensure_psutil()

DEPENDENCY_STATUS = {
    'state': 'pending',
    'checked_at': None,
    'outdated': [],
    'missing': [],
    'error': None,
    'install_events': AUTO_INSTALL_EVENTS,
}
DEPENDENCY_STATUS_LOCK = threading.Lock()


def record_install_event(package: str, version: str) -> None:
    with DEPENDENCY_STATUS_LOCK:
        DEPENDENCY_STATUS['install_events'].append({
            'package': package,
            'version': version,
            'installed_at': time.time(),
        })


def audit_python_dependencies() -> None:
    """Check requirements against PyPI without changing installed packages."""
    requirements_path = Path(WORKSPACE_ROOT) / 'requirements.txt'
    try:
        packages = []
        for line in requirements_path.read_text(encoding='utf-8').splitlines():
            requirement = line.split('#', 1)[0].strip()
            if requirement and not requirement.startswith(('-', 'git+', 'http')):
                packages.append(re.split(r'[<>=!~;\[]', requirement, maxsplit=1)[0].strip())
        installed = subprocess.run(
            [sys.executable, '-m', 'pip', 'list', '--outdated', '--format=json'],
            cwd=str(WORKSPACE_ROOT), capture_output=True, text=True,
            encoding='utf-8', errors='replace', timeout=180, check=True, shell=False,
        )
        outdated_items = json.loads(installed.stdout or '[]')
        required_names = {package.lower().replace('_', '-') for package in packages}
        outdated = [
            item for item in outdated_items
            if str(item.get('name', '')).lower().replace('_', '-') in required_names
        ]
        missing = []
        for package in packages:
            try:
                importlib_metadata.version(package)
            except importlib_metadata.PackageNotFoundError:
                missing.append(package)
        with DEPENDENCY_STATUS_LOCK:
            DEPENDENCY_STATUS.update({
                'state': 'complete',
                'checked_at': time.time(),
                'outdated': outdated,
                'missing': missing,
                'error': None,
            })
    except (OSError, subprocess.SubprocessError, ValueError) as exc:
        with DEPENDENCY_STATUS_LOCK:
            DEPENDENCY_STATUS.update({
                'state': 'error',
                'checked_at': time.time(),
                'error': str(exc),
            })


def update_python_dependencies(packages: list[str]) -> dict:
    """Upgrade only packages reported by the latest dependency audit."""
    with DEPENDENCY_STATUS_LOCK:
        allowed = {
            str(item.get('name', '')).strip()
            for item in DEPENDENCY_STATUS.get('outdated', [])
            if item.get('name')
        }
    selected = sorted({package for package in packages if package in allowed})
    if not selected:
        raise ValueError('No audited outdated packages were selected')
    result = subprocess.run(
        [sys.executable, '-m', 'pip', 'install', '--upgrade', *selected],
        cwd=str(WORKSPACE_ROOT), capture_output=True, text=True,
        encoding='utf-8', errors='replace', timeout=600, shell=False,
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or 'pip returned a non-zero exit code').strip()
        raise RuntimeError(detail[-2000:])
    audit_python_dependencies()
    return {'updated': selected, 'output': (result.stdout or '').strip()[-2000:]}


threading.Thread(target=audit_python_dependencies, name='dependency-audit', daemon=True).start()
# Opera cookie helper (extracts Opera GX cookies to Netscape cookies.txt)
try:
    from opera_cookies import export_opera_cookies_netscape
except Exception:
    export_opera_cookies_netscape = None

def detect_private_ip() -> str:
    """Return the machine's preferred private IPv4 address, falling back to a non-loopback bind."""
    candidates = []

    try:
        hostname = socket.gethostname()
        for family, _, _, _, sockaddr in socket.getaddrinfo(hostname, None, type=socket.SOCK_DGRAM):
            if family == socket.AF_INET:
                addr = sockaddr[0]
                if addr and addr != '127.0.0.1':
                    candidates.append(addr)
    except Exception:
        pass

    try:
        for entry in socket.gethostbyname_ex(socket.gethostname())[2]:
            if entry and entry != '127.0.0.1':
                candidates.append(entry)
    except Exception:
        pass

    for addr in candidates:
        try:
            ip_obj = ipaddress.ip_address(addr)
            if ip_obj.is_private and not ip_obj.is_loopback:
                return str(ip_obj)
        except ValueError:
            continue

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect(('8.8.8.8', 80))
            detected = sock.getsockname()[0]
            if detected and detected != '127.0.0.1':
                return detected
    except Exception:
        pass

    raise RuntimeError('Unable to determine a non-loopback host IP for the API server.')


raw_host = os.environ.get('VIDEO_RETRIEVER_HOST')
if raw_host in (None, ''):
    HOST = detect_private_ip()
elif raw_host in ('localhost', '127.0.0.1', '::1'):
    HOST = detect_private_ip()
else:
    HOST = raw_host
PORT = int(os.environ.get('VIDEO_RETRIEVER_PORT', '5000'))
PORTS = tuple(dict.fromkeys(
    [PORT]
    + [int(value.strip()) for value in os.environ.get(
        'VIDEO_RETRIEVER_PORTS', '5001,5002,5003,5004'
    ).split(',') if value.strip()]
))
NGINX_SOCKET_PATH = os.environ.get('VIDEO_RETRIEVER_NGINX_SOCKET')
AUTH_USER = os.environ.get('VIDEO_RETRIEVER_ADMIN_USER', 'admin')
AUTH_PASSWORD = os.environ.get('VIDEO_RETRIEVER_ADMIN_PASSWORD', '')
ROOT_USER = os.environ.get('VIDEO_RETRIEVER_ROOT_USER', 'root')
ROOT_PASSWORD = os.environ.get('VIDEO_RETRIEVER_ROOT_PASSWORD') or 'password'
SESSION_COOKIE_NAME = 'video_retriever_session'
ROOT_SESSION_COOKIE_NAME = 'video_retriever_root_session'
STORAGE_ROOT = Path(WORKSPACE_ROOT) / 'data'
SQL_DIRECTORY = STORAGE_ROOT / 'sql'
ACCOUNT_STORE = STORAGE_ROOT / '.video_retriever_accounts.json'
ACCOUNT_DATABASE = SQL_DIRECTORY / '.video_retriever_accounts.sqlite3'
DEVICE_POLICY_STORE = STORAGE_ROOT / '.video_retriever_device_policies.json'
for _managed_path, _legacy_path in (
    (ACCOUNT_DATABASE, Path(WORKSPACE_ROOT) / '.video_retriever_accounts.sqlite3'),
    (DEVICE_POLICY_STORE, Path(WORKSPACE_ROOT) / '.video_retriever_device_policies.json'),
):
    _managed_path.parent.mkdir(parents=True, exist_ok=True)
    if not _managed_path.exists() and _legacy_path.exists():
        shutil.copy2(_legacy_path, _managed_path)
ACCOUNT_HASH_ITERATIONS = 240000
AUTH_SESSIONS = {}
AUTH_LOCAL_SESSIONS = {}
ROOT_ACTIVE_TOKEN = None
AUTH_SESSIONS_LOCK = threading.Lock()
PROXY_CONTEXTS = {}
PROXY_CONTEXTS_LOCK = threading.Lock()
TRUSTED_SUBNET = os.environ.get('VIDEO_RETRIEVER_TRUSTED_SUBNET', '172.20.10.0/24')
CONNECTED_DEVICES = {}
CONNECTED_DEVICES_LOCK = threading.Lock()
SPOTIFY_JOBS = {}
SPOTIFY_JOBS_LOCK = threading.Lock()
DOWNLOAD_ANALYTICS = deque(maxlen=180)
DOWNLOAD_ANALYTICS_LOCK = threading.Lock()
DOWNLOAD_ANALYTICS_COMPLETED = 0
ROOT_LOGIN_IP_LOG_LOCK = threading.Lock()
LOGIN_RATE_LIMIT_LOCK = threading.Lock()
LOGIN_FAILURES = {}
LOGIN_MAX_FAILURES = 5
LOGIN_WINDOW_SECONDS = 900
LOGIN_LOCKOUT_SECONDS = 300


def _load_json_store(path: Path, default):
    try:
        with path.open('r', encoding='utf-8') as stream:
            value = json.load(stream)
        return value if isinstance(value, type(default)) else default
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        print(f'Unable to load {path.name}: {exc}')
        return default


def _save_json_store(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    with temporary.open('w', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
    os.replace(temporary, path)


def _hash_account_password(password: str, salt: Optional[bytes] = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac(
        'sha256', password.encode('utf-8'), salt, ACCOUNT_HASH_ITERATIONS
    )
    return f'{ACCOUNT_HASH_ITERATIONS}${base64.urlsafe_b64encode(salt).decode()}${base64.urlsafe_b64encode(digest).decode()}'


def _verify_account_password(password: str, encoded: str) -> bool:
    try:
        iterations, salt_text, digest_text = encoded.split('$', 2)
        salt = base64.urlsafe_b64decode(salt_text.encode())
        expected = base64.urlsafe_b64decode(digest_text.encode())
        actual = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, int(iterations))
        return secrets.compare_digest(actual, expected)
    except (TypeError, ValueError):
        return False


@contextmanager
def _account_database():
    ACCOUNT_DATABASE.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(str(ACCOUNT_DATABASE))
    try:
        connection.execute(
            '''
            CREATE TABLE IF NOT EXISTS accounts (
                username TEXT PRIMARY KEY,
                password_hash TEXT NOT NULL,
                permissions TEXT NOT NULL,
                created_at REAL NOT NULL,
                creator_ip TEXT NOT NULL DEFAULT '',
                creator_hostname TEXT NOT NULL DEFAULT ''
            )
                '''
        )
        connection.execute(
                '''
                CREATE TABLE IF NOT EXISTS dashboard_preferences (
                    username TEXT PRIMARY KEY,
                    preferences TEXT NOT NULL,
                    updated_at REAL NOT NULL
                )
                '''
        )
        connection.execute(
                '''
                CREATE TABLE IF NOT EXISTS activity_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL,
                    action TEXT NOT NULL,
                    details TEXT NOT NULL DEFAULT '',
                    created_at REAL NOT NULL
                )
                '''
        )
        columns = {row[1] for row in connection.execute('PRAGMA table_info(accounts)')}
        if 'creator_ip' not in columns:
            connection.execute("ALTER TABLE accounts ADD COLUMN creator_ip TEXT NOT NULL DEFAULT ''")
        if 'creator_hostname' not in columns:
            connection.execute("ALTER TABLE accounts ADD COLUMN creator_hostname TEXT NOT NULL DEFAULT ''")
        connection.commit()
        yield connection
    finally:
        connection.close()


def _account_records() -> dict:
    with _account_database() as connection:
        rows = connection.execute(
            'SELECT username, password_hash, permissions, created_at, creator_ip, creator_hostname FROM accounts'
        ).fetchall()
    records = {}
    for username, password_hash, permissions, created_at, creator_ip, creator_hostname in rows:
        try:
            permission_list = json.loads(permissions)
        except (TypeError, ValueError):
            permission_list = ['view']
        records[username] = {
            'password_hash': password_hash,
            'permissions': permission_list if isinstance(permission_list, list) else ['view'],
            'created_at': created_at,
            'creator_ip': creator_ip,
            'creator_hostname': creator_hostname,
        }
    return records


def _migrate_account_store() -> None:
    legacy = _load_json_store(ACCOUNT_STORE, {})
    if not legacy or not isinstance(legacy, dict):
        return
    with _account_database() as connection:
        for username, record in legacy.items():
            if not isinstance(record, dict) or not record.get('password_hash'):
                continue
            connection.execute(
                '''
                INSERT OR IGNORE INTO accounts
                    (username, password_hash, permissions, created_at, creator_ip, creator_hostname)
                VALUES (?, ?, ?, ?, ?, ?)
                ''',
                (
                    username,
                    record['password_hash'],
                    json.dumps(record.get('permissions', ['view'])),
                    float(record.get('created_at', time.time())),
                    record.get('creator_ip', ''),
                    record.get('creator_hostname', ''),
                ),
            )
        connection.commit()


_migrate_account_store()


def _dashboard_username(handler: BaseHTTPRequestHandler) -> Optional[str]:
    return session_user(handler) or request_client_ip(handler)


def record_activity(handler: BaseHTTPRequestHandler, action: str, details: str = '') -> None:
    username = _dashboard_username(handler)
    if not username:
        return
    try:
        with _account_database() as connection:
            connection.execute(
                'INSERT INTO activity_log (username, action, details, created_at) VALUES (?, ?, ?, ?)',
                (username, str(action)[:80], str(details)[:1000], time.time()),
            )
            connection.commit()
    except sqlite3.Error as exc:
        print(f'Unable to record activity: {exc}')


def dashboard_preferences(handler: BaseHTTPRequestHandler) -> dict:
    username = _dashboard_username(handler)
    if not username:
        return {}
    with _account_database() as connection:
        row = connection.execute(
            'SELECT preferences FROM dashboard_preferences WHERE username = ?', (username,)
        ).fetchone()
    if not row:
        return {}
    try:
        value = json.loads(row[0])
    except (TypeError, ValueError):
        return {}
    return value if isinstance(value, dict) else {}


def save_dashboard_preferences(handler: BaseHTTPRequestHandler, preferences: dict) -> dict:
    username = _dashboard_username(handler)
    if not username:
        raise ValueError('Authentication is required')
    allowed = {'theme', 'remote_mode', 'history_query', 'history_status', 'active_view', 'theme_preset', 'custom_colors'}
    clean = {key: preferences[key] for key in allowed if key in preferences}
    if not isinstance(clean.get('theme', 'dark'), str) or clean.get('theme', 'dark') not in ('dark', 'light'):
        raise ValueError('Theme must be dark or light')
    preset = clean.get('theme_preset', 'classic')
    valid_presets = {'classic', 'midnight-red', 'electric-blue', 'forest', 'sunset'}
    if not isinstance(preset, str) or preset not in valid_presets:
        raise ValueError('Theme preset is invalid')
    custom_colors = clean.get('custom_colors', {})
    if custom_colors is not None and not isinstance(custom_colors, dict):
        raise ValueError('Custom colors must be an object')
    if isinstance(custom_colors, dict):
        cleaned_colors = {}
        for key, value in custom_colors.items():
            if key in {'primary', 'secondary', 'background', 'surface', 'text'} and isinstance(value, str):
                cleaned_colors[key] = value
        clean['custom_colors'] = cleaned_colors
    with _account_database() as connection:
        connection.execute(
            '''
            INSERT INTO dashboard_preferences (username, preferences, updated_at)
            VALUES (?, ?, ?)
            ON CONFLICT(username) DO UPDATE SET preferences=excluded.preferences, updated_at=excluded.updated_at
            ''',
            (username, json.dumps(clean), time.time()),
        )
        connection.commit()
    return clean


def activity_records(handler: BaseHTTPRequestHandler, limit: int = 100) -> list[dict]:
    username = _dashboard_username(handler)
    if not username:
        return []
    limit = max(1, min(500, int(limit)))
    with _account_database() as connection:
        rows = connection.execute(
            '''
            SELECT action, details, created_at FROM activity_log
            WHERE username = ? ORDER BY created_at DESC LIMIT ?
            ''',
            (username, limit),
        ).fetchall()
    return [
        {'action': action, 'details': details, 'created_at': created_at}
        for action, details, created_at in rows
    ]


def download_analytics_snapshot() -> dict:
    global DOWNLOAD_ANALYTICS_COMPLETED
    progress = get_all_download_progress()
    now = time.time()
    terminal_statuses = {'completed', 'finished', 'failed', 'error', 'cancelled'}
    active = sum(
        1 for item in progress.values()
        if str(item.get('status', '')).lower() not in terminal_statuses
    )
    queued = sum(
        1 for item in progress.values()
        if str(item.get('status', '')).lower() in ('queued', 'pending')
    )
    with DOWNLOAD_ANALYTICS_LOCK:
        completed = DOWNLOAD_ANALYTICS_COMPLETED
        DOWNLOAD_ANALYTICS.append({
            'timestamp': now,
            'active': active,
            'completed': completed,
            'queued': queued,
        })
        samples = list(DOWNLOAD_ANALYTICS)
    return {'current': {'active': active, 'completed': completed}, 'samples': samples}


def finish_download_tracking(progress_id: Optional[str], status: str, title: str = '') -> None:
    global DOWNLOAD_ANALYTICS_COMPLETED
    if not progress_id:
        return
    if status in ('completed', 'finished'):
        with DOWNLOAD_ANALYTICS_LOCK:
            DOWNLOAD_ANALYTICS_COMPLETED += 1
    progress = get_all_download_progress()
    progress.pop(progress_id, None)
    try:
        progress_path = resolve_configured_directory(
            load_config().get('state_directory'),
            './data/state',
        ) / 'download_progress.json'
        progress_path.parent.mkdir(parents=True, exist_ok=True)
        progress_path.write_text(json.dumps(progress, indent=2), encoding='utf-8')
    except OSError as exc:
        print(f'Unable to clear download tracking for {title or progress_id}: {exc}')


def _device_policies() -> dict:
    return _load_json_store(DEVICE_POLICY_STORE, {})


def _account_permissions(username: Optional[str]) -> set:
    if not username:
        return set()
    if username in (ROOT_USER, AUTH_USER):
        return {'view', 'control', 'audit'}
    record = _account_records().get(username, {})
    permissions = set(record.get('permissions', ['view']))
    if 'download' in permissions or 'operate' in permissions:
        permissions.discard('download')
        permissions.discard('operate')
        permissions.add('control')
    return permissions


def _device_permission(handler: BaseHTTPRequestHandler) -> str:
    return _device_policies().get(request_client_ip(handler), 'view')


def create_account(handler: BaseHTTPRequestHandler, payload: dict) -> tuple[bool, str]:
    username = str(payload.get('username', '')).strip()
    password = str(payload.get('password', ''))
    if not re.fullmatch(r'[A-Za-z0-9_.-]{3,32}', username):
        return False, 'Username must be 3-32 characters using letters, numbers, dot, dash, or underscore'
    if len(password) < 8:
        return False, 'Password must be at least 8 characters'
    if username in (ROOT_USER, AUTH_USER) or username.lower().startswith('guest-'):
        return False, 'That username is reserved'
    with _account_database() as connection:
        exists = connection.execute(
            'SELECT 1 FROM accounts WHERE username = ?', (username,)
        ).fetchone()
    if exists:
        return False, 'An account with that username already exists'
    try:
        with _account_database() as connection:
            connection.execute(
                '''
                INSERT INTO accounts
                    (username, password_hash, permissions, created_at, creator_ip, creator_hostname)
                VALUES (?, ?, ?, ?, ?, ?)
                ''',
                (
                    username, _hash_account_password(password), json.dumps(['view']), time.time(),
                    request_client_ip(handler), socket.getfqdn(request_client_ip(handler)),
                ),
            )
            connection.commit()
    except sqlite3.IntegrityError:
        return False, 'An account with that username already exists'
    return True, username


def account_audit_records() -> list:
    return [
        {
            'username': username,
            'permissions': sorted(_account_permissions(username)),
            'created_at': record.get('created_at'),
            'creator_ip': record.get('creator_ip', ''),
            'creator_hostname': record.get('creator_hostname', ''),
        }
        for username, record in _account_records().items()
    ]


def update_account_permissions(handler: BaseHTTPRequestHandler, payload: dict) -> None:
    if not is_root_session(handler):
        send_json_response(handler, 403, {'error': 'Root access required'})
        return
    username = str(payload.get('username', '')).strip()
    requested = payload.get('permissions', [])
    permissions = sorted(set(requested) if isinstance(requested, list) else [])
    if username in (ROOT_USER, AUTH_USER) or username.lower().startswith('guest-'):
        send_json_response(handler, 400, {'error': 'This account cannot be managed here'})
        return
    if not permissions or not set(permissions).issubset({'view', 'control', 'audit'}):
        send_json_response(handler, 400, {'error': 'Permissions must use view, control, or audit'})
        return
    with _account_database() as connection:
        updated = connection.execute(
            'UPDATE accounts SET permissions = ? WHERE username = ?',
            (json.dumps(permissions), username),
        ).rowcount
        connection.commit()
    if not updated:
        send_json_response(handler, 404, {'error': 'Account not found'})
        return
    send_json_response(handler, 200, {'updated': True, 'username': username, 'permissions': permissions})


def auth_password_configured() -> bool:
    return bool(AUTH_PASSWORD or ROOT_PASSWORD)


def session_user(handler: BaseHTTPRequestHandler) -> Optional[str]:
    cookies = handler.headers.get('Cookie', '')
    match = re.search(rf'(?:^|;\s*){re.escape(SESSION_COOKIE_NAME)}=([^;]+)', cookies)
    if match:
        with AUTH_SESSIONS_LOCK:
            return AUTH_SESSIONS.get(match.group(1))
    root_match = re.search(rf'(?:^|;\s*){re.escape(ROOT_SESSION_COOKIE_NAME)}=([^;]+)', cookies)
    if not root_match:
        return None
    with AUTH_SESSIONS_LOCK:
        user = AUTH_SESSIONS.get(root_match.group(1))
        return user if user == ROOT_USER else None


def request_client_ip(handler: BaseHTTPRequestHandler) -> str:
    peer_ip = handler.client_address[0]
    if ipaddress.ip_address(peer_ip).is_loopback:
        forwarded = handler.headers.get('X-Real-IP', '').strip()
        if forwarded:
            return forwarded
    return peer_ip


def root_login_ip_log_path() -> Path:
    return resolve_configured_directory(
        load_config().get('logs_directory'),
        './logs',
    ) / 'root_login_ips.log'


def record_root_login_ip(handler: BaseHTTPRequestHandler) -> None:
    client_ip = request_client_ip(handler)
    try:
        hostname = socket.gethostbyaddr(client_ip)[0]
    except (socket.herror, socket.gaierror, ValueError):
        hostname = client_ip
    entry = {
        'timestamp': time.strftime('%Y-%m-%dT%H:%M:%S%z', time.localtime()),
        'ip': client_ip,
        'hostname': hostname,
    }
    try:
        log_path = root_login_ip_log_path()
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with ROOT_LOGIN_IP_LOG_LOCK:
            with log_path.open('a', encoding='utf-8') as stream:
                stream.write(json.dumps(entry, ensure_ascii=True) + '\n')
    except OSError as exc:
        print(f'Unable to record root login IP in {root_login_ip_log_path()}: {exc}')


def login_rate_limit_key(handler: BaseHTTPRequestHandler, username: str) -> tuple[str, str]:
    return request_client_ip(handler), username.strip().lower()


def login_is_locked_out(handler: BaseHTTPRequestHandler, username: str) -> int:
    now = time.time()
    key = login_rate_limit_key(handler, username)
    with LOGIN_RATE_LIMIT_LOCK:
        record = LOGIN_FAILURES.get(key)
        if not record:
            return 0
        if now >= record.get('expires_at', 0):
            LOGIN_FAILURES.pop(key, None)
            return 0
        return max(1, int(record['expires_at'] - now))


def record_login_failure(handler: BaseHTTPRequestHandler, username: str) -> None:
    now = time.time()
    key = login_rate_limit_key(handler, username)
    with LOGIN_RATE_LIMIT_LOCK:
        record = LOGIN_FAILURES.get(key, {'count': 0, 'first_seen': now})
        if now - record.get('first_seen', now) > LOGIN_WINDOW_SECONDS:
            record = {'count': 0, 'first_seen': now}
        record['count'] += 1
        if record['count'] >= LOGIN_MAX_FAILURES:
            record['expires_at'] = now + LOGIN_LOCKOUT_SECONDS
        LOGIN_FAILURES[key] = record


def clear_login_failures(handler: BaseHTTPRequestHandler, username: str) -> None:
    with LOGIN_RATE_LIMIT_LOCK:
        LOGIN_FAILURES.pop(login_rate_limit_key(handler, username), None)


def is_local_host_request(handler: BaseHTTPRequestHandler) -> bool:
    try:
        client_ip = ipaddress.ip_address(request_client_ip(handler))
        if client_ip.is_loopback:
            return True
        host_ip = ipaddress.ip_address(HOST)
        return client_ip == host_ip
    except ValueError:
        return False


def is_root_session(handler: BaseHTTPRequestHandler) -> bool:
    cookies = handler.headers.get('Cookie', '')
    token = re.search(rf'(?:^|;\s*){re.escape(ROOT_SESSION_COOKIE_NAME)}=([^;]+)', cookies)
    if not token:
        return False
    regular_token = re.search(rf'(?:^|;\s*){re.escape(SESSION_COOKIE_NAME)}=([^;]+)', cookies)
    if regular_token and regular_token.group(1) != token.group(1):
        return False
    with AUTH_SESSIONS_LOCK:
        session_token = token.group(1)
        return (
            AUTH_SESSIONS.get(session_token) == ROOT_USER
            and AUTH_LOCAL_SESSIONS.get(session_token, False)
        )


def require_auth(handler: BaseHTTPRequestHandler, permission: Optional[str] = None) -> bool:
    if not auth_password_configured():
        send_json_response(handler, 503, {'error': 'Authentication is not configured. Set VIDEO_RETRIEVER_ADMIN_PASSWORD or VIDEO_RETRIEVER_ROOT_PASSWORD.'})
        return False
    user = session_user(handler)
    if user:
        granted = _account_permissions(user)
        device_level = _device_permission(handler)
        levels = {'view': 0, 'download': 1, 'control': 1, 'operate': 2, 'audit': 0}
        effective_level = max(
            max((levels.get(item, 0) for item in granted), default=0),
            levels.get(device_level, 0),
        )
        if permission and effective_level < levels.get(permission, 0):
            if permission == 'download':
                send_json_response(handler, 403, {'error': 'Download permission is not enabled for this device'})
                return False
            if permission == 'operate':
                send_json_response(handler, 403, {'error': 'Operator permission is required'})
                return False
        return True
    send_json_response(handler, 401, {'error': 'Authentication required'})
    return False


def record_connected_device(handler: BaseHTTPRequestHandler) -> None:
    ip = request_client_ip(handler)
    now = time.time()
    # Reverse DNS can block every API request on isolated LANs. The address
    # itself is the reliable device identity; resolve names outside the request path.
    hostname = ip
    with CONNECTED_DEVICES_LOCK:
        existing = CONNECTED_DEVICES.get(ip, {})
        CONNECTED_DEVICES[ip] = {
            'ip': ip,
            'hostname': hostname,
            'first_seen': existing.get('first_seen', now),
            'last_seen': now,
            'downloads': existing.get('downloads', 0),
        }


def scan_nearby_devices() -> list[dict]:
    """Read the host ARP cache to identify nearby LAN devices without probing them."""
    try:
        result = subprocess.run(
            ['arp', '-a'],
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace',
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise RuntimeError(f'Unable to read the local ARP table: {exc}') from exc
    devices = {}
    hostname_candidates = {}
    pattern = re.compile(r'(?P<ip>\d{1,3}(?:\.\d{1,3}){3})\s+(?P<mac>[0-9a-f-]{11,17})\s+(?P<type>dynamic|static)', re.IGNORECASE)
    for match in pattern.finditer(result.stdout or ''):
        ip = match.group('ip')
        try:
            address = ipaddress.ip_address(ip)
        except ValueError:
            continue
        if (
            not address.is_private
            or address.is_loopback
            or address.is_multicast
            or address.is_unspecified
            or address.is_reserved
            or address == ipaddress.IPv4Address('255.255.255.255')
            or address.packed[-1] == 255
        ):
            continue
        with CONNECTED_DEVICES_LOCK:
            known_device = CONNECTED_DEVICES.get(ip, {})
        hostname = str(known_device.get('hostname') or '')
        devices[ip] = {
            'ip': ip,
            'hostname': hostname or ip,
            'mac': match.group('mac').replace('-', ':').lower(),
            'entry_type': match.group('type').lower(),
            'source': 'arp',
        }
        if not hostname or hostname == ip:
            hostname_candidates[ip] = ip
    if hostname_candidates:
        def resolve_hostname(ip: str) -> tuple[str, str]:
            try:
                dns_lookup = subprocess.run(
                    ['nslookup', '-timeout=1', '-retry=0', ip],
                    capture_output=True,
                    text=True,
                    encoding='utf-8',
                    errors='replace',
                    timeout=2,
                    check=False,
                )
                match = re.search(r'^\s*Name:\s*([^\s]+)', dns_lookup.stdout or '', re.IGNORECASE | re.MULTILINE)
                if match and match.group(1) != ip:
                    return ip, match.group(1).rstrip('.')
            except (OSError, subprocess.SubprocessError):
                pass
            try:
                ping = subprocess.run(
                    ['ping', '-a', '-n', '1', '-w', '700', ip],
                    capture_output=True,
                    text=True,
                    encoding='utf-8',
                    errors='replace',
                    timeout=2,
                    check=False,
                )
                match = re.search(r'Pinging\s+([^\s\[]+)\s+\[' + re.escape(ip) + r'\]', ping.stdout or '', re.IGNORECASE)
                if match and match.group(1) != ip:
                    return ip, match.group(1)
            except (OSError, subprocess.SubprocessError):
                pass
            try:
                netbios = subprocess.run(
                    ['nbtstat', '-A', ip],
                    capture_output=True,
                    text=True,
                    encoding='utf-8',
                    errors='replace',
                    timeout=2,
                    check=False,
                )
                match = re.search(r'^\s*([A-Za-z0-9_.-]+)\s+<00>\s+UNIQUE', netbios.stdout or '', re.IGNORECASE | re.MULTILINE)
                if match:
                    return ip, match.group(1)
            except (OSError, subprocess.SubprocessError):
                pass
            return ip, ip
        executor = ThreadPoolExecutor(max_workers=min(8, len(hostname_candidates)))
        try:
            futures = [executor.submit(resolve_hostname, ip) for ip in hostname_candidates.values()]
            for future in as_completed(futures, timeout=3):
                ip, hostname = future.result()
                if hostname != ip:
                    devices[ip]['hostname'] = hostname
        except FuturesTimeoutError:
            # Keep unresolved addresses; the scan remains useful without DNS.
            pass
        finally:
            executor.shutdown(wait=False, cancel_futures=True)
    return sorted(devices.values(), key=lambda item: tuple(int(part) for part in item['ip'].split('.')))


def record_device_download(handler: BaseHTTPRequestHandler) -> None:
    ip = request_client_ip(handler)
    with CONNECTED_DEVICES_LOCK:
        device = CONNECTED_DEVICES.get(ip)
        if device:
            device['downloads'] = int(device.get('downloads', 0)) + 1


def _refresh_wmi_metrics() -> None:
    global RESOURCE_WMI_CACHE, RESOURCE_WMI_REFRESHING
    try:
        wmi_script = (
            'import json, pythoncom, wmi; '
            'pythoncom.CoInitialize(); '
            'client=wmi.WMI(); '
            'processors=[float(item.LoadPercentage) for item in client.Win32_Processor() if item.LoadPercentage is not None]; '
            'systems=list(client.Win32_OperatingSystem()); '
            'system=systems[0] if systems else None; '
            'memory=(((1-(float(system.FreePhysicalMemory)/float(system.TotalVisibleMemorySize)))*100) '
            'if system and float(system.TotalVisibleMemorySize)>0 else None); '
            'disks=[item for item in client.Win32_LogicalDisk() if str(item.DeviceID).rstrip(":").upper()=='
            f'{WORKSPACE_ROOT.drive.rstrip(":").upper()!r}]; '
            'disk=disks[0] if disks else None; '
            'disk_used=((1-(float(disk.FreeSpace)/float(disk.Size)))*100 '
            'if disk and float(disk.Size or 0)>0 else None); '
            'print(json.dumps({"cpu":processors,"memory":memory,"processes":len(client.Win32_Process()),"disk":disk_used}))'
        )
        result = subprocess.run(
            [sys.executable, '-c', wmi_script],
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace',
            timeout=5,
            check=False,
        )
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or 'WMI helper failed')
        metrics = json.loads(result.stdout)
        with RESOURCE_WMI_LOCK:
            RESOURCE_WMI_CACHE = metrics
    except (OSError, subprocess.SubprocessError, RuntimeError, ValueError, KeyError, json.JSONDecodeError):
        with RESOURCE_WMI_LOCK:
            RESOURCE_WMI_CACHE = None
    finally:
        with RESOURCE_WMI_LOCK:
            RESOURCE_WMI_REFRESHING = False


def _start_wmi_refresh() -> None:
    global RESOURCE_WMI_REFRESHING
    with RESOURCE_WMI_LOCK:
        if RESOURCE_WMI_REFRESHING:
            return
        RESOURCE_WMI_REFRESHING = True
    threading.Thread(target=_refresh_wmi_metrics, name='resource-wmi-refresh', daemon=True).start()


def resource_monitor_snapshot() -> dict:
    """Return safe host resource metrics for the authenticated monitor."""
    disk = shutil.disk_usage(str(WORKSPACE_ROOT))
    source_values = {
        'cpu_percent': [],
        'memory_used_percent': [],
        'disk_used_percent': [],
        'process_count': [],
    }
    snapshot = {
        'timestamp': time.time(),
        'hostname': socket.getfqdn(),
        'platform': platform.platform(),
        'cpu_count': os.cpu_count() or 1,
        'disk': {
            'total_bytes': disk.total,
            'used_bytes': disk.used,
            'free_bytes': disk.free,
            'used_percent': round((disk.used / disk.total) * 100, 1) if disk.total else 0,
        },
        'memory': None,
        'cpu_percent': None,
        'process_count': None,
        'load_average': None,
        'monitoring_sources': [],
    }
    if psutil is not None:
        memory = psutil.virtual_memory()
        snapshot['memory'] = {
            'total_bytes': memory.total,
            'used_bytes': memory.used,
            'available_bytes': memory.available,
            'used_percent': memory.percent,
        }
        source_values['cpu_percent'].append(float(psutil.cpu_percent(interval=0.1)))
        source_values['memory_used_percent'].append(float(memory.percent))
        source_values['disk_used_percent'].append(round((disk.used / disk.total) * 100, 1) if disk.total else 0)
        source_values['process_count'].append(float(len(psutil.pids())))
        snapshot['monitoring_sources'].append('psutil')
    if wmi is not None and platform.system().lower() == 'windows':
        with RESOURCE_WMI_LOCK:
            wmi_metrics = RESOURCE_WMI_CACHE
        if wmi_metrics is None:
            _start_wmi_refresh()
        else:
            processors = [float(value) for value in wmi_metrics.get('cpu', [])]
            memory_used_percent = wmi_metrics.get('memory')
            disk_used_percent = wmi_metrics.get('disk')
            if processors:
                source_values['cpu_percent'].append(sum(processors) / len(processors))
            if memory_used_percent is not None:
                source_values['memory_used_percent'].append(float(memory_used_percent))
            source_values['process_count'].append(float(wmi_metrics['processes']))
            if disk_used_percent is not None:
                source_values['disk_used_percent'].append(float(disk_used_percent))
            snapshot['monitoring_sources'].append('wmi')
    with RESOURCE_WMI_LOCK:
        if RESOURCE_WMI_REFRESHING:
            snapshot['monitoring_status'] = 'WMI refresh in progress; using the latest available sources.'
    if source_values['cpu_percent']:
        snapshot['cpu_percent'] = round(sum(source_values['cpu_percent']) / len(source_values['cpu_percent']), 1)
    if snapshot['memory'] is not None and source_values['memory_used_percent']:
        snapshot['memory']['used_percent'] = round(sum(source_values['memory_used_percent']) / len(source_values['memory_used_percent']), 1)
    if source_values['disk_used_percent']:
        snapshot['disk']['used_percent'] = round(sum(source_values['disk_used_percent']) / len(source_values['disk_used_percent']), 1)
    if source_values['process_count']:
        snapshot['process_count'] = round(sum(source_values['process_count']) / len(source_values['process_count']))
    snapshot['averaged_metrics'] = {
        key: len(values) for key, values in source_values.items() if values
    }
    try:
        snapshot['load_average'] = [round(value, 2) for value in os.getloadavg()]
    except (AttributeError, OSError):
        pass
    return snapshot


def spotify_output_directory() -> Path:
    output = resolve_configured_directory(
        load_config().get('spotify_output_directory'),
        './downloads/Spotify',
    )
    output.mkdir(parents=True, exist_ok=True)
    return output


def safe_spotify_directory_name(name: str, fallback: str) -> str:
    """Return a filesystem-safe, non-empty Spotify collection directory name."""
    normalized = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name).strip(' .')
    normalized = re.sub(r'\s{2,}', ' ', normalized)
    return normalized[:120] or fallback


def spotify_job_output_directory(spotify_url: str) -> Path:
    """Use an album metadata name as the output directory for album jobs."""
    output = spotify_output_directory()
    parsed = urlparse(spotify_url)
    album_match = re.match(r'^/album/([A-Za-z0-9]+)$', parsed.path)
    if not album_match:
        return output

    album_id = album_match.group(1)
    album_name = ''
    oembed_url = f'https://open.spotify.com/oembed?url={quote(spotify_url, safe="")}'
    try:
        with urllib.request.urlopen(oembed_url, timeout=20) as response:
            metadata = json.loads(response.read().decode('utf-8'))
        album_name = str(metadata.get('title') or '').strip()
    except (OSError, ValueError, urllib.error.URLError):
        album_name = ''

    album_directory = output / safe_spotify_directory_name(album_name, f'album-{album_id}')
    album_directory.mkdir(parents=True, exist_ok=True)
    return album_directory


def browser_extension_directory() -> Path:
    """Return the managed unpacked browser-extension directory."""
    extension_root = resolve_configured_directory(
        load_config().get('extensions_directory'),
        './extensions',
    ) / 'youtube-bot-extension'
    return extension_root


def spotify_job_snapshot(job_id: str) -> Optional[dict]:
    with SPOTIFY_JOBS_LOCK:
        job = SPOTIFY_JOBS.get(job_id)
        return dict(job) if job else None


def spotify_job_overview() -> list[dict]:
    with SPOTIFY_JOBS_LOCK:
        jobs = sorted(SPOTIFY_JOBS.values(), key=lambda item: item.get('created_at', 0), reverse=True)[:8]
        return [dict(job) for job in jobs]


def spotify_display_metadata(spotify_url: str) -> dict:
    metadata = {'title': '', 'artist': '', 'album': '', 'artwork_url': ''}
    try:
        request = urllib.request.Request(
            f'https://open.spotify.com/oembed?url={quote(spotify_url, safe="")}',
            headers={'User-Agent': 'Mozilla/5.0'},
        )
        with urllib.request.urlopen(request, timeout=15) as response:
            data = json.loads(response.read().decode('utf-8'))
        metadata['title'] = str(data.get('title') or '').strip()
        metadata['artwork_url'] = str(data.get('thumbnail_url') or '').strip()
    except (OSError, ValueError, urllib.error.URLError):
        pass
    parsed = urlparse(spotify_url)
    kind = (parsed.path.strip('/').split('/', 1) or [''])[0].lower()
    if kind == 'album':
        metadata['album'] = metadata['title']
    elif kind == 'track':
        metadata['artist'] = metadata['title'].split(' - ', 1)[0] if ' - ' in metadata['title'] else ''
    return metadata


def normalize_spotify_download_name(path: Path) -> Path:
    """Remove YouTube visualizer labels and ID suffixes from a downloaded name."""
    stem = re.sub(
        r'\s*(?:\([^)]*(?:visualizer|official\s+(?:music\s+)?video|music\s+video|lyrics?\s+video|audio)[^)]*\)'
        r'|\[[^\]]*(?:visualizer|official\s+(?:music\s+)?video|music\s+video|lyrics?\s+video|audio)[^\]]*\])',
        '',
        path.stem,
        flags=re.IGNORECASE,
    )
    stem = re.sub(r'\s*\[[A-Za-z0-9_-]{8,}\]\s*$', '', stem)
    stem = re.sub(r'\s{2,}', ' ', stem).strip(' .')
    if not stem:
        return path
    candidate = path.with_name(f'{stem}{path.suffix}')
    if candidate == path or not candidate.exists():
        return candidate
    index = 2
    while True:
        alternate = path.with_name(f'{stem} ({index}){path.suffix}')
        if not alternate.exists():
            return alternate
        index += 1


def choose_spotify_youtube_match(
    ytdlp: str,
    track_title: str,
    artist: str,
    youtube_api_key: Optional[str] = None,
) -> Optional[str]:
    """Select a verified YouTube alternative for one Spotify track."""
    title_text = re.sub(r'\s+', ' ', track_title).strip().lower()
    artist_text = re.sub(r'\s+', ' ', artist).strip().lower()
    title_tokens = set(re.findall(r'[a-z0-9]+', title_text))
    artist_tokens = set(re.findall(r'[a-z0-9]+', artist_text))
    rejected_tokens = {'live', 'cover', 'karaoke', 'remix', 'sped', 'slowed', 'nightcore', 'instrumental'}

    def score_candidate(candidate_title: str, candidate_channel: str) -> float:
        candidate_text = re.sub(r'\s+', ' ', candidate_title).strip().lower()
        candidate_channel = candidate_channel.lower()
        candidate_tokens = set(re.findall(r'[a-z0-9]+', candidate_text))
        title_overlap = len(title_tokens & candidate_tokens) / max(len(title_tokens), 1)
        artist_overlap = len(artist_tokens & (candidate_tokens | set(re.findall(r'[a-z0-9]+', candidate_channel))))
        artist_score = artist_overlap / max(len(artist_tokens), 1) if artist_tokens else 0.5
        similarity = difflib.SequenceMatcher(None, title_text, candidate_text).ratio()
        score = title_overlap * 0.52 + artist_score * 0.28 + similarity * 0.20
        if any(token in candidate_tokens for token in rejected_tokens):
            score -= 0.24
        if any(token in candidate_tokens or token in candidate_channel for token in ('official', 'audio', 'vevo', 'topic')):
            score += 0.08
        return score

    # The Data API is authoritative for candidate discovery. Each candidate is
    # then re-read through the video metadata endpoint before it is accepted.
    if youtube_api_key:
        api_candidates = {}
        api_queries = [
            f'{artist} - {track_title} official audio'.strip(' -'),
            f'{artist} {track_title} audio'.strip(),
            f'{track_title} {artist}'.strip(),
        ]
        try:
            for query in api_queries:
                for candidate in search_youtube_video_candidates(query, youtube_api_key, max_results=10):
                    video_id = candidate.get('video_id', '')
                    if re.fullmatch(r'[A-Za-z0-9_-]{11}', video_id):
                        api_candidates[video_id] = candidate
            best_id = None
            best_score = 0.0
            for video_id, candidate in api_candidates.items():
                metadata = fetch_youtube_video_metadata(
                    f'https://www.youtube.com/watch?v={video_id}',
                    api_key=youtube_api_key,
                )
                video = metadata.get('video', {}) if isinstance(metadata, dict) else {}
                snippet = video.get('snippet', {}) if isinstance(video, dict) else {}
                verified_title = str(snippet.get('title') or candidate.get('title') or '')
                verified_channel = str(snippet.get('channelTitle') or candidate.get('channel') or '')
                if metadata.get('error') or not verified_title:
                    continue
                score = score_candidate(verified_title, verified_channel)
                title_overlap = len(title_tokens & set(re.findall(r'[a-z0-9]+', verified_title.lower())))
                if title_overlap >= max(1, int(len(title_tokens) * 0.55)) and score > best_score:
                    best_id, best_score = video_id, score
            if best_id and best_score >= 0.52:
                return best_id
        except (OSError, RuntimeError, ValueError) as exc:
            # Preserve the yt-dlp fallback when the API quota/network is unavailable.
            print(f'YouTube API matching unavailable for "{track_title}": {exc}')

    # Fallback search for installations without a usable YouTube API key.
    best_id = None
    best_score = 0.0
    queries = [f'{artist} {track_title} official audio'.strip()]
    if artist:
        queries.append(f'{track_title} official audio')
    for query in queries:
        search = subprocess.run(
            [
                ytdlp, f'ytsearch5:{query}', '--flat-playlist', '--skip-download',
                '--print', '%(id)s\t%(title)s\t%(channel)s',
            ],
            cwd=str(WORKSPACE_ROOT),
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace',
            timeout=120,
            shell=False,
        )
        if search.returncode != 0:
            continue
        for line in search.stdout.splitlines():
            parts = line.split('\t', 2)
            if len(parts) < 2:
                continue
            video_id, candidate_title = parts[0].strip(), parts[1].strip()
            candidate_text = candidate_title.lower()
            candidate_tokens = set(re.findall(r'[a-z0-9]+', candidate_text))
            title_overlap = len(title_tokens & candidate_tokens) / max(len(title_tokens), 1)
            if title_overlap < 0.75:
                continue
            similarity = difflib.SequenceMatcher(None, title_text, candidate_text).ratio()
            score = title_overlap * 0.7 + similarity * 0.3
            if artist and artist.lower() in candidate_text:
                score += 0.15
            if score > best_score and re.fullmatch(r'[A-Za-z0-9_-]{8,}', video_id):
                best_id, best_score = video_id, score
    return best_id if best_score >= 0.45 else None


def download_spotify_cover(spotify_url: str) -> Optional[Path]:
    """Download the public Spotify artwork to a temporary JPEG file."""
    oembed_url = f'https://open.spotify.com/oembed?url={quote(spotify_url, safe="")}'
    try:
        with urllib.request.urlopen(oembed_url, timeout=20) as response:
            metadata = json.loads(response.read().decode('utf-8'))
        cover_url = str(metadata.get('thumbnail_url') or '').strip()
        if not cover_url:
            return None
        cover_file = tempfile.NamedTemporaryFile(suffix='.jpg', delete=False)
        cover_path = Path(cover_file.name)
        cover_file.close()
        request = urllib.request.Request(cover_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(request, timeout=30) as response, cover_path.open('wb') as target:
            target.write(response.read())
        return cover_path
    except (OSError, ValueError, urllib.error.URLError):
        if 'cover_path' in locals():
            cover_path.unlink(missing_ok=True)
        return None


def embed_spotify_cover(audio_path: Path, cover_path: Path, ffmpeg: str) -> bool:
    """Attach JPEG artwork to an MP3 as an ID3 attached picture."""
    temporary_path = audio_path.with_suffix('.spotify-cover.mp3')
    try:
        result = subprocess.run(
            [
                ffmpeg, '-y', '-i', str(audio_path), '-i', str(cover_path),
                '-map', '0:a:0', '-map', '1:v:0', '-map_metadata', '0',
                '-c:a', 'copy', '-c:v', 'mjpeg', '-id3v2_version', '3',
                '-metadata:s:v', 'title=Album cover',
                '-metadata:s:v', 'comment=Spotify album artwork',
                '-disposition:v', 'attached_pic', str(temporary_path),
            ],
            cwd=str(WORKSPACE_ROOT), capture_output=True, text=True,
            encoding='utf-8', errors='replace', timeout=180, shell=False,
        )
        if result.returncode != 0:
            temporary_path.unlink(missing_ok=True)
            return False
        temporary_path.replace(audio_path)
        return True
    except (OSError, subprocess.TimeoutExpired):
        temporary_path.unlink(missing_ok=True)
        return False


def tag_spotify_audio(
    audio_path: Path,
    *,
    title: str,
    artist: str,
    album: str,
    track_number: int,
    track_total: int,
    source_url: str,
    youtube_url: str,
    cover_path: Optional[Path],
) -> bool:
    """Write inspectable ID3 metadata matching Spotify's track fields."""
    if ID3 is None:
        return False
    try:
        try:
            tags = ID3(str(audio_path))
        except ID3NoHeaderError:
            tags = ID3()
        tags.delall('TIT2')
        tags.delall('TPE1')
        tags.delall('TPE2')
        tags.delall('TALB')
        tags.delall('TRCK')
        tags.delall('TPOS')
        tags.delall('TSRC')
        tags.delall('COMM')
        tags.delall('TXXX')
        tags.add(TIT2(encoding=3, text=[title]))
        tags.add(TPE1(encoding=3, text=[artist or 'Unknown Artist']))
        tags.add(TPE2(encoding=3, text=[artist or 'Unknown Artist']))
        tags.add(TALB(encoding=3, text=[album or 'Spotify Download']))
        tags.add(TRCK(encoding=3, text=[f'{track_number}/{track_total}']))
        tags.add(TPOS(encoding=3, text=['1/1']))
        tags.add(TSRC(encoding=3, text=[source_url]))
        tags.add(COMM(encoding=3, lang='eng', desc='', text=[youtube_url]))
        tags.add(TXXX(encoding=3, desc='Source URL', text=[source_url]))
        tags.add(TXXX(encoding=3, desc='Date/Time Original', text=[time.strftime('%Y:%m:%d')]))
        if cover_path and cover_path.is_file():
            tags.delall('APIC:')
            tags.add(APIC(
                encoding=3,
                mime='image/jpeg',
                type=3,
                desc='Cover',
                data=cover_path.read_bytes(),
            ))
        tags.save(str(audio_path), v2_version=3)
        return True
    except (OSError, ValueError):
        return False


def run_spotify_oembed_fallback(spotify_url: str, output_dir: Path) -> dict:
    """Resolve public Spotify metadata and download YouTube matches."""
    parsed = urlparse(spotify_url)
    kind_match = re.match(r'^/(track|album|playlist)/([A-Za-z0-9]+)$', parsed.path)
    if not kind_match:
        return {'ok': False, 'error': 'The public fallback supports Spotify track, album, and playlist URLs.'}
    kind, item_id = kind_match.groups()
    oembed_url = f'https://open.spotify.com/oembed?url={quote(spotify_url, safe="")}'
    try:
        with urllib.request.urlopen(oembed_url, timeout=20) as response:
            metadata = json.loads(response.read().decode('utf-8'))
    except (OSError, ValueError, urllib.error.URLError) as exc:
        return {'ok': False, 'error': f'Unable to read public Spotify metadata: {exc}'}
    title = str(metadata.get('title') or '').strip()
    cover_url = str(metadata.get('thumbnail_url') or '').strip()
    tracks = []
    if kind == 'track':
        artist = ''
        try:
            request = urllib.request.Request(spotify_url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(request, timeout=20) as response:
                page = response.read().decode('utf-8', errors='replace')
            musician_match = re.search(
                r'<meta[^>]+(?:name|property)="music:musician_description"[^>]+content="([^"]+)"',
                page, re.IGNORECASE,
            )
            artist = (musician_match.group(1) if musician_match else '').strip()
        except (OSError, urllib.error.URLError):
            artist = ''
        tracks = [(title, artist)]
    else:
        embed_url = f'https://open.spotify.com/embed/{kind}/{item_id}'
        try:
            request = urllib.request.Request(embed_url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(request, timeout=20) as response:
                embed_page = response.read().decode('utf-8', errors='replace')
            cover_match = re.search(
                r'<img[^>]+src="(https://[^"]*spotifycdn[^"]*)"',
                embed_page, re.IGNORECASE,
            )
            if cover_match:
                cover_url = html.unescape(cover_match.group(1))
            rows = re.findall(
                r'<h3[^>]*TracklistRow_title[^>]*>(.*?)</h3>.*?'
                r'<h4[^>]*TracklistRow_subtitle[^>]*>(.*?)</h4>',
                embed_page, re.IGNORECASE | re.DOTALL,
            )
            tracks = [
                (re.sub(r'<[^>]+>', '', html.unescape(track)).strip(),
                 re.sub(
                     r'<span[^>]*>.*?</span>', '',
                     html.unescape(artist), flags=re.IGNORECASE | re.DOTALL,
                 ).strip())
                for track, artist in rows
            ]
        except (OSError, urllib.error.URLError) as exc:
            return {'ok': False, 'error': f'Unable to read Spotify {kind} track list: {exc}'}
    tracks = [(track, artist) for track, artist in tracks if track]
    if not tracks:
        return {'ok': False, 'error': 'Spotify did not provide any public tracks for this link.'}
    ytdlp = shutil.which('yt-dlp')
    if not ytdlp:
        return {'ok': False, 'error': 'yt-dlp executable not found; install yt-dlp for the Spotify fallback.'}
    ffmpeg = shutil.which('ffmpeg')
    cover_path = download_spotify_cover(spotify_url) if cover_url and ffmpeg else None
    outputs = []
    failed_tracks = []
    youtube_api_key = str(load_config().get('youtube_api_key') or '').strip()
    for track_index, (track_title, artist) in enumerate(tracks, start=1):
        try:
            video_id = choose_spotify_youtube_match(
                ytdlp, track_title, artist, youtube_api_key=youtube_api_key
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            failed_tracks.append({'title': track_title, 'error': f'YouTube search failed: {exc}'})
            continue
        if not video_id:
            failed_tracks.append({'title': track_title, 'error': 'No verified YouTube match found'})
            continue
        command = [
            ytdlp, f'https://www.youtube.com/watch?v={video_id}', '--no-playlist', '--no-warnings', '--quiet',
            '--format', 'bestaudio/best', '--extract-audio', '--audio-format', 'mp3',
            '--audio-quality', '0',
            '--embed-metadata', '--print', 'after_move:filepath',
            '--output', str(output_dir / '%(title)s [%(id)s].%(ext)s'),
            '--windows-filenames', '--max-filesize', '500M',
        ]
        fallback_config = load_config()
        fallback_limit = adaptive_bandwidth_limit(fallback_config)
        if fallback_limit is None:
            fallback_limit = int(fallback_config.get('bandwidth_limit_kbps') or 0)
        if fallback_limit > 0:
            command.extend(['--limit-rate', f'{fallback_limit}K'])
        try:
            result = subprocess.run(
                command, cwd=str(WORKSPACE_ROOT), capture_output=True, text=True,
                encoding='utf-8', errors='replace', timeout=1800, shell=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            failed_tracks.append({'title': track_title, 'error': f'YouTube download failed: {exc}'})
            continue
        output = ((result.stdout or '') + (result.stderr or '')).strip()
        outputs.append(output[-3000:])
        if result.returncode != 0:
            failed_tracks.append({'title': track_title, 'error': f'YouTube download failed: {output[-1200:]}'})
            continue
        audio_paths = []
        for line in output.splitlines():
            candidate = Path(line.strip().strip('"'))
            if candidate.suffix.lower() == '.mp3' and candidate.is_file():
                audio_paths.append(candidate)
        if not audio_paths:
            audio_paths = sorted(output_dir.glob('*.mp3'), key=lambda path: path.stat().st_mtime, reverse=True)[:1]
        if not audio_paths:
            failed_tracks.append({'title': track_title, 'error': 'YouTube download produced no MP3 file'})
            continue
        for audio_path in audio_paths[:1]:
            normalized_audio_path = normalize_spotify_download_name(audio_path)
            if normalized_audio_path != audio_path:
                audio_path.replace(normalized_audio_path)
                audio_path = normalized_audio_path
            if cover_path and ffmpeg:
                embed_spotify_cover(audio_path, cover_path, ffmpeg)
            tag_spotify_audio(
                audio_path,
                title=track_title,
                artist=artist,
                album=title if kind == 'album' else '',
                track_number=track_index,
                track_total=len(tracks),
                source_url=spotify_url,
                youtube_url=f'https://www.youtube.com/watch?v={video_id}',
                cover_path=cover_path,
            )
    if cover_path:
        cover_path.unlink(missing_ok=True)
    return {
        'ok': bool(outputs),
        'title': title,
        'output': '\n'.join(outputs)[-12000:],
        'track_count': len(tracks),
        'downloaded_track_count': len(tracks) - len(failed_tracks),
        'failed_tracks': failed_tracks,
        'error': (
            f'{len(failed_tracks)} track(s) could not be downloaded'
            if failed_tracks else ''
        ),
    }


def run_spotify_job(job_id: str, spotify_url: str) -> None:
    output_dir = spotify_job_output_directory(spotify_url)
    existing_mp3_files = set(output_dir.glob('*.mp3'))
    display_metadata = spotify_display_metadata(spotify_url)
    parsed_kind = (urlparse(spotify_url).path.strip('/').split('/', 1) or [''])[0].lower()
    parsed_url = urlparse(spotify_url)
    normalized_url = f'{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path}'
    with SPOTIFY_JOBS_LOCK:
        if job_id in SPOTIFY_JOBS:
            SPOTIFY_JOBS[job_id].update({
                'status': 'running',
                'output_directory': str(output_dir.relative_to(WORKSPACE_ROOT)).replace('\\', '/'),
                'content_type': parsed_kind,
                'title': display_metadata.get('title', ''),
                'album': display_metadata.get('album', ''),
                'artist': display_metadata.get('artist', ''),
                'artwork_url': display_metadata.get('artwork_url', ''),
            })
    executable = shutil.which('spotdl')
    command_args = [
        'download', normalized_url,
        '--output', str(output_dir),
        '--format', 'mp3',
        '--overwrite', 'skip',
        '--print-errors',
        '--no-cache',
    ]
    spotify_quality = str(load_config().get('spotify_audio_quality', '320k')).strip().lower()
    if spotify_quality not in {'auto', '320k', '256k', '192k', '128k', '96k', '64k', '32k'}:
        spotify_quality = '320k'
    command_args.extend(['--bitrate', spotify_quality])
    spotify_config = load_config()
    configured_spotify_threads = max(1, min(8, int(spotify_config.get('concurrent_threads') or 3)))
    spotify_threads = 1 if adaptive_bandwidth_limit(spotify_config) is not None else configured_spotify_threads
    command_args.extend(['--threads', str(spotify_threads)])
    client_id = (
        os.environ.get('SPOTIFY_CLIENT_ID')
        or spotify_config.get('spotify_client_id', '')
    ).strip()
    client_secret = (
        os.environ.get('SPOTIFY_CLIENT_SECRET')
        or spotify_config.get('spotify_client_secret', '')
    ).strip()
    if client_id and client_secret:
        command_args.extend([
            '--client-id', client_id,
            '--client-secret', client_secret,
            '--use-official-api',
        ])
    commands = []
    if executable:
        commands.append([executable, *command_args])
    commands.append([sys.executable, '-m', 'spotdl', *command_args])
    with SPOTIFY_JOBS_LOCK:
        SPOTIFY_JOBS[job_id]['commands'] = commands
    try:
        attempts = []
        result = None
        for command in commands:
            try:
                attempt = subprocess.run(
                    command, cwd=str(WORKSPACE_ROOT), capture_output=True, text=True,
                    encoding='utf-8', errors='replace', timeout=1800, shell=False,
                )
            except FileNotFoundError as exc:
                attempts.append({'command': command, 'error': str(exc)})
                continue
            except subprocess.TimeoutExpired:
                attempts.append({'command': command, 'error': 'timed out after 30 minutes'})
                continue
            attempts.append({
                'command': command,
                'exit_code': attempt.returncode,
                'output': (attempt.stdout or '')[-6000:] + (attempt.stderr or '')[-6000:],
            })
            result = attempt
            if attempt.returncode == 0:
                break
        if result is None:
            with SPOTIFY_JOBS_LOCK:
                SPOTIFY_JOBS[job_id].update({
                    'status': 'error',
                    'error': 'All spotdl execution attempts failed. Install or repair spotdl with: python -m pip install --upgrade spotdl',
                    'attempts': attempts,
                    'tracks': [Path(path).stem for path in files],
                })
            return
        output = ((result.stdout or '') + (result.stderr or '')).strip()
        if result.returncode != 0:
            detail = output[-4000:] if output else 'spotdl did not provide diagnostic output'
            detail_lower = detail.lower()
            spotify_api_access_denied = (
                'active premium subscription required' in detail_lower
                or (
                    'spotifyexception' in detail_lower
                    and 'http status: 403' in detail_lower
                )
            )
            anonymous_spotify_auth_failure = (
                not (client_id and client_secret)
                and (
                    'session auth' in detail_lower
                    or 'unauthorized request' in detail_lower
                )
            )
            if spotify_api_access_denied or anonymous_spotify_auth_failure:
                fallback = run_spotify_oembed_fallback(spotify_url, output_dir)
                if fallback.get('ok'):
                    files = [
                        str(path.relative_to(WORKSPACE_ROOT)).replace('\\', '/')
                        for path in output_dir.rglob('*') if path.is_file()
                    ]
                    if result.returncode == 0:
                        ffmpeg = shutil.which('ffmpeg')
                        cover_path = download_spotify_cover(spotify_url) if ffmpeg else None
                        if cover_path and ffmpeg:
                            try:
                                for audio_path in output_dir.glob('*.mp3'):
                                    if audio_path not in existing_mp3_files:
                                        embed_spotify_cover(audio_path, cover_path, ffmpeg)
                            finally:
                                cover_path.unlink(missing_ok=True)
                    with SPOTIFY_JOBS_LOCK:
                        SPOTIFY_JOBS[job_id].update({
                            'status': 'completed_with_warnings' if fallback.get('failed_tracks') else 'completed',
                            'output': (
                                fallback.get('output', '')
                                + (
                                    '\n\nTrack warnings:\n'
                                    + '\n'.join(
                                        f"- {item.get('title')}: {item.get('error')}"
                                        for item in fallback.get('failed_tracks', [])
                                    )
                                    if fallback.get('failed_tracks') else ''
                                )
                            )[-12000:],
                            'files': files,
                            'metadata_source': 'Spotify oEmbed + YouTube',
                            'fallback': True,
                            'attempts': attempts,
                            'tracks': [Path(path).stem for path in files],
                            'failed_tracks': fallback.get('failed_tracks', []),
                        })
                    return
                detail = f'{detail}\n\nFallback: {fallback.get("error", "unknown fallback error")}'
            with SPOTIFY_JOBS_LOCK:
                SPOTIFY_JOBS[job_id].update({
                    'status': 'error',
                    'error': f'spotdl could not resolve or download this Spotify URL:\n{detail}',
                    'output': detail,
                    'attempts': attempts,
                    'metadata_source': 'spotdl',
                })
            return
        files = [
            str(path.relative_to(WORKSPACE_ROOT)).replace('\\', '/')
            for path in output_dir.rglob('*') if path.is_file()
        ]
        with SPOTIFY_JOBS_LOCK:
            SPOTIFY_JOBS[job_id].update({
                'status': 'completed' if result.returncode == 0 else 'error',
                'exit_code': result.returncode,
                'output': output[-12000:],
                'files': files,
                'metadata_source': 'spotdl',
                'attempts': attempts,
            })
    except subprocess.TimeoutExpired:
        with SPOTIFY_JOBS_LOCK:
            SPOTIFY_JOBS[job_id].update({'status': 'error', 'error': 'Spotify download timed out after 30 minutes'})
    except OSError as exc:
        with SPOTIFY_JOBS_LOCK:
            SPOTIFY_JOBS[job_id].update({'status': 'error', 'error': str(exc)})


def proxy_context_for(handler: BaseHTTPRequestHandler) -> Optional[str]:
    with PROXY_CONTEXTS_LOCK:
        return PROXY_CONTEXTS.get(request_client_ip(handler))


def remember_proxy_context(handler: BaseHTTPRequestHandler, target_url: str) -> None:
    parsed = urlparse(target_url)
    if parsed.scheme not in ('http', 'https') or not parsed.netloc:
        return
    with PROXY_CONTEXTS_LOCK:
        PROXY_CONTEXTS[request_client_ip(handler)] = f'{parsed.scheme}://{parsed.netloc}/'


def authenticate(handler: BaseHTTPRequestHandler, username: str, password: str) -> bool:
    global ROOT_ACTIVE_TOKEN
    retry_after = login_is_locked_out(handler, username)
    if retry_after:
        send_json_response(handler, 429, {
            'error': 'Too many failed login attempts',
            'retry_after': retry_after,
        })
        return False
    is_root = (
        bool(ROOT_PASSWORD)
        and secrets.compare_digest(username, ROOT_USER)
        and secrets.compare_digest(password, ROOT_PASSWORD)
    )
    is_admin = (
        secrets.compare_digest(username, AUTH_USER)
        and secrets.compare_digest(password, AUTH_PASSWORD)
    )
    account = _account_records().get(username)
    is_account = bool(account and _verify_account_password(password, account.get('password_hash', '')))
    if is_root or is_admin or is_account:
        clear_login_failures(handler, username)
        token = secrets.token_urlsafe(32)
        with AUTH_SESSIONS_LOCK:
            if is_root and ROOT_ACTIVE_TOKEN and AUTH_SESSIONS.get(ROOT_ACTIVE_TOKEN) == ROOT_USER:
                send_json_response(handler, 500, {
                    'error': 'Fatal root ownership conflict',
                    'message': 'Another root session already owns this network. Stop that session before claiming root again.',
                    'fatal': True,
                })
                return False
            AUTH_SESSIONS[token] = username
            AUTH_LOCAL_SESSIONS[token] = is_local_host_request(handler)
            if is_root:
                ROOT_ACTIVE_TOKEN = token
        if is_root:
            record_root_login_ip(handler)
        handler.send_response(200)
        handler.send_header('Content-Type', 'application/json; charset=utf-8')
        secure = '; Secure' if handler.headers.get('X-Forwarded-Proto', 'http').lower() == 'https' else ''
        handler.send_header('Set-Cookie', f'{SESSION_COOKIE_NAME}={token}; Path=/; HttpOnly; SameSite=Strict{secure}')
        if is_root:
            handler.send_header('Set-Cookie', f'{ROOT_SESSION_COOKIE_NAME}={token}; Path=/; HttpOnly; SameSite=Strict{secure}')
        else:
            handler.send_header('Set-Cookie', f'{ROOT_SESSION_COOKIE_NAME}=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict{secure}')
        handler.send_header('Cache-Control', 'no-store')
        handler.end_headers()
        role = 'root' if is_root else 'admin' if is_admin else 'user'
        write_response_body(handler, json.dumps({
            'authenticated': True,
            'role': role,
            'username': username,
            'local_host': is_local_host_request(handler),
            'permissions': sorted(_account_permissions(username)),
            'account_audit': account_audit_records() if is_root else None,
            'root_hostname': socket.getfqdn() if is_root else None,
        }).encode('utf-8'))
        return True
    record_login_failure(handler, username)
    send_json_response(handler, 401, {'error': 'Invalid credentials'})
    return False


def authenticate_guest(handler: BaseHTTPRequestHandler) -> None:
    token = secrets.token_urlsafe(32)
    guest_name = f'guest-{token[:8]}'
    with AUTH_SESSIONS_LOCK:
        AUTH_SESSIONS[token] = guest_name
        AUTH_LOCAL_SESSIONS[token] = False
    handler.send_response(200)
    handler.send_header('Content-Type', 'application/json; charset=utf-8')
    secure = '; Secure' if handler.headers.get('X-Forwarded-Proto', 'http').lower() == 'https' else ''
    handler.send_header('Set-Cookie', f'{SESSION_COOKIE_NAME}={token}; Path=/; HttpOnly; SameSite=Strict{secure}')
    handler.send_header('Set-Cookie', f'{ROOT_SESSION_COOKIE_NAME}=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict{secure}')
    handler.send_header('Cache-Control', 'no-store')
    handler.end_headers()
    write_response_body(handler, json.dumps({
        'authenticated': True,
        'role': 'guest',
        'username': guest_name,
        'temporary': True,
        'local_host': False,
    }).encode('utf-8'))


def sign_out(handler: BaseHTTPRequestHandler) -> None:
    global ROOT_ACTIVE_TOKEN
    cookies = handler.headers.get('Cookie', '')
    tokens = re.findall(
        rf'(?:^|;\s*)(?:{re.escape(SESSION_COOKIE_NAME)}|{re.escape(ROOT_SESSION_COOKIE_NAME)})=([^;]+)',
        cookies,
    )
    with AUTH_SESSIONS_LOCK:
        for token in tokens:
            if token == ROOT_ACTIVE_TOKEN:
                ROOT_ACTIVE_TOKEN = None
            AUTH_SESSIONS.pop(token, None)
            AUTH_LOCAL_SESSIONS.pop(token, None)
    secure = '; Secure' if handler.headers.get('X-Forwarded-Proto', 'http').lower() == 'https' else ''
    handler.send_response(200)
    handler.send_header('Content-Type', 'application/json; charset=utf-8')
    handler.send_header('Set-Cookie', f'{SESSION_COOKIE_NAME}=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict{secure}')
    handler.send_header('Set-Cookie', f'{ROOT_SESSION_COOKIE_NAME}=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict{secure}')
    handler.send_header('Cache-Control', 'no-store')
    handler.end_headers()
    write_response_body(handler, json.dumps({'signed_out': True}).encode('utf-8'))


def update_device_permission(handler: BaseHTTPRequestHandler, payload: dict) -> None:
    if not is_root_session(handler):
        send_json_response(handler, 403, {'error': 'Root access required'})
        return
    ip = str(payload.get('ip', '')).strip()
    permission = str(payload.get('permission', 'view')).strip().lower()
    try:
        ipaddress.ip_address(ip)
    except ValueError:
        send_json_response(handler, 400, {'error': 'A valid device IP is required'})
        return
    if permission not in ('view', 'download', 'operate'):
        send_json_response(handler, 400, {'error': 'Permission must be view, download, or operate'})
        return
    policies = _device_policies()
    policies[ip] = permission
    _save_json_store(DEVICE_POLICY_STORE, policies)
    send_json_response(handler, 200, {'updated': True, 'ip': ip, 'permission': permission})


def change_root_password(handler: BaseHTTPRequestHandler, payload: dict) -> None:
    global ROOT_PASSWORD
    if not is_root_session(handler):
        send_json_response(handler, 403, {'error': 'Root access required'})
        return
    new_password = str(payload.get('new_password', ''))
    if len(new_password) < 8:
        send_json_response(handler, 400, {'error': 'Root password must be at least 8 characters'})
        return
    ROOT_PASSWORD = new_password
    send_json_response(handler, 200, {'updated': True, 'message': 'Root password updated for this server session'})


def detect_package_manager() -> str:
    if os.name == 'nt':
        return 'winget' if shutil.which('winget') else 'choco' if shutil.which('choco') else 'none detected'
    for manager in ('apt', 'dnf', 'yum', 'pacman', 'zypper', 'apk'):
        if shutil.which(manager):
            return manager
    return 'none detected'


def run_root_terminal_command(handler: BaseHTTPRequestHandler, payload: dict) -> None:
    if not is_root_session(handler) or not is_local_host_request(handler):
        send_json_response(handler, 403, {'error': 'Local root access required'})
        return
    command = str(payload.get('command', '')).strip()
    if not command or any(token in command for token in ('&', '|', ';', '>', '<', '`', '$(', '\n', '\r')):
        send_json_response(handler, 400, {'error': 'Enter one approved command without shell operators'})
        return
    try:
        args = shlex.split(command, posix=False)
    except ValueError as exc:
        send_json_response(handler, 400, {'error': f'Invalid command syntax: {exc}'})
        return
    if not args:
        send_json_response(handler, 400, {'error': 'Command is empty'})
        return
    executable = args[0].lower().removesuffix('.exe')
    allowed = {
        'dir': lambda: (str(WORKSPACE_ROOT), ''),
        'ls': lambda: (str(WORKSPACE_ROOT), ''),
        'pwd': lambda: (str(WORKSPACE_ROOT), ''),
    }
    if executable in allowed and len(args) == 1:
        if executable in ('dir', 'ls'):
            output = '\n'.join(sorted(path.name for path in WORKSPACE_ROOT.iterdir()))
        else:
            output = str(WORKSPACE_ROOT)
        send_json_response(handler, 200, {
            'ok': True, 'command': command, 'output': output, 'cwd': str(WORKSPACE_ROOT),
            'os': platform.system(), 'package_manager': detect_package_manager(),
        })
        return
    is_windows = os.name == 'nt'
    approved = {
        ('python', '--version'), ('python', '-V'),
        ('python3', '--version'), ('python3', '-V'),
        ('git', 'status', '--short'), ('git', 'status'),
        ('where', 'python'), ('where', 'git'),
        ('which', 'python'), ('which', 'git'),
        ('systeminfo',), ('hostname',), ('whoami',), ('id',),
        ('ipconfig',), ('ipconfig', '/all'),
        ('tasklist',), ('netstat', '-ano'), ('netstat', '-tulpn'),
        ('sc', 'query'), ('sc', 'query', 'VideoRetriever'),
        ('uname', '-a'), ('ps', 'aux'), ('ss', '-tulpn'),
        ('ip', 'addr'),
        ('df', '-h'), ('free', '-h'), ('getmac',),
        ('systemctl', 'status', 'nginx', '--no-pager'),
    }
    normalized = tuple(part.lower() for part in args)
    if is_windows:
        approved -= {
            ('python3', '--version'), ('python3', '-V'), ('which', 'python'), ('which', 'git'),
            ('id',), ('netstat', '-tulpn'), ('uname', '-a'), ('ps', 'aux'), ('ss', '-tulpn'),
            ('df', '-h'), ('free', '-h'), ('systemctl', 'status', 'nginx', '--no-pager'),
        }
    else:
        approved -= {
            ('systeminfo',), ('ipconfig',), ('ipconfig', '/all'), ('tasklist',),
            ('netstat', '-ano'), ('sc', 'query'), ('sc', 'query', 'VideoRetriever'),
            ('getmac',), ('where', 'python'), ('where', 'git'),
            ('ip', 'addr'),
        }
    if normalized not in approved:
        send_json_response(handler, 403, {'error': 'Command is not approved for the dashboard terminal'})
        return
    try:
        result = subprocess.run(args, cwd=str(WORKSPACE_ROOT), capture_output=True, text=True, timeout=15, shell=False)
    except subprocess.TimeoutExpired:
        send_json_response(handler, 504, {'error': 'Command timed out'})
        return
    send_json_response(handler, 200, {
        'ok': result.returncode == 0,
        'command': command,
        'output': (result.stdout or '') + (result.stderr or ''),
        'exit_code': result.returncode,
        'cwd': str(WORKSPACE_ROOT),
        'os': platform.system(),
        'package_manager': detect_package_manager(),
    })


class UnixThreadingHTTPServer(socketserver.ThreadingMixIn, HTTPServer):
    """HTTP server variant for NGINX reverse-proxy deployments using a Unix socket."""
    address_family = getattr(socket, 'AF_UNIX', None)
    daemon_threads = True
    allow_reuse_address = True


class LanThreadingHTTPServer(ThreadingHTTPServer):
    """Bind without a reverse-DNS lookup that can stall on isolated LANs."""

    allow_reuse_address = True
    daemon_threads = True

    def server_bind(self):
        self.socket.bind(self.server_address)
        self.server_name = self.server_address[0]
        self.server_port = self.socket.getsockname()[1]

    def __init__(self, server_address, handler_class):
        if self.address_family is None:
            raise OSError('Unix domain sockets are not supported on this platform')
        socket_path = str(server_address)
        socket_dir = os.path.dirname(socket_path)
        if socket_dir and not os.path.exists(socket_dir):
            os.makedirs(socket_dir, exist_ok=True)
        if os.path.exists(socket_path):
            os.unlink(socket_path)
        super().__init__(server_address, handler_class)

    def server_close(self):
        try:
            super().server_close()
        finally:
            socket_path = getattr(self, 'server_address', None)
            if isinstance(socket_path, str) and os.path.exists(socket_path):
                try:
                    os.unlink(socket_path)
                except OSError:
                    pass

def run_yt_dlp_json(url: str, timeout: int = 90, force_ipv4_on_error: bool = True, cookiefile: Optional[str] = None) -> dict:
    """
    Run yt-dlp CLI to produce JSON metadata for the given URL.
    Returns dict with keys: 'ok' (bool), 'data' (parsed JSON on success), 'error' (string on failure), 'attempts' (list of attempt dicts)
    This function uses subprocess.Popen.communicate with timeout and ensures the child process is killed on timeout.
    It will optionally retry once with --force-ipv4 when a transport/SSL-related error or timeout occurs.
    """
    attempts = []
    ytdlp_path = shutil.which('yt-dlp')
    if not ytdlp_path:
        return {'ok': False, 'error': 'yt-dlp executable not found on PATH', 'attempts': attempts}

    def _run_with_args(args, to):
        try:
            proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            out, err = proc.communicate(timeout=to)
            return proc.returncode, out or '', err or ''
        except subprocess.TimeoutExpired:
            try:
                proc.kill()
            except Exception:
                pass
            # ensure we read any remaining output
            try:
                out, err = proc.communicate(timeout=5)
            except Exception:
                out, err = '', ''
            return -1, out or '', err or 'timeout'
        except Exception as e:
            return -1, '', str(e)

    base_cmd = [ytdlp_path, '--no-warnings', '--skip-download', '--dump-json', url]
    if cookiefile:
        base_cmd = [ytdlp_path, '--no-warnings', '--skip-download', '--dump-json', '--cookies', cookiefile, url]

    # Attempt 1: normal
    rc, out, err = _run_with_args(base_cmd, timeout)
    attempts.append({'args': base_cmd, 'returncode': rc, 'stdout': out, 'stderr': err})

    def _parse_output(out_text):
        out_text = (out_text or '').strip()
        if not out_text:
            return None, 'empty output'
        try:
            return json.loads(out_text), None
        except Exception:
            # fallback to first non-empty JSON line
            for ln in out_text.splitlines():
                ln = ln.strip()
                if not ln:
                    continue
                try:
                    return json.loads(ln), None
                except Exception:
                    continue
            return None, 'failed to parse JSON output'

    if rc == 0:
        data, perr = _parse_output(out)
        if data is not None:
            return {'ok': True, 'data': data, 'attempts': attempts}
        # else treat as failure and fallthrough to possible retry
        err_msg = perr or (err or 'unknown')
    else:
        err_msg = err or out or f'returncode={rc}'

    # Detect SSL/timeouts and optionally retry with --force-ipv4
    should_retry_ipv4 = False
    lower_err = (err_msg or '').lower()
    if 'ssl' in lower_err or 'unexpected_eof' in lower_err or 'timeout' in lower_err or 'eof' in lower_err:
        should_retry_ipv4 = True

    if force_ipv4_on_error and should_retry_ipv4:
        alt_cmd = [ytdlp_path, '--no-warnings', '--skip-download', '--dump-json', '--force-ipv4', url]
        if cookiefile:
            alt_cmd = [ytdlp_path, '--no-warnings', '--skip-download', '--dump-json', '--force-ipv4', '--cookies', cookiefile, url]
        rc2, out2, err2 = _run_with_args(alt_cmd, max(10, timeout // 2))
        attempts.append({'args': alt_cmd, 'returncode': rc2, 'stdout': out2, 'stderr': err2})
        if rc2 == 0:
            data2, perr2 = _parse_output(out2)
            if data2 is not None:
                return {'ok': True, 'data': data2, 'attempts': attempts}
            else:
                return {'ok': False, 'error': perr2 or err2 or 'parse_failed', 'attempts': attempts}
        else:
            return {'ok': False, 'error': err2 or out2 or f'returncode={rc2}', 'attempts': attempts}

    return {'ok': False, 'error': err_msg, 'attempts': attempts}


def sanitize_attempts(attempts, max_field_len: int = 2000):
    """Sanitize and truncate attempt stdout/stderr to keep responses reasonable."""
    sanitized = []
    for a in (attempts or []):
        sa = {
            'args': a.get('args'),
            'returncode': a.get('returncode'),
        }
        out = a.get('stdout') or ''
        err = a.get('stderr') or ''
        if len(out) > max_field_len:
            out = out[:max_field_len] + '... (truncated)'
        if len(err) > max_field_len:
            err = err[:max_field_len] + '... (truncated)'
        sa['stdout'] = out
        sa['stderr'] = err
        sanitized.append(sa)
    return sanitized


def human_readable_bytes(value: Optional[int]) -> Optional[str]:
    if value is None:
        return None
    try:
        n = int(value)
    except (TypeError, ValueError):
        return None
    if n < 0:
        return None
    units = ['B', 'KB', 'MB', 'GB', 'TB']
    i = 0
    while n >= 1024 and i < len(units) - 1:
        n /= 1024.0
        i += 1
    if i == 0:
        return f'{int(n)} {units[i]}'
    return f'{n:.1f} {units[i]}'


def _coerce_int(value: Optional[object]) -> Optional[int]:
    if value in (None, ''):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _estimate_filesize_bytes(fmt: Optional[dict], duration_seconds: Optional[int]) -> Optional[int]:
    if not isinstance(fmt, dict):
        return None
    explicit = _coerce_int(fmt.get('filesize'))
    if explicit is not None:
        return explicit
    explicit_approx = _coerce_int(fmt.get('filesize_approx'))
    if explicit_approx is not None:
        return explicit_approx

    bitrate_kbps = _coerce_int(fmt.get('tbr'))
    if bitrate_kbps is None or duration_seconds is None or duration_seconds <= 0:
        return None
    # yt-dlp's tbr is commonly expressed in kilobits/second. Convert to bytes.
    return int((bitrate_kbps * 1000 / 8) * duration_seconds)


def derive_best_download_info(yt_info: dict) -> dict:
    if not isinstance(yt_info, dict):
        return {}
    formats = yt_info.get('formats') or []
    if not isinstance(formats, list) or not formats:
        return {}

    duration_seconds = _coerce_int(yt_info.get('duration'))

    def format_quality_key(fmt: dict) -> tuple:
        height = _coerce_int(fmt.get('height')) or 0
        width = _coerce_int(fmt.get('width')) or 0
        fps = _coerce_int(fmt.get('fps')) or 0
        bitrate = _coerce_int(fmt.get('tbr')) or 0
        size_estimate = _estimate_filesize_bytes(fmt, duration_seconds) or 0
        return (height, width, fps, bitrate, size_estimate)

    def is_combined(fmt: dict) -> bool:
        return fmt.get('vcodec') not in (None, 'none') and fmt.get('acodec') not in (None, 'none')

    def is_video_only(fmt: dict) -> bool:
        return fmt.get('vcodec') not in (None, 'none') and fmt.get('acodec') in (None, 'none')

    def is_audio_only(fmt: dict) -> bool:
        return fmt.get('vcodec') in (None, 'none') and fmt.get('acodec') not in (None, 'none')

    candidates = []
    for fmt in formats:
        if not isinstance(fmt, dict):
            continue
        if is_combined(fmt):
            candidates.append(('combined', fmt))
        elif is_video_only(fmt):
            candidates.append(('video-only', fmt))
        elif is_audio_only(fmt):
            candidates.append(('audio-only', fmt))

    if not candidates:
        return {}

    combined_candidates = [fmt for kind, fmt in candidates if kind == 'combined']
    video_candidates = [fmt for kind, fmt in candidates if kind == 'video-only']
    audio_candidates = [fmt for kind, fmt in candidates if kind == 'audio-only']

    chosen = None
    download_type = 'combined'
    if combined_candidates:
        chosen = max(combined_candidates, key=format_quality_key)
        download_type = 'combined'
    elif video_candidates:
        chosen = max(video_candidates, key=format_quality_key)
        download_type = 'video-only'
    elif audio_candidates:
        chosen = max(audio_candidates, key=format_quality_key)
        download_type = 'audio-only'
    else:
        return {}

    filesize = _estimate_filesize_bytes(chosen, duration_seconds)
    if filesize is None and download_type == 'combined':
        best_video = max(video_candidates, key=format_quality_key) if video_candidates else None
        best_audio = max(audio_candidates, key=format_quality_key) if audio_candidates else None
        video_size = _estimate_filesize_bytes(best_video, duration_seconds) if best_video else None
        audio_size = _estimate_filesize_bytes(best_audio, duration_seconds) if best_audio else None
        if video_size is not None and audio_size is not None:
            filesize = video_size + audio_size
    elif filesize is None and download_type == 'video-only' and audio_candidates:
        best_audio = max(audio_candidates, key=format_quality_key)
        audio_size = _estimate_filesize_bytes(best_audio, duration_seconds)
        if audio_size is not None:
            filesize = audio_size

    label = None
    height = _coerce_int(chosen.get('height'))
    if height:
        label = f'{height}p'
    elif chosen.get('format_note'):
        label = str(chosen.get('format_note'))
    else:
        label = str(chosen.get('format') or chosen.get('ext') or 'best')

    return {
        'format_id': chosen.get('format_id'),
        'ext': chosen.get('ext'),
        'quality_label': label,
        'height': height,
        'width': _coerce_int(chosen.get('width')),
        'fps': _coerce_int(chosen.get('fps')),
        'vcodec': chosen.get('vcodec'),
        'acodec': chosen.get('acodec'),
        'format_note': chosen.get('format_note'),
        'download_type': download_type,
        'filesize_bytes': filesize,
        'filesize_label': human_readable_bytes(filesize) if filesize is not None else None,
    }


def derive_video_download_assets(yt_info: dict) -> dict:
    """Expose the yt-dlp data needed by the dashboard's download selectors."""
    if not isinstance(yt_info, dict):
        return {'formats': [], 'subtitles': {}, 'automatic_captions': {}, 'chapters': []}
    formats = []
    for item in yt_info.get('formats') or []:
        if not isinstance(item, dict) or not item.get('format_id'):
            continue
        formats.append({
            key: item.get(key) for key in (
                'format_id', 'format_note', 'ext', 'height', 'width', 'fps',
                'vcodec', 'acodec', 'filesize', 'filesize_approx', 'tbr'
            ) if item.get(key) is not None
        })
    return {
        'formats': formats,
        'subtitles': yt_info.get('subtitles') if isinstance(yt_info.get('subtitles'), dict) else {},
        'automatic_captions': yt_info.get('automatic_captions') if isinstance(yt_info.get('automatic_captions'), dict) else {},
        'chapters': yt_info.get('chapters') if isinstance(yt_info.get('chapters'), list) else [],
    }


def analyze_job_worker(job_id: str, url: str, options: dict) -> None:
    """Background worker that performs deeper analysis for a video.

    Steps:
      - normalize url
      - fetch youtube api metadata if configured
      - run yt-dlp JSON discovery
      - attempt to fetch transcript via youtube_transcript_api
      - if transcript not available, attempt to download audio to temp and leave note for Whisper
      - store results in JOBS[job_id]
    """
    with JOBS_LOCK:
        JOBS[job_id] = {'status': 'running', 'started_at': time.time(), 'progress': [], 'result': None, 'error': None}

    try:
        # Normalize URL
        normalized = normalize_video_url(url) or url

        # Fetch API metadata if available
        try:
            cfg = load_config()
            api_key = cfg.get('youtube_api_key')
        except Exception:
            api_key = None

        api_payload = None
        if api_key:
            try:
                api_payload = fetch_youtube_video_metadata(normalized, api_key=api_key, include_comments=True)
            except Exception as e:
                api_payload = {'error': str(e)}

        JOBS[job_id]['progress'].append('fetched_api')

        # Use yt-dlp to discover formats and basic metadata
        cookiefile = None
        try:
            # Prefer explicit cookie_id passed in options
            cid = options.get('cookie_id') if isinstance(options, dict) else None
            if cid:
                with TEMP_COOKIES_LOCK:
                    meta = TEMP_COOKIES.get(cid)
                    if meta and meta.get('path'):
                        cookiefile = meta.get('path')
            # Fallback: try Opera auto-detect
            if not cookiefile and export_opera_cookies_netscape:
                try:
                    cookiefile = export_opera_cookies_netscape()
                except Exception:
                    cookiefile = None
        except Exception:
            cookiefile = None
        try:
            # Use retry wrapper with exponential backoff to handle transient network/yt-dlp failures
            def retry_run(url, attempts=3, base_delay=2):
                last = None
                for i in range(attempts):
                    res = run_yt_dlp_json(url, timeout=60, force_ipv4_on_error=True, cookiefile=cookiefile)
                    if res.get('ok'):
                        return res
                    last = res
                    delay = base_delay * (2 ** i)
                    jitter = min(5, delay * 0.2)
                    time.sleep(delay + (jitter * (0.5 - random.random())))
                return last

            import random
            runner = retry_run(normalized, attempts=3, base_delay=2)
        finally:
            # If we used an auto-detected cookiefile not managed by TEMP_COOKIES, remove it
            try:
                if cookiefile:
                    remove_managed = True
                    if isinstance(options, dict) and options.get('cookie_id'):
                        with TEMP_COOKIES_LOCK:
                            cid2 = options.get('cookie_id')
                            if cid2 in TEMP_COOKIES and TEMP_COOKIES[cid2].get('path') == cookiefile:
                                remove_managed = False
                    if remove_managed:
                        try:
                            os.unlink(cookiefile)
                        except Exception:
                            pass
            except Exception:
                pass
        if not runner.get('ok'):
            JOBS[job_id]['status'] = 'failed'
            JOBS[job_id]['error'] = runner.get('error')
            JOBS[job_id]['attempts'] = sanitize_attempts(runner.get('attempts', []))
            return

        yt_info = runner.get('data')
        JOBS[job_id]['progress'].append('yt-dlp-discovered')

        # Attempt transcript via youtube_transcript_api (preferred)
        transcript = None
        transcript_error = None
        try:
            from youtube_transcript_api import YouTubeTranscriptApi
            vid = None
            try:
                vid = get_video_id_from_url(normalized)
            except Exception:
                vid = None
            if vid:
                try:
                    transcript = YouTubeTranscriptApi.get_transcript(vid)
                except Exception as e:
                    transcript_error = str(e)
            else:
                transcript_error = 'no_video_id'
        except Exception as e:
            transcript_error = f'youtube_transcript_api_not_available: {e}'

        if transcript:
            JOBS[job_id]['progress'].append('transcript_fetched')
        else:
            JOBS[job_id]['progress'].append('transcript_missing')

        # If transcript missing, attempt to download audio for future processing and try local transcription
        audio_path = None
        if not transcript:
            try:
                outdir = str(resolve_configured_directory(
                    load_config().get('output_directory'),
                    './downloads/Single Videos',
                ))
                # Download audio as mp3 to temp file named by job id
                audio_filename = f'{job_id}.%(ext)s'
                ytdlp_path = shutil.which('yt-dlp')
                if ytdlp_path:
                    cmd = [ytdlp_path, '-x', '--audio-format', 'mp3', '-o', str(Path(outdir) / audio_filename), normalized]
                    audio_config = load_config()
                    audio_limit = adaptive_bandwidth_limit(audio_config)
                    if audio_limit is None:
                        audio_limit = int(audio_config.get('bandwidth_limit_kbps') or 0)
                    if audio_limit > 0:
                        cmd.extend(['--limit-rate', f'{audio_limit}K'])
                    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
                    if proc.returncode == 0:
                        # find downloaded file by glob
                        import glob
                        matches = glob.glob(str(Path(outdir) / (job_id + '.*')))
                        if matches:
                            audio_path = matches[0]
                            JOBS[job_id]['progress'].append('audio_downloaded')
                    else:
                        JOBS[job_id]['progress'].append('audio_download_failed')
                else:
                    JOBS[job_id]['progress'].append('yt-dlp-missing-for-audio')
            except Exception as e:
                JOBS[job_id]['progress'].append('audio_download_exception')

        # Attempt local transcription if we have audio and no transcript from API
        if not transcript and audio_path:
            # Try faster-whisper first, then openai/whisper
            transcribed_text = None
            try:
                from faster_whisper import WhisperModel
                JOBS[job_id]['progress'].append('transcription_backend_faster_whisper')
                try:
                    # load a small model; device decision can be improved based on config
                    model = WhisperModel('small', device='cpu', compute_type='int8')
                    segments, info = model.transcribe(audio_path, beam_size=5)
                    text = ''.join([s.text for s in segments])
                    transcribed_text = text
                    JOBS[job_id]['progress'].append('transcribed_faster_whisper')
                except Exception as e:
                    transcript_error = f'faster_whisper_failed: {e}'
            except Exception:
                # faster-whisper not available
                pass

            if not transcribed_text:
                try:
                    import whisper
                    JOBS[job_id]['progress'].append('transcription_backend_whisper')
                    try:
                        wmodel = whisper.load_model('small')
                        res = wmodel.transcribe(audio_path)
                        transcribed_text = res.get('text')
                        JOBS[job_id]['progress'].append('transcribed_whisper')
                    except Exception as e:
                        transcript_error = f'whisper_failed: {e}'
                except Exception:
                    # whisper not available
                    pass

            if transcribed_text:
                # Normalize into a transcript-like structure for API consistency
                transcript = [{'text': transcribed_text}]
            else:
                if not transcript_error:
                    transcript_error = 'no_transcription_backend_available'
                JOBS[job_id]['progress'].append('transcription_unavailable')

        # Build result
        result = {
            'youtube_api': api_payload,
            'yt_dlp': yt_info,
            'transcript': transcript,
            'transcript_error': transcript_error,
            'audio_path': audio_path,
        }

        JOBS[job_id]['result'] = result
        JOBS[job_id]['status'] = 'done'
        JOBS[job_id]['finished_at'] = time.time()
    except Exception as e:
        JOBS[job_id]['status'] = 'failed'
        JOBS[job_id]['error'] = str(e)
        import traceback
        JOBS[job_id]['traceback'] = traceback.format_exc()
        JOBS[job_id]['finished_at'] = time.time()


REQUIRED_DIRECTORIES = ensure_server_directories(WORKSPACE_ROOT)

# In-memory job store for long-running video analysis tasks
JOBS = {}
JOBS_LOCK = threading.Lock()

# Temporary cookies store: cookie_id -> {'path','created_at','source','domains'}
TEMP_COOKIES = {}
TEMP_COOKIES_LOCK = threading.Lock()
COOKIE_TTL = 300  # seconds; temp cookie files older than this will be removed


def _cookie_cleanup_worker():
    while True:
        now = time.time()
        to_delete = []
        with TEMP_COOKIES_LOCK:
            for cid, meta in list(TEMP_COOKIES.items()):
                if now - meta.get('created_at', 0) > COOKIE_TTL:
                    to_delete.append(cid)
        for cid in to_delete:
            try:
                with TEMP_COOKIES_LOCK:
                    meta = TEMP_COOKIES.pop(cid, None)
                if meta and meta.get('path'):
                    try:
                        os.unlink(meta['path'])
                    except Exception:
                        pass
            except Exception:
                pass
        time.sleep(30)

# start cleanup thread
_cleanup_thread = threading.Thread(target=_cookie_cleanup_worker, daemon=True)
_cleanup_thread.start()


QUALITY_MAP = {
    '1080p': 'bestvideo[height<=1080]+bestaudio/best',
    '720p': 'bestvideo[height<=720]+bestaudio/best',
    '480p': 'bestvideo[height<=480]+bestaudio/best',
    '360p': 'bestvideo[height<=360]+bestaudio/best',
    'best': 'bestvideo+bestaudio/best',
    'worst': 'worst',
}

FORMAT_MAP = {
    'mp4': 'mp4',
    'webm': 'webm',
    'audio': 'mp3',
    'mp3': 'mp3',
}

SUBTITLE_OPTIONS = {
    'none': False,
    'auto': 'auto',
    'all': 'all',
}


def build_download_options(data: dict) -> dict:
    """Build download options from dashboard form data."""
    quality = str(data.get('quality', 'best')).lower()
    fmt = str(data.get('format', 'mp4')).lower()
    subtitles = str(data.get('subtitles', 'none')).lower()
    subtitle_lang = str(data.get('subtitle_language', 'en')).strip() or 'en'
    format_id = str(data.get('format_id', '')).strip()
    cookie_id = str(data.get('cookie_id', '')).strip() if data else ''
    cookiefile = str(data.get('cookiefile', '')).strip() if data else ''
    use_browser_cookies = bool(data.get('use_browser_cookies'))

    # Normalize format
    fmt = FORMAT_MAP.get(fmt, 'mp4')

    # Handle subtitles
    download_subs = subtitles != 'none'
    sub_lang = subtitle_lang if download_subs else None

    if fmt == 'mp3':
        format_code = 'bestaudio/best'
        output_type = 'audio'
        quality_label = 'MP3 Audio'
    elif fmt == 'webm':
        format_code = 'bestvideo[ext=webm]+bestaudio[ext=webm]/best[ext=webm]'
        output_type = 'video'
        quality_label = f'WebM {quality.upper()}'
    else:  # mp4
        format_code = QUALITY_MAP.get(quality, QUALITY_MAP['best'])
        output_type = 'video'
        quality_label = f'{quality.upper()} Video' if quality in QUALITY_MAP else 'Best Video'
    if format_id and fmt != 'mp3' and all(char not in format_id for char in (' ', ';', '|', '&', '\n', '\r')):
        format_code = format_id

    return {
        'format_code': format_code,
        'output_type': output_type,
        'quality_label': quality_label,
        'format_id': format_id or None,
        'download_subs': download_subs,
        'sub_lang': sub_lang,
        'cookie_id': cookie_id,
        'cookiefile': cookiefile,
        'use_browser_cookies': use_browser_cookies,
        'concurrent_threads': max(1, min(8, int(data.get('concurrent_threads') or 3))),
        'bandwidth_limit_kbps': max(0, int(data.get('bandwidth_limit_kbps') or 0)),
        'override_adaptive_bandwidth': bool(data.get('override_adaptive_bandwidth', False)),
    }


def delete_download_record(video_id: str = '', url: str = '') -> dict:
    """Delete a history entry and its files, restricted to the configured output tree."""
    history = load_history()
    if not history.get('downloads'):
        history = get_dashboard_data().get('history', {'downloads': []})
    entries = history.get('downloads', [])
    matches = [entry for entry in entries if (
        (video_id and str(entry.get('video_id', '')) == video_id) or
        (url and str(entry.get('url', '')) == url)
    )]

    config = load_config()
    output_dir = Path(config.get('output_directory', './downloads'))
    if not output_dir.is_absolute():
        output_dir = WORKSPACE_ROOT / output_dir
    output_root = output_dir.resolve()
    if not matches and url:
        derived_id = get_video_id_from_url(url)
        if derived_id:
            matches = [
                {'video_id': derived_id, 'url': url, 'file_path': str(candidate)}
                for candidate in output_root.rglob(f'*[[]{derived_id}].*')
                if candidate.is_file()
            ]
    if not matches:
        raise FileNotFoundError('Download record not found')

    deleted_files = []
    for entry in matches:
        candidates = []
        file_path = entry.get('file_path')
        if file_path:
            candidates.append(Path(file_path))
        thumbnail_path = entry.get('thumbnail_path')
        if thumbnail_path:
            candidates.append(Path(thumbnail_path) if Path(thumbnail_path).is_absolute() else WORKSPACE_ROOT / thumbnail_path)
        for candidate in candidates:
            resolved = candidate.resolve()
            if resolved.exists() and (resolved == output_root or output_root in resolved.parents):
                if resolved.is_file():
                    resolved.unlink()
                    deleted_files.append(str(resolved))
                    # Remove subtitle/metadata sidecars created beside the video.
                    if candidate == Path(file_path):
                        for sidecar in resolved.parent.glob(f'{resolved.stem}.*'):
                            if sidecar.is_file() and sidecar != resolved:
                                sidecar.unlink()
                                deleted_files.append(str(sidecar))
    history['downloads'] = [entry for entry in entries if entry not in matches]
    save_history(history)
    return {'deleted_records': len(matches), 'deleted_files': deleted_files}


def configured_download_directory() -> Path:
    config = load_config()
    return resolve_configured_directory(
        config.get('output_directory'),
        './downloads/Single Videos',
    )


def launch_media_player(file_path: str) -> dict:
    """Launch mpv.net/mpv for a downloaded file without exposing shell execution."""
    requested = Path(file_path).expanduser()
    if not requested.is_absolute():
        requested = WORKSPACE_ROOT / requested
    target = requested.resolve()
    root = configured_download_directory().resolve()
    if not target.is_file() or (target != root and root not in target.parents):
        raise FileNotFoundError('The selected download is not available')
    executable = shutil.which('mpvnet') if os.name == 'nt' else None
    if not executable and os.name == 'nt':
        for candidate in (
            Path(os.environ.get('ProgramFiles', '')) / 'mpv.net' / 'mpvnet.exe',
            Path(os.environ.get('LOCALAPPDATA', '')) / 'Programs' / 'mpv.net' / 'mpvnet.exe',
        ):
            if candidate.is_file():
                executable = str(candidate)
                break
    executable = executable or shutil.which('mpv')
    installed = False
    if not executable:
        install_commands = []
        if os.name == 'nt':
            if shutil.which('winget'):
                install_commands.append(['winget', 'install', '--id', 'mpv.net', '--exact', '--accept-package-agreements', '--accept-source-agreements'])
            if shutil.which('choco'):
                install_commands.append(['choco', 'install', 'mpv.net', '-y', '--no-progress'])
        elif sys.platform == 'darwin':
            if shutil.which('brew'):
                install_commands.append(['brew', 'install', 'mpv'])
        else:
            if shutil.which('apt-get'):
                install_commands.append(['sudo', '-n', 'apt-get', 'install', '-y', 'mpv'])
            if shutil.which('dnf'):
                install_commands.append(['sudo', '-n', 'dnf', 'install', '-y', 'mpv'])
            if shutil.which('pacman'):
                install_commands.append(['sudo', '-n', 'pacman', '-Sy', '--noconfirm', 'mpv'])
        install_errors = []
        for command in install_commands:
            try:
                result = subprocess.run(
                    command, cwd=str(WORKSPACE_ROOT), capture_output=True, text=True,
                    encoding='utf-8', errors='replace', timeout=300, shell=False,
                )
                if result.returncode == 0:
                    installed = True
                    break
                install_errors.append((result.stderr or result.stdout or 'package manager failed').strip()[-500:])
            except (OSError, subprocess.SubprocessError) as exc:
                install_errors.append(str(exc))
        if os.name == 'nt':
            executable = shutil.which('mpvnet') or shutil.which('mpv')
            if not executable:
                for candidate in (
                    Path(os.environ.get('ProgramFiles', '')) / 'mpv.net' / 'mpvnet.exe',
                    Path(os.environ.get('LOCALAPPDATA', '')) / 'Programs' / 'mpv.net' / 'mpvnet.exe',
                ):
                    if candidate.is_file():
                        executable = str(candidate)
                        break
        else:
            executable = shutil.which('mpv')
        if not executable:
            detail = install_errors[-1] if install_errors else 'No supported package manager was found'
            raise FileNotFoundError(f'Unable to install mpv automatically: {detail}')
    if not executable:
        raise FileNotFoundError('mpv.net/mpv was not found on PATH. Install mpv.net on Windows or mpv on Linux/macOS.')
    subprocess.Popen(
        [executable, str(target)],
        cwd=str(target.parent),
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        shell=False,
        close_fds=os.name != 'nt',
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0) if os.name == 'nt' else 0,
    )
    return {'launched': True, 'installed': installed, 'player': Path(executable).name, 'file': str(target)}


def list_download_files() -> list:
    root = configured_download_directory()
    if not root.exists():
        return []
    files = []
    for file_path in root.rglob('*'):
        if file_path.is_file():
            files.append({
                'name': file_path.name,
                'path': file_path.relative_to(root).as_posix(),
                'size': file_path.stat().st_size,
                'modified_at': file_path.stat().st_mtime,
                'url': '/downloads/' + quote(file_path.relative_to(root).as_posix(), safe='/'),
            })
    return files


def send_json_response(handler: BaseHTTPRequestHandler, status_code: int, payload: dict) -> None:
    """Send a JSON response with proper headers.

    Guard against client disconnects (ConnectionAbortedError / BrokenPipeError) so the server
    doesn't crash or spam tracebacks when the client times out or disconnects while a long
    running request finishes.
    """
    body = json.dumps(payload).encode('utf-8')
    try:
        handler.send_response(status_code)
        handler.send_header('Content-Type', 'application/json; charset=utf-8')
        handler.send_header('Access-Control-Allow-Origin', '*')
        handler.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        handler.send_header('Access-Control-Allow-Headers', 'Content-Type')
        handler.send_header('Content-Length', str(len(body)))
        # Permit embedding of API responses inside iframes proxied by this server
        handler.send_header('Content-Security-Policy', 'frame-ancestors *;')
        handler.send_header('X-Frame-Options', 'ALLOWALL')
        handler.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        handler.end_headers()
        try:
            handler.wfile.write(body)
        except (BrokenPipeError, ConnectionAbortedError) as e:
            # Browser cancellations are expected during iframe navigation.
            pass
    except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError, OSError) as e:
        # Client disconnected while headers or data were being written. This is a normal network
        # race during browser refreshes, timeouts, or cancelled requests on Windows/macOS/Linux.
        if getattr(e, 'winerror', None) not in (10053, 10054):
            print(f'Client disconnected while sending JSON response: {e}')
        try:
            handler.connection.close()
        except Exception:
            pass
    except Exception as e:
        # If sending headers fails for a genuinely unexpected reason, log and swallow to avoid crashing.
        print(f'Error while sending JSON response: {e}')
        try:
            handler.connection.close()
        except Exception:
            pass


def write_response_body(handler: BaseHTTPRequestHandler, body: bytes) -> bool:
    """Write an already-initialized response without logging normal disconnects."""
    try:
        handler.wfile.write(body)
        return True
    except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError, OSError) as exc:
        if not is_client_disconnect(exc):
            print(f'Error while writing response body: {exc}')
        try:
            handler.connection.close()
        except OSError:
            pass
        return False


def is_client_disconnect(error: BaseException) -> bool:
    """Identify normal browser cancellation errors from socket writes."""
    return isinstance(error, (BrokenPipeError, ConnectionAbortedError, ConnectionResetError)) or getattr(error, 'winerror', None) in (10053, 10054)


def normalize_proxy_target(url: str) -> Optional[str]:
    if not url or not isinstance(url, str):
        return None
    url = url.strip()
    if not url:
        return None
    if not url.lower().startswith(('http://', 'https://')):
        return None
    try:
        parsed = urlparse(url)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password:
            return None
        if parsed.port is not None and not 1 <= parsed.port <= 65535:
            return None
        # Fragments never reach the remote server and can create broken proxy cache keys.
        return parsed._replace(fragment='').geturl()
    except ValueError:
        return None


def normalize_download_target(url: str) -> Optional[str]:
    if not isinstance(url, str):
        return None
    candidate = url.strip()
    if not candidate.lower().startswith(('http://', 'https://')):
        return None
    try:
        parsed = urlparse(candidate)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname:
            return None
        return candidate
    except ValueError:
        return None


def inject_html_base(html_text: str, base_href: str) -> str:
    if not html_text or not base_href:
        return html_text
    head_match = re.search(r'<head[^>]*>', html_text, flags=re.IGNORECASE)
    base_tag = f'<base href="{html.escape(base_href, quote=True)}">'
    if head_match:
        insert_pos = head_match.end()
        return html_text[:insert_pos] + base_tag + html_text[insert_pos:]

    html_match = re.search(r'<html[^>]*>', html_text, flags=re.IGNORECASE)
    if html_match:
        insert_pos = html_match.end()
        return html_text[:insert_pos] + '<head>' + base_tag + '</head>' + html_text[insert_pos:]

    return '<head>' + base_tag + '</head>' + html_text


def remove_csp_meta(html_text: str) -> str:
    if not html_text:
        return html_text
    # Remove any HTML-level meta tags that try to block framing or inject CSP restrictions.
    return re.sub(
        r'<meta[^>]+http-equiv\s*=\s*["\'](?:content-security-policy|x-frame-options|x-content-security-policy|x-webkit-csp)["\'][^>]*>',
        '',
        html_text,
        flags=re.IGNORECASE,
    )


def should_rewrite_url(value: str) -> bool:
    if not value or not isinstance(value, str):
        return False
    trimmed = value.strip()
    lower = trimmed.lower()
    if not trimmed:
        return False
    if lower.startswith(('javascript:', 'mailto:', 'tel:', 'data:', 'blob:', 'filesystem:', 'vbscript:')):
        return False
    if trimmed.startswith('#'):
        return False
    return True


def resolve_proxy_target_url(base_href: str, target: str) -> Optional[str]:
    if not should_rewrite_url(target):
        return None
    try:
        # Preserve scheme-relative URLs
        if target.startswith('//'):
            parsed_base = urlparse(base_href)
            target = f'{parsed_base.scheme}:{target}'
        resolved = urljoin(base_href, target)
        if resolved.lower().startswith(('http://', 'https://')):
            return resolved
    except Exception:
        pass
    return None


def proxy_url_for(target: str) -> str:
    return f'/proxy?url={quote(target, safe="")}'


def rewrite_html_links(html_text: str, base_href: str) -> str:
    if not html_text or not base_href:
        return html_text

    def rewrite_attr(match):
        attr = match.group('attr')
        quote = match.group('quote')
        url = match.group('url')
        if not should_rewrite_url(url):
            return match.group(0)
        resolved = resolve_proxy_target_url(base_href, url)
        if not resolved:
            return match.group(0)
        # Avoid double proxying local proxy URLs.
        parsed = urlparse(resolved)
        if parsed.path == '/proxy' and parse_qs(parsed.query).get('url'):
            return match.group(0)
        return f'{attr}{quote}{proxy_url_for(resolved)}{quote}'

    def rewrite_srcset(match):
        value = match.group('value')
        parts = [part.strip() for part in value.split(',') if part.strip()]
        rewritten = []
        for part in parts:
            if ' ' in part:
                candidate, descriptor = part.split(None, 1)
            else:
                candidate, descriptor = part, ''
            if should_rewrite_url(candidate):
                resolved = resolve_proxy_target_url(base_href, candidate)
                if resolved:
                    candidate = proxy_url_for(resolved)
            rewritten.append(candidate + (f' {descriptor}' if descriptor else ''))
        return f'{match.group("prefix")}{match.group("quote")}{", ".join(rewritten)}{match.group("quote")}'

    html_text = re.sub(r'(?P<attr>\b(?:href|src|action)\s*=\s*)(?P<quote>["\'])(?P<url>.*?)(?P=quote)', rewrite_attr, html_text, flags=re.IGNORECASE)
    html_text = re.sub(r'(?P<prefix>\bsrcset\s*=\s*)(?P<quote>["\'])(?P<value>.*?)(?P=quote)', rewrite_srcset, html_text, flags=re.IGNORECASE | re.DOTALL)
    return html_text


def inject_proxy_navigation_script(html_text: str) -> str:
    if not html_text:
        return html_text
    script = '''<script>(function(){
      const proxyBase = location.origin;
      const endpoint = proxyBase + '/proxy?url=';
      function shouldProxy(value){
        if(!value) return false;
        const trimmed = value.trim();
        const lower = trimmed.toLowerCase();
        return !(!trimmed || lower.startsWith('javascript:') || lower.startsWith('mailto:') || lower.startsWith('tel:') || lower.startsWith('data:') || lower.startsWith('blob:') || lower.startsWith('filesystem:') || trimmed.startsWith('#'));
      }
      function normalize(value){
        try{return new URL(value, document.baseURI).href}catch(e){return null}
      }
      function proxyUrl(value){
        const resolved = normalize(value);
        if(!resolved) return null;
        if(resolved.includes('/proxy?url=')) return resolved;
        return endpoint + encodeURIComponent(resolved);
      }
      function rewriteUrl(value){
        if(typeof value !== 'string') return value;
        const proxied = proxyUrl(value);
        return proxied || value;
      }
      document.addEventListener('click', function(event){
        const anchor = event.target.closest('a');
        if(!anchor||!anchor.getAttribute) return;
        const href = anchor.getAttribute('href');
        if(!shouldProxy(href)) return;
        const proxied = proxyUrl(href);
        if(proxied){
          event.preventDefault();
          window.location.href = proxied;
        }
      }, true);
      document.addEventListener('submit', function(event){
        const form = event.target;
        if(!(form instanceof HTMLFormElement)) return;
        const action = form.getAttribute('action') || document.location.href;
        if(!shouldProxy(action)) return;
        if((form.method||'get').toLowerCase() !== 'get') return;
        event.preventDefault();
        const params = new URLSearchParams(new FormData(form));
        const url = normalize(action);
        if(!url) return;
        const proxied = endpoint + encodeURIComponent(url + (params.toString() ? ('?' + params.toString()) : ''));
        window.location.href = proxied;
      }, true);
      const originalFetch = window.fetch.bind(window);
      if (originalFetch) {
        window.fetch = function(input, init){
          let url = input;
          if (typeof input === 'object' && input && input.url) {
            url = input.url;
          }
          if (typeof url === 'string') {
            const proxied = proxyUrl(url);
            if (proxied) {
              if (typeof input === 'string') {
                return originalFetch(proxied, init);
              }
              const nextInput = Object.assign({}, input, {url: proxied});
              return originalFetch(nextInput, init);
            }
          }
          return originalFetch(input, init);
        };
      }
      const originalOpen = XMLHttpRequest.prototype.open;
      XMLHttpRequest.prototype.open = function(method, url, async, user, password){
        const proxied = typeof url === 'string' ? proxyUrl(url) : null;
        if (proxied) {
          return originalOpen.call(this, method, proxied, async, user, password);
        }
        return originalOpen.call(this, method, url, async, user, password);
      };
      const originalPushState = history.pushState.bind(history);
      history.pushState = function(state, title, url){
        return originalPushState(state, title, rewriteUrl(url));
      };
      const originalReplaceState = history.replaceState.bind(history);
      history.replaceState = function(state, title, url){
        return originalReplaceState(state, title, rewriteUrl(url));
      };
      const originalOpenWindow = window.open;
      if (originalOpenWindow) {
        window.open = function(url, target, features){
          const proxied = typeof url === 'string' ? proxyUrl(url) : null;
          if (proxied) {
            return originalOpenWindow.call(this, proxied, target, features);
          }
          return originalOpenWindow.call(this, url, target, features);
        };
      }
    })();</script>'''
    head_match = re.search(r'<head[^>]*>', html_text, flags=re.IGNORECASE)
    if head_match:
        insert_pos = head_match.end()
        return html_text[:insert_pos] + script + html_text[insert_pos:]
    html_match = re.search(r'<html[^>]*>', html_text, flags=re.IGNORECASE)
    if html_match:
        insert_pos = html_match.end()
        return html_text[:insert_pos] + '<head>' + script + '</head>' + html_text[insert_pos:]
    return script + html_text


def serve_static_file(handler: BaseHTTPRequestHandler, path: str) -> bool:
    """Serve a local file or directory listing from the workspace root."""
    normalized_path = unquote(path.lstrip('/'))
    web_root = resolve_configured_directory(load_config().get('web_directory'), './web')
    if normalized_path == 'dashboard.html':
        safe_path = (web_root / normalized_path).resolve()
    elif normalized_path == 'favicon.ico':
        safe_path = (resolve_configured_directory(
            load_config().get('favicon_directory'),
            './web/assets',
        ) / 'favicon.ico').resolve()
    else:
        safe_path = (WORKSPACE_ROOT / normalized_path).resolve()

    try:
        # Security: Ensure path is within workspace
        try:
            safe_path.relative_to(WORKSPACE_ROOT)
        except ValueError:
            print(f'Security: Path outside workspace: {safe_path}')
            return False

        if safe_path.exists() and safe_path.is_dir():
            index_path = safe_path / 'index.html'
            if index_path.exists() and index_path.is_file():
                body = index_path.read_bytes()
                content_type = 'text/html; charset=utf-8'
            else:
                listing = '<html><body><h1>Directory listing</h1><ul>'
                for child in sorted(safe_path.iterdir()):
                    rel = child.name
                    listing += f'<li><a href="/{normalized_path}/{rel}">{rel}</a></li>'
                listing += '</ul></body></html>'
                body = listing.encode('utf-8')
                content_type = 'text/html; charset=utf-8'

            handler.send_response(200)
            handler.send_header('Content-Type', content_type)
            handler.send_header('Content-Length', str(len(body)))
            handler.send_header('Access-Control-Allow-Origin', '*')
            # Ensure embedded contexts can display this listing
            handler.send_header('Content-Security-Policy', 'frame-ancestors *;')
            handler.send_header('X-Frame-Options', 'ALLOWALL')
            handler.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            handler.end_headers()
            handler.wfile.write(body)
            return True

        if not safe_path.exists() or not safe_path.is_file():
            print(f'File not found: {safe_path}')
            return False

        body = safe_path.read_bytes()
        content_type = mimetypes.guess_type(str(safe_path))[0] or 'application/octet-stream'
        handler.send_response(200)
        handler.send_header('Content-Type', content_type)
        handler.send_header('Content-Length', str(len(body)))
        handler.send_header('Access-Control-Allow-Origin', '*')
        # Ensure embedding is allowed for served static files
        handler.send_header('Content-Security-Policy', 'frame-ancestors *;')
        handler.send_header('X-Frame-Options', 'ALLOWALL')
        if content_type.startswith('text/html'):
            handler.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        else:
            handler.send_header('Cache-Control', 'public, max-age=3600')
        handler.end_headers()
        handler.wfile.write(body)
        return True
    except Exception as e:
        print(f'Error serving file {path}: {e}')
        return False


def fetch_via_proxy(handler: BaseHTTPRequestHandler, target_url: str) -> bool:
    """Fetch a remote URL and return it through the local server while stripping frame-blocking headers."""
    try:
        parsed = urlparse(target_url)
        if parsed.scheme not in ('http', 'https'):
            send_json_response(handler, 400, {'error': 'Unsupported URL scheme', 'url': target_url})
            return True
        if not parsed.hostname:
            send_json_response(handler, 400, {'error': 'Proxy target has no hostname', 'url': target_url})
            return True

        req = urllib.request.Request(target_url, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
            # Keep the response body readable; the proxy does not implement decompression.
            'Accept-Encoding': 'identity',
        })
        with urllib.request.urlopen(req, timeout=30) as resp:
            status = resp.status
            final_url = resp.geturl() or target_url
            # Normalize header keys to lower-case and intentionally DO NOT forward remote framing/CSP headers.
            headers = {k.lower(): v for k, v in resp.getheaders()}
            # Explicitly remove headers that can prevent embedding or otherwise interfere with the proxy.
            headers.pop('x-frame-options', None)
            headers.pop('content-security-policy', None)
            headers.pop('x-content-security-policy', None)
            headers.pop('x-webkit-csp', None)
            content = resp.read()

        content_type = headers.get('content-type', 'application/octet-stream')
        is_html = 'text/html' in content_type or 'application/xhtml+xml' in content_type

        if is_html:
            remember_proxy_context(handler, final_url)
            charset = 'utf-8'
            for part in content_type.split(';'):
                part = part.strip()
                if part.lower().startswith('charset='):
                    charset = part.split('=', 1)[1].strip()
                    break
            text = content.decode(charset, errors='replace')
            text = inject_html_base(text, final_url)
            text = remove_csp_meta(text)
            text = rewrite_html_links(text, final_url)
            text = inject_proxy_navigation_script(text)
            content = text.encode(charset, errors='replace')
            content_type = f'text/html; charset={charset}'

        handler.send_response(status)
        handler.send_header('Content-Type', content_type)
        handler.send_header('Content-Length', str(len(content)))
        handler.send_header('Access-Control-Allow-Origin', '*')
        # Ensure the proxied response allows embedding by explicitly setting a permissive frame-ancestors policy
        handler.send_header('Content-Security-Policy', 'frame-ancestors *;')
        # Explicitly set an embedding-friendly X-Frame-Options for clients that still inspect it.
        # Note: 'ALLOWALL' is non-standard but used here to avoid sending DENY/SAMEORIGIN from upstream.
        handler.send_header('X-Frame-Options', 'ALLOWALL')
        handler.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        # Also mirror any other safe headers from the upstream response (e.g., cookies) when appropriate
        # but always avoid forwarding upstream framing/CSP headers that may block embedding.
        try:
            handler.end_headers()
            handler.wfile.write(content)
        except OSError as exc:
            if is_client_disconnect(exc):
                return True
            raise
        return True
    except urllib.error.HTTPError as e:
        body = e.read() if hasattr(e, 'read') else b''
        try:
            handler.send_response(e.code)
            handler.send_header('Content-Type', e.headers.get_content_type() if hasattr(e.headers, 'get_content_type') else 'text/plain; charset=utf-8')
            handler.send_header('Access-Control-Allow-Origin', '*')
            handler.send_header('Content-Security-Policy', 'frame-ancestors *;')
            handler.send_header('X-Frame-Options', 'ALLOWALL')
            handler.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            handler.end_headers()
            handler.wfile.write(body)
        except OSError as write_error:
            if is_client_disconnect(write_error):
                return True
            raise
        return True
    except urllib.error.URLError as e:
        reason = getattr(e, 'reason', e)
        if isinstance(reason, socket.gaierror):
            message = f'Unable to resolve the remote host for {urlparse(target_url).hostname or "the proxy target"}'
        elif isinstance(reason, TimeoutError):
            message = 'The remote host did not respond before the proxy timed out'
        else:
            message = f'Unable to reach the remote URL: {reason}'
        try:
            send_json_response(handler, 502, {
                'error': 'Proxy target unavailable',
                'message': message,
                'url': target_url,
            })
        except OSError as write_error:
            if not is_client_disconnect(write_error):
                raise
        return True
    except OSError as e:
        if is_client_disconnect(e):
            return True
        raise
    except Exception as e:
        try:
            send_json_response(handler, 502, {'error': 'Failed to proxy remote URL', 'message': str(e)})
        except OSError as write_error:
            if not is_client_disconnect(write_error):
                raise
        return True


def process_download_request(url: str, options: dict) -> None:
    """Process a download request in a background thread.

    Supports per-request cookie handling via these keys in `options`:
    - cookie_id: a temporary cookie id previously returned by /api/cookies/upload or /api/cookies/use-browser
    - cookiefile: a direct path to a cookies.txt file (use with caution)
    - use_browser_cookies: when true, attempt to auto-export Opera cookies via helper
    """
    progress_id = str(options.get('progress_id') or '')
    try:
        url = normalize_download_target(url)
        if not url:
            print('Rejected malformed download target before yt-dlp processing')
            finish_download_tracking(progress_id, 'failed', url or 'invalid target')
            return
        if download_cancel_requested(progress_id):
            finish_download_tracking(progress_id, 'cancelled', url)
            return
        set_download_progress(progress_id, {
            'status': 'downloading',
            'stage': 'starting',
            'title': url,
            'url': url,
        })
        config = load_config()
        if options.get('concurrent_threads'):
            config['concurrent_threads'] = max(1, min(8, int(options['concurrent_threads'])))
        if options.get('bandwidth_limit_kbps') is not None:
            config['bandwidth_limit_kbps'] = max(0, int(options.get('bandwidth_limit_kbps') or 0))
        if options.get('override_adaptive_bandwidth'):
            config['adaptive_bandwidth_enabled'] = False
        history = load_history() if config.get('enable_history', True) else {'downloads': []}

        # Per-request cookie handling: prefer explicit cookiefile or cookie_id, else optionally auto-detect
        _auto_cookie_to_delete = None
        try:
            # Direct cookiefile path passed in options (explicit)
            if options.get('cookiefile'):
                config['cookie_file'] = options.get('cookiefile')
            # cookie_id referencing a managed temporary cookie stored by the server
            elif options.get('cookie_id'):
                cid = options.get('cookie_id')
                with TEMP_COOKIES_LOCK:
                    meta = TEMP_COOKIES.get(cid)
                    if meta and meta.get('path'):
                        config['cookie_file'] = meta.get('path')
            # If requested, try to auto-detect Opera cookies (non-managed temporary file)
            elif options.get('use_browser_cookies'):
                if export_opera_cookies_netscape:
                    try:
                        cf = export_opera_cookies_netscape()
                        if cf:
                            config['cookie_file'] = cf
                            _auto_cookie_to_delete = cf
                    except Exception:
                        pass
        except Exception:
            # Don't fail the whole download if cookie resolution fails; continue without cookies
            pass

        videos = extract_playlist_videos(url)
        if download_cancel_requested(progress_id):
            finish_download_tracking(progress_id, 'cancelled', url)
            return
        if not videos:
            print(f'No videos found in URL: {url}')
            # Clean up any auto-created cookiefile
            if _auto_cookie_to_delete:
                try:
                    os.unlink(_auto_cookie_to_delete)
                except Exception:
                    pass
            finish_download_tracking(progress_id, 'failed', url)
            return

        output_dir = str(resolve_configured_directory(
            load_config().get('output_directory'),
            './downloads/Single Videos',
        ))
        results = download_videos(
            videos,
            output_dir,
            options['format_code'],
            options['output_type'],
            options['quality_label'],
            history,
            config,
            options['download_subs'],
            options['sub_lang'],
            progress_id=progress_id,
        )

        # Clean up any auto-created cookiefile (not managed by TEMP_COOKIES)
        if _auto_cookie_to_delete:
            try:
                os.unlink(_auto_cookie_to_delete)
            except Exception:
                pass

        if config.get('enable_history', True):
            save_history(history)
        if any(item.get('status') == 'downloaded' for item in results):
            final_status = 'completed'
        elif any(item.get('status') == 'cancelled' for item in results):
            final_status = 'cancelled'
        else:
            final_status = 'failed'
        finish_download_tracking(progress_id, final_status, url)
    except Exception as e:
        print(f'Error processing download: {e}')
        import traceback
        traceback.print_exc()
        finish_download_tracking(progress_id, 'failed', url if isinstance(url, str) else 'download')


class BotApiHandler(BaseHTTPRequestHandler):
    """HTTP request handler for Bot API and dashboard."""

    def do_OPTIONS(self):
        """Handle CORS preflight requests."""
        self.send_response(204)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        # Permit embedding the responses that follow CORS preflight (useful for iframe-driven clients)
        self.send_header('Content-Security-Policy', 'frame-ancestors *;')
        self.send_header('X-Frame-Options', 'ALLOWALL')
        self.end_headers()

    def do_GET(self):
        """Handle GET requests for files and API endpoints."""
        path = unquote(urlparse(self.path).path)
        print(f'GET request: {path}')
        try:
            # Keep the page's connectivity probe independent from optional
            # security/runtime initialization performed for other endpoints.
            if path in ('/health', '/api/health'):
                send_json_response(self, 200, {'status': 'ok', 'message': 'health check'})
                return
            bot_module = __import__('Bot')
            if getattr(bot_module, 'LOCKOFF_MODE', False):
                send_json_response(self, 403, {
                    'error': 'System lock-off active',
                    'lockoff_mode': True,
                    'complete_lockoff': getattr(bot_module, 'COMPLETE_LOCKOFF_MODE', False),
                    'state_reestablished': getattr(bot_module, 'LOCKOFF_STATE_REESTABLISHED', False),
                    'message': getattr(bot_module, 'LOCKOFF_REASON', '') or LOCKOFF_MESSAGE,
                })
                return
            record_connected_device(self)
            # Compatibility aliases: older scripts and dashboard versions sometimes call these without /api.
            compat_aliases = {
                '/health': '/api/health',
                '/stats': '/api/stats',
                '/history': '/api/history',
                '/presets': '/api/presets',
                '/diagnostics': '/api/diagnostics',
                '/downloads/status': '/api/downloads/status',
                '/downloads/stream': '/api/downloads/stream',
                '/video/inspect': '/api/video/inspect',
                '/video/live': '/api/video/live',
                '/cookies/status': '/api/cookies/status',
                '/resource-monitor': '/api/resource-monitor',
            }
            if path in compat_aliases:
                path = compat_aliases[path]
            elif path.startswith('/video/job/'):
                path = '/api' + path
            elif path == '/api':
                send_json_response(self, 200, {
                    'status': 'ok',
                    'service': 'Multimedia Handler',
                    'health': '/api/health',
                })
                return
            # File downloads and their metadata are intentionally public to trusted LAN clients.
            # All other API reads, including download status/stream endpoints, remain protected.
            if (
                path.startswith('/api/')
                and path not in (
                    '/api/health',
                    '/api/presets',
                    '/api/downloads/files',
                    '/api/auth/status',
                )
                and not require_auth(self)
            ):
                return
            if path == '/api/auth/status':
                user = session_user(self)
                send_json_response(self, 200, {
                    'authenticated': bool(user),
                    'role': 'root' if user == ROOT_USER else 'admin' if user == AUTH_USER else 'user' if user else None,
                    'username': user,
                    'local_host': is_local_host_request(self),
                    'permissions': sorted(_account_permissions(user)),
                })
                return
            if path == '/api/preferences':
                send_json_response(self, 200, {'preferences': dashboard_preferences(self)})
                return
            if path == '/api/activity':
                query = parse_qs(urlparse(self.path).query)
                limit = (query.get('limit') or ['100'])[0]
                send_json_response(self, 200, {'activities': activity_records(self, int(limit))})
                return
            if path == '/api/downloads/analytics':
                send_json_response(self, 200, download_analytics_snapshot())
                return
            if path == '/api/activity/export':
                query = parse_qs(urlparse(self.path).query)
                limit = int((query.get('limit') or ['500'])[0])
                output = io.StringIO()
                writer = csv.writer(output)
                writer.writerow(['timestamp', 'action', 'details'])
                for item in activity_records(self, limit):
                    writer.writerow([
                        time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(item['created_at'])),
                        item['action'],
                        item['details'],
                    ])
                body = output.getvalue().encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'text/csv; charset=utf-8')
                self.send_header('Content-Disposition', 'attachment; filename="video-retriever-activity.csv"')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if path.startswith('/api/spotify/jobs/'):
                if not require_auth(self):
                    return
                job = spotify_job_snapshot(path.rsplit('/', 1)[-1])
                if not job:
                    send_json_response(self, 404, {'error': 'Spotify job not found'})
                    return
                send_json_response(self, 200, {'job': job})
                return
            if path == '/api/extensions/status':
                extension_root = browser_extension_directory()
                manifest_path = extension_root / 'manifest.json'
                send_json_response(self, 200, {
                    'installed': manifest_path.is_file(),
                    'directory': str(extension_root),
                    'manifest': json.loads(manifest_path.read_text(encoding='utf-8')) if manifest_path.is_file() else None,
                })
                return
            if path in ('/api/root/devices/permissions', '/api/root/accounts'):
                if not is_root_session(self):
                    send_json_response(self, 403, {'error': 'Root access on the hosting device is required'})
                    return
                send_json_response(self, 200, {
                    'policies': _device_policies(),
                    'connected_devices': list(CONNECTED_DEVICES.values()),
                    'accounts': account_audit_records(),
                    'root_hostname': socket.getfqdn(),
                })
                return
            if path == '/api/network/devices':
                if not is_root_session(self):
                    send_json_response(self, 403, {'error': 'Root access on the hosting device is required'})
                    return
                remote_ip = request_client_ip(self)
                try:
                    hostname = socket.gethostbyaddr(remote_ip)[0]
                except (socket.herror, socket.gaierror):
                    hostname = remote_ip
                root_hostname = socket.getfqdn()
                root_ip = detect_private_ip()
                send_json_response(self, 200, {
                    'host_device': {
                        'hostname': root_hostname,
                        'ip': root_ip,
                        'label': f'{root_hostname} [ROOT HOST]',
                        'role': 'root',
                    },
                    'requesting_device': {'ip': remote_ip, 'hostname': hostname},
                    'connected_devices': list(CONNECTED_DEVICES.values()),
                    'trusted_subnet': TRUSTED_SUBNET,
                    'root_identity': f'{root_hostname} [ROOT HOST @ {root_ip}]',
                })
                return
            if path == '/api/network/scan':
                if not is_root_session(self):
                    send_json_response(self, 403, {'error': 'Root access on the hosting device is required'})
                    return
                try:
                    devices = scan_nearby_devices()
                    send_json_response(self, 200, {
                        'devices': devices,
                        'scanned_at': time.time(),
                        'method': 'local ARP cache',
                    })
                    record_activity(self, 'network_scan', f'{len(devices)} nearby devices discovered')
                except RuntimeError as exc:
                    send_json_response(self, 503, {'error': str(exc)})
                return
            # Provide client-side presets (qualities/formats) to keep extension in sync
            if path == '/api/presets':
                try:
                    send_json_response(self, 200, {
                        'qualities': list(QUALITY_MAP.keys()),
                        'format_map': FORMAT_MAP,
                        'quality_map': QUALITY_MAP,
                    })
                except Exception as e:
                    send_json_response(self, 500, {'error': str(e)})
                return
            # Diagnostics endpoint: lightweight checks to help debug backend issues
            if path == '/api/diagnostics':
                try:
                    diag = {
                        'status': 'ok',
                        'hostname': socket.getfqdn(),
                        'host_ip': detect_private_ip(),
                        'python_version': sys.version.split()[0],
                        'os': platform.system(),
                        'package_manager': detect_package_manager(),
                    }
                    # Workspace root
                    try:
                        diag['workspace_root'] = str(WORKSPACE_ROOT)
                    except Exception as e:
                        diag['workspace_root_error'] = str(e)
                    # Config load
                    try:
                        cfg = load_config()
                        diag['config_loaded'] = True
                        diag['config_keys'] = list(cfg.keys())[:20]
                        # Report whether YouTube API key is present (do not reveal the key)
                        try:
                            diag['youtube_api_key_present'] = bool(cfg.get('youtube_api_key'))
                        except Exception:
                            diag['youtube_api_key_present'] = False
                    except Exception as e:
                        diag['config_loaded'] = False
                        diag['config_error'] = str(e)
                    # History load
                    try:
                        history = load_history() if cfg.get('enable_history', True) else {'downloads': []}
                        diag['history_count'] = len(history.get('downloads', []))
                    except Exception as e:
                        diag['history_error'] = str(e)
                    # Downloads directory
                    try:
                        outdir = Path(cfg.get('output_directory', './downloads'))
                        outpath = outdir if outdir.is_absolute() else WORKSPACE_ROOT / outdir
                        diag['downloads_path'] = str(outpath)
                        diag['downloads_exists'] = outpath.exists()
                    except Exception as e:
                        diag['downloads_error'] = str(e)
                    # yt_dlp availability
                    try:
                        import yt_dlp as _ydl
                        diag['yt_dlp'] = True
                    except Exception as e:
                        diag['yt_dlp'] = False
                        diag['yt_dlp_error'] = str(e)
                    # yt-dlp CLI presence
                    try:
                        diag['yt_dlp_cli'] = bool(shutil.which('yt-dlp'))
                    except Exception:
                        diag['yt_dlp_cli'] = False
                    # youtube_transcript_api
                    try:
                        import youtube_transcript_api as _yta
                        diag['youtube_transcript_api'] = True
                    except Exception as e:
                        diag['youtube_transcript_api'] = False
                        diag['youtube_transcript_api_error'] = str(e)
                    # pytube
                    try:
                        import pytube as _pt
                        diag['pytube'] = True
                    except Exception as e:
                        diag['pytube'] = False
                        diag['pytube_error'] = str(e)
                    # faster-whisper
                    try:
                        import faster_whisper as _fw
                        diag['faster_whisper'] = True
                    except Exception as e:
                        diag['faster_whisper'] = False
                        diag['faster_whisper_error'] = str(e)
                    # openai whisper
                    try:
                        import whisper as _w
                        diag['whisper'] = True
                    except Exception as e:
                        diag['whisper'] = False
                        diag['whisper_error'] = str(e)
                    # Opera GX cookies availability (best-effort)
                    try:
                        if export_opera_cookies_netscape:
                            cf = export_opera_cookies_netscape()
                            if cf:
                                diag['opera_cookies_available'] = True
                                try:
                                    os.unlink(cf)
                                except Exception:
                                    pass
                            else:
                                diag['opera_cookies_available'] = False
                        else:
                            diag['opera_cookies_available'] = False
                    except Exception as e:
                        diag['opera_cookies_available'] = False
                        diag['opera_cookies_error'] = str(e)
                    send_json_response(self, 200, diag)
                except Exception as e:
                    send_json_response(self, 500, {'error': 'Diagnostics failed', 'message': str(e)})
                return
            if path == '/api/resource-monitor':
                if not require_auth(self):
                    return
                send_json_response(self, 200, resource_monitor_snapshot())
                return
            if path == '/api/dependencies/status':
                if not require_auth(self):
                    return
                with DEPENDENCY_STATUS_LOCK:
                    dependency_status = dict(DEPENDENCY_STATUS)
                    dependency_status['outdated'] = list(DEPENDENCY_STATUS.get('outdated', []))
                    dependency_status['missing'] = list(DEPENDENCY_STATUS.get('missing', []))
                    dependency_status['install_events'] = list(DEPENDENCY_STATUS.get('install_events', []))
                send_json_response(self, 200, dependency_status)
                return
            if path == '/api/spotify/overview':
                if not require_auth(self):
                    return
                send_json_response(self, 200, {'jobs': spotify_job_overview()})
                return
            if path == '/api/dependencies/update':
                if not require_auth(self, 'control'):
                    return
                content_length = int(self.headers.get('Content-Length', 0))
                payload = json.loads(self.rfile.read(content_length).decode('utf-8')) if content_length else {}
                packages = payload.get('packages') or []
                if not isinstance(packages, list) or not all(isinstance(package, str) for package in packages):
                    send_json_response(self, 400, {'error': 'packages must be a list of package names'})
                    return
                try:
                    result = update_python_dependencies(packages)
                except (OSError, subprocess.SubprocessError, ValueError, RuntimeError) as exc:
                    send_json_response(self, 502, {'error': 'Python dependency update failed', 'message': str(exc)})
                    return
                send_json_response(self, 200, result)
                return
            # API Endpoint: Cookies status
            if path == '/api/cookies/status':
                try:
                    with TEMP_COOKIES_LOCK:
                        items = []
                        for cid, meta in TEMP_COOKIES.items():
                            items.append({
                                'cookie_id': cid,
                                'source': meta.get('source'),
                                'created_at': meta.get('created_at'),
                                'domains': meta.get('domains', [])
                            })
                    send_json_response(self, 200, {'cookies': items, 'auto_detect_supported': bool(export_opera_cookies_netscape)})
                except Exception as e:
                    send_json_response(self, 500, {'error': str(e)})
                return

            # API Endpoint: Download progress/status for UI polling
            if path in ('/api/downloads/stream', '/downloads/stream'):
                # Server-Sent Events (SSE) stream that emits the full progress registry whenever it changes.
                self.send_response(200)
                self.send_header('Content-Type', 'text/event-stream')
                self.send_header('Cache-Control', 'no-cache')
                self.send_header('Access-Control-Allow-Origin', '*')
                # Allow embedding of the SSE stream in proxied iframes
                self.send_header('Content-Security-Policy', 'frame-ancestors *;')
                self.send_header('X-Frame-Options', 'ALLOWALL')
                self.send_header('Connection', 'keep-alive')
                self.end_headers()
                try:
                    last_payload = None
                    while True:
                        progress = get_all_download_progress()
                        payload = json.dumps({'progress': progress})
                        if payload != last_payload:
                            data = f"data: {payload}\n\n".encode('utf-8')
                            try:
                                self.wfile.write(data)
                                self.wfile.flush()
                            except (BrokenPipeError, ConnectionAbortedError):
                                break
                            last_payload = payload
                        time.sleep(1)
                except Exception as e:
                    print(f'SSE stream error: {e}')
                return
            if path in ('/api/downloads/status', '/downloads/status'):
                try:
                    progress = get_all_download_progress()
                    history = {}
                    try:
                        cfg = load_config()
                        history = load_history() if cfg.get('enable_history', True) else {'downloads': []}
                    except Exception:
                        history = {'downloads': []}
                    send_json_response(self, 200, {'progress': progress, 'history': history.get('downloads', [])})
                except Exception as e:
                    send_json_response(self, 500, {'error': str(e)})
                return
            # API Endpoint: Analyse one YouTube video with yt-dlp.
            if path == '/api/video/inspect':
                query = parse_qs(urlparse(self.path).query)
                video_url = (query.get('url') or [''])[0].strip()
                cookie_id = (query.get('cookie_id') or [''])[0].strip()
                if not video_url:
                    send_json_response(self, 400, {'error': 'Missing url query parameter'})
                    return
                # Normalize URL to canonical form that yt-dlp can reason about
                normalized = normalize_video_url(video_url)
                if not normalized:
                    send_json_response(self, 400, {'error': 'Invalid or unsupported YouTube URL', 'input_url': video_url})
                    return
                video_url = normalized
                # Try YouTube Data API for metadata/comments first (if configured)
                cfg = {}
                try:
                    cfg = load_config()
                except Exception:
                    cfg = {}
                yt_api_key = cfg.get('youtube_api_key') if isinstance(cfg, dict) else None
                api_payload = None
                if yt_api_key:
                    try:
                        api_payload = fetch_youtube_video_metadata(video_url, api_key=yt_api_key, include_comments=True)
                        if api_payload and api_payload.get('error'):
                            # keep the error info but continue to yt-dlp for formats
                            print(f'YouTube API metadata fetch error for {video_url}: {api_payload.get("error")}')
                    except Exception as e:
                        print(f'Error fetching YouTube API metadata: {e}')
                        api_payload = {'error': str(e)}

                # Run extraction in a worker thread that invokes the yt-dlp CLI with a timeout
                result = {}
                def worker():
                    try:
                        print(f'Video inspect started for: {video_url}')
                        # Resolve cookiefile: prefer cookie_id query param, else auto-detect
                        cookiefile = None
                        try:
                            if cookie_id:
                                with TEMP_COOKIES_LOCK:
                                    meta = TEMP_COOKIES.get(cookie_id)
                                    if meta and meta.get('path'):
                                        cookiefile = meta.get('path')
                            # Fallback: try Opera auto-detect
                            if not cookiefile and export_opera_cookies_netscape:
                                try:
                                    cookiefile = export_opera_cookies_netscape()
                                except Exception:
                                    cookiefile = None
                        except Exception:
                            cookiefile = None

                        specialized_data = None
                        try:
                            specialized_data = extract_video_intelligence(video_url, include_comments=False)
                            print(f'Video inspect completed for: {video_url} (backend=pytube)')
                        except Exception as py_err:
                            print(f'Specialized video intelligence failed for {video_url}: {py_err}')
                            specialized_data = None

                        yt_data = {}
                        runner_attempts = []
                        ytdlp_path = shutil.which('yt-dlp')
                        if ytdlp_path:
                            try:
                                runner = run_yt_dlp_json(video_url, timeout=90, force_ipv4_on_error=True, cookiefile=cookiefile)
                                if runner.get('ok'):
                                    yt_data = runner.get('data') or {}
                                    runner_attempts = runner.get('attempts', [])
                                else:
                                    print(f'yt-dlp inspect failed for {video_url}: {runner.get("error")}')
                            finally:
                                if cookiefile:
                                    delete_managed = True
                                    try:
                                        if cookie_id:
                                            with TEMP_COOKIES_LOCK:
                                                if cookie_id in TEMP_COOKIES and TEMP_COOKIES[cookie_id].get('path') == cookiefile:
                                                    delete_managed = False
                                    except Exception:
                                        delete_managed = True
                                    if delete_managed:
                                        try:
                                            os.unlink(cookiefile)
                                        except Exception:
                                            pass
                        else:
                            print('yt-dlp executable not found on PATH; continuing with specialized intelligence if available')

                        if not specialized_data and not yt_data:
                            raise RuntimeError('Unable to inspect video metadata: yt-dlp and pytube extraction both failed')

                        result['yt_dlp'] = yt_data
                        result['attempts'] = runner_attempts
                        result['data'] = specialized_data if isinstance(specialized_data, dict) else yt_data
                        print(f'Video inspect completed for: {video_url} (backend=pytube/yt-dlp)')
                    except Exception as e:
                        result['error'] = str(e)
                        print(f'Video inspection error for {video_url}: {e}')
                th = threading.Thread(target=worker, daemon=True)
                th.start()

                # If client asked for synchronous inspect (debugging), wait; otherwise enqueue as a job
                query_params = parse_qs(urlparse(self.path).query)
                sync = query_params.get('sync', ['false'])[0].lower() == 'true'
                if sync:
                    th.join(100)  # wait up to 100 seconds
                    if th.is_alive():
                        print(f'Video inspect timed out for: {video_url}')
                        send_json_response(self, 504, {'error': 'Inspection timed out', 'message': 'Video inspection exceeded time limit on server'})
                        return
                    if 'error' in result:
                        # Include sanitized yt-dlp attempt logs when available to aid debugging
                        attempts = sanitize_attempts(result.get('attempts', [])) if isinstance(result.get('attempts', []), list) else []
                        # Detect common restriction patterns to give a clearer hint to the client
                        restriction_hint = None
                        err_msg = (result.get('error') or '').lower()
                        if 'video unavailable' in err_msg or 'restricted' in err_msg or any('video unavailable' in (a.get('stderr') or '').lower() or 'restricted' in (a.get('stderr') or '').lower() for a in attempts):
                            restriction_hint = 'Video appears to be restricted (age/region/organization policy). Try providing a browser cookies file or use a different network/proxy.'
                        payload = {
                            'error': 'Unable to inspect video',
                            'message': result.get('error'),
                            'yt_dlp_attempts': attempts
                        }
                        if restriction_hint:
                            payload['restricted'] = True
                            payload['restriction_hint'] = restriction_hint
                        send_json_response(self, 502, payload)
                        return

                    # Merge results: prefer API metadata for snippet/stats/comments and include yt-dlp formats under 'yt_dlp'
                    final_payload = {}
                    if api_payload:
                        final_payload['youtube_api'] = api_payload
                    yt_data = result.get('yt_dlp', {})
                    final_payload.update(result.get('data', {}) if isinstance(result.get('data', {}), dict) else {})
                    if isinstance(api_payload, dict):
                        api_video = api_payload.get('video')
                        if isinstance(api_video, dict):
                            api_snippet = api_video.get('snippet') or {}
                            api_stats = api_video.get('statistics') or {}
                            final_payload.setdefault('video', {
                                'id': api_video.get('id') or get_video_id_from_url(video_url) or '',
                                'url': video_url,
                                'title': api_snippet.get('title') or '',
                                'channel': api_snippet.get('channelTitle') or '',
                                'channel_title': api_snippet.get('channelTitle') or '',
                                'thumbnail': ((api_snippet.get('thumbnails') or {}).get('maxres') or (api_snippet.get('thumbnails') or {}).get('high') or {}).get('url', ''),
                                'description': api_snippet.get('description') or '',
                                'published_at': api_snippet.get('publishedAt') or '',
                                'category': api_snippet.get('categoryId') or '',
                            })
                            final_payload.setdefault('metrics', {
                                'views': int(api_stats.get('viewCount') or 0),
                                'likes': int(api_stats.get('likeCount') or 0),
                                'comments': int(api_stats.get('commentCount') or 0),
                                'subscribers': 0,
                            })
                        final_payload['comments'] = api_payload.get('comments') or []
                    final_payload['yt_dlp'] = yt_data
                    assets = derive_video_download_assets(yt_data)
                    final_payload['formats'] = assets['formats']
                    final_payload['subtitles'] = assets['subtitles']
                    final_payload['automatic_captions'] = assets['automatic_captions']
                    final_payload['chapters'] = assets['chapters']
                    final_payload['download_assets'] = assets
                    final_payload['download_suggestion'] = derive_best_download_info(yt_data)
                    # Attach sanitized attempt logs for debugging
                    final_payload['yt_dlp_attempts'] = sanitize_attempts(result.get('attempts', []))
                    send_json_response(self, 200, final_payload)
                    return
                else:
                    # Enqueue as a lightweight job so client doesn't block/timeout
                    job_id = str(uuid.uuid4())
                    with JOBS_LOCK:
                        JOBS[job_id] = {'status': 'queued', 'created_at': time.time(), 'progress': ['inspect_queued'], 'result': None}
                    # Start a thread that will run the worker and then store the result
                    def job_wrapper():
                        # run the worker synchronously here
                        worker()
                        with JOBS_LOCK:
                            yt_data = result.get('yt_dlp', {})
                            JOBS[job_id]['result'] = {
                                'youtube_api': api_payload,
                                'comments': (api_payload or {}).get('comments', []) if isinstance(api_payload, dict) else [],
                                'yt_dlp': yt_data,
                                'download_suggestion': derive_best_download_info(yt_data if isinstance(yt_data, dict) else {}),
                                'download_assets': derive_video_download_assets(yt_data if isinstance(yt_data, dict) else {}),
                                'yt_dlp_attempts': sanitize_attempts(result.get('attempts', [])),
                                'error': result.get('error')
                            }
                            JOBS[job_id]['status'] = 'done' if not result.get('error') else 'failed'
                            JOBS[job_id]['finished_at'] = time.time()
                    t = threading.Thread(target=job_wrapper, daemon=True)
                    t.start()
                    send_json_response(self, 202, {'status': 'queued', 'job_id': job_id, 'poll': f'/api/video/job/{job_id}/result'})
                    return

            # API Endpoint: Job status/result
            if path.startswith('/api/video/job/'):
                parts = path.split('/')
                # Expected: /api/video/job/{id}/status or /api/video/job/{id}/result
                if len(parts) < 6:
                    send_json_response(self, 400, {'error': 'Invalid job path'})
                    return
                job_id = parts[4]
                action = parts[5]
                with JOBS_LOCK:
                    job = JOBS.get(job_id)
                if not job:
                    send_json_response(self, 404, {'error': 'Job not found'})
                    return
                if action == 'status':
                    send_json_response(self, 200, {'job_id': job_id, 'status': job.get('status'), 'progress': job.get('progress', [])})
                    return
                if action == 'result':
                    if job.get('status') != 'done':
                        send_json_response(self, 202, {'job_id': job_id, 'status': job.get('status')})
                        return
                    # Return result (include sanitized attempts if present)
                    res = job.get('result', {})
                    if 'attempts' in job:
                        res['yt_dlp_attempts'] = sanitize_attempts(job.get('attempts', []))
                    send_json_response(self, 200, res)
                    return

            # API Endpoint: Refresh live public metrics/comments.
            if path == '/api/video/live':
                query = parse_qs(urlparse(self.path).query)
                video_url = (query.get('url') or [''])[0].strip()
                if not video_url:
                    send_json_response(self, 400, {'error': 'Missing url query parameter'})
                    return
                # Normalize URL to canonical form
                normalized = normalize_video_url(video_url)
                if not normalized:
                    send_json_response(self, 400, {'error': 'Invalid or unsupported YouTube URL', 'input_url': video_url})
                    return
                video_url = normalized
                # Try YouTube Data API for metadata/comments first (if configured)
                cfg = {}
                try:
                    cfg = load_config()
                except Exception:
                    cfg = {}
                yt_api_key = cfg.get('youtube_api_key') if isinstance(cfg, dict) else None
                api_payload = None
                if yt_api_key:
                    try:
                        api_payload = fetch_youtube_video_metadata(video_url, api_key=yt_api_key, include_comments=True)
                        if api_payload and api_payload.get('error'):
                            print(f'YouTube API metadata fetch error for {video_url}: {api_payload.get("error")}')
                    except Exception as e:
                        print(f'Error fetching YouTube API metadata: {e}')
                        api_payload = {'error': str(e)}

                # Run extraction in a worker thread that invokes the yt-dlp CLI with a timeout (shorter for live)
                result = {}
                def worker_live():
                    try:
                        print(f'Live inspect started for: {video_url}')

                        specialized_data = None
                        try:
                            specialized_data = extract_video_intelligence(video_url, include_comments=False)
                            print(f'Live inspect completed for: {video_url} (backend=pytube)')
                        except Exception as py_err:
                            print(f'Specialized live intelligence failed for {video_url}: {py_err}')
                            specialized_data = None

                        yt_data = {}
                        runner_attempts = []
                        ytdlp_path = shutil.which('yt-dlp')
                        if ytdlp_path:
                            cookiefile = None
                            try:
                                if export_opera_cookies_netscape:
                                    cookiefile = export_opera_cookies_netscape()
                            except Exception:
                                cookiefile = None
                            try:
                                runner = run_yt_dlp_json(video_url, timeout=50, force_ipv4_on_error=True, cookiefile=cookiefile)
                                if runner.get('ok'):
                                    yt_data = runner.get('data') or {}
                                    runner_attempts = runner.get('attempts', [])
                                else:
                                    print(f'yt-dlp inspect failed for {video_url}: {runner.get("error")}')
                            finally:
                                if cookiefile:
                                    try:
                                        os.unlink(cookiefile)
                                    except Exception:
                                        pass
                        else:
                            print('yt-dlp executable not found on PATH; continuing with specialized intelligence if available')

                        if not specialized_data and not yt_data:
                            raise RuntimeError('Unable to refresh video metadata: yt-dlp and pytube extraction both failed')

                        result['yt_dlp'] = yt_data
                        result['attempts'] = runner_attempts
                        result['data'] = specialized_data if isinstance(specialized_data, dict) else yt_data
                        print(f'Live inspect completed for: {video_url} (backend=pytube/yt-dlp)')
                    except Exception as e:
                        result['error'] = str(e)
                        print(f'Live inspection error for {video_url}: {e}')

                th = threading.Thread(target=worker_live, daemon=True)
                th.start()
                th.join(60)  # shorter timeout for live refresh
                if th.is_alive():
                    print(f'Live inspect timed out for: {video_url}')
                    send_json_response(self, 504, {'error': 'Live refresh timed out', 'message': 'Live refresh exceeded time limit on server'})
                    return
                if 'error' in result:
                    send_json_response(self, 502, {
                        'error': 'Unable to refresh video metrics',
                        'message': result.get('error')
                    })
                    return

                final_payload = {}
                if api_payload:
                    final_payload['youtube_api'] = api_payload
                yt_data = result.get('yt_dlp', {})
                final_payload.update(result.get('data', {}) if isinstance(result.get('data', {}), dict) else {})
                final_payload['yt_dlp'] = yt_data
                assets = derive_video_download_assets(yt_data)
                final_payload['formats'] = assets['formats']
                final_payload['subtitles'] = assets['subtitles']
                final_payload['automatic_captions'] = assets['automatic_captions']
                final_payload['chapters'] = assets['chapters']
                final_payload['download_assets'] = assets
                final_payload['download_suggestion'] = derive_best_download_info(yt_data)
                final_payload['yt_dlp_attempts'] = sanitize_attempts(result.get('attempts', []))
                send_json_response(self, 200, final_payload)
                return

            # API Endpoint: Get dashboard statistics
            if path in ('/api/stats', '/stats'):
                try:
                    data = get_dashboard_data()
                    send_json_response(self, 200, data)
                except Exception as e:
                    print(f'Error in get_dashboard_data: {e}')
                    import traceback
                    traceback.print_exc()
                    send_json_response(self, 500, {
                        'status': 'error',
                        'message': str(e),
                        'history': {'downloads': []},
                        'stats': {
                            'total_videos': 0,
                            'total_storage_bytes': 0,
                            'success_rate': 0.0,
                            'most_common_quality': 'N/A'
                        }
                    })
                return

            # API Endpoint: Get download history
            if path in ('/api/history', '/history'):
                try:
                    data = get_dashboard_data()
                    send_json_response(self, 200, {'downloads': data.get('history', {}).get('downloads', [])})
                except Exception as e:
                    print(f'Error fetching history: {e}')
                    send_json_response(self, 500, {'error': str(e), 'downloads': []})
                return

            if path in ('/api/downloads/files', '/downloads/files'):
                send_json_response(self, 200, {
                    'directory': str(configured_download_directory()),
                    'files': list_download_files(),
                })
                return

            if path == '/downloads' or path.startswith('/downloads/'):
                relative = unquote(path[len('/downloads'):].lstrip('/'))
                download_root = configured_download_directory()
                requested = (download_root / relative).resolve()
                try:
                    requested.relative_to(download_root)
                except ValueError:
                    send_json_response(self, 403, {'error': 'Download path is outside the configured directory'})
                    return
                if requested.is_dir():
                    send_json_response(self, 403, {'error': 'Directory listing is disabled'})
                    return
                if requested.is_file():
                    file_size = requested.stat().st_size
                    self.send_response(200)
                    self.send_header('Content-Type', mimetypes.guess_type(str(requested))[0] or 'application/octet-stream')
                    self.send_header('Content-Length', str(file_size))
                    self.send_header('Content-Disposition', f'attachment; filename="{requested.name.replace(chr(34), "")}"')
                    self.end_headers()
                    with requested.open('rb') as download_stream:
                        while True:
                            chunk = download_stream.read(1024 * 1024)
                            if not chunk:
                                break
                            self.wfile.write(chunk)
                    return
                send_json_response(self, 404, {'error': 'Download file not found'})
                return

            # Proxy endpoint: fetch remote pages through the local server and remove framing restrictions.
            if path == '/proxy':
                if not require_auth(self):
                    return
                query = parse_qs(urlparse(self.path).query)
                target_url = (query.get('url') or [''])[0].strip()
                if not target_url:
                    send_json_response(self, 400, {'error': 'Missing url query parameter'})
                    return
                if target_url.lower() in ('[object object]', 'undefined', 'null'):
                    send_json_response(self, 400, {'error': 'Invalid proxy target'})
                    return
                normalized = normalize_proxy_target(target_url)
                if not normalized:
                    send_json_response(self, 400, {'error': 'Invalid or unsupported URL', 'url': target_url})
                    return
                if fetch_via_proxy(self, normalized):
                    return

            # Serve the standalone dashboard directly from this same local server.
            if path == '/' or path == '/dashboard':
                dashboard_path = resolve_configured_directory(
                    load_config().get('web_directory'),
                    './web',
                ) / 'dashboard.html'
                if dashboard_path.exists():
                    path = '/dashboard.html'
                elif (WORKSPACE_ROOT / 'dashboard_sync.html').exists():
                    path = '/dashboard_sync.html'
                else:
                    path = '/dashboard.html'

            # Resolve relative assets requested by proxied pages (for example YouTube's
            # /s/player/.../base.js) against the remote page that initiated the request.
            # Without this, the local static handler incorrectly looks for them in the workspace.
            referer = self.headers.get('Referer', '')
            referer_query = parse_qs(urlparse(referer).query) if referer else {}
            proxy_source = (referer_query.get('url') or [''])[0]
            if proxy_source and path.startswith('/') and not path.startswith(('/api/', '/proxy')):
                remote_asset = urljoin(proxy_source, self.path)
                if normalize_proxy_target(remote_asset) and fetch_via_proxy(self, remote_asset):
                    return

            # Player assets are often requested by page scripts without the proxy query
            # context. Resolve those known relative paths against the client's last
            # proxied origin before attempting local static-file serving.
            if path.startswith(('/s/player/', '/www-player.css')):
                proxy_context = proxy_context_for(self)
                if proxy_context:
                    remote_asset = urljoin(proxy_context, self.path)
                    if normalize_proxy_target(remote_asset) and fetch_via_proxy(self, remote_asset):
                        return

            if path.startswith('/api/'):
                send_json_response(self, 404, {'error': 'API endpoint not found', 'path': path})
                return

            # Serve static files
            if serve_static_file(self, path):
                return

            # File not found
            send_json_response(self, 404, {'error': 'Not found'})
        except Exception as e:
            if is_client_disconnect(e):
                return
            print(f'Unexpected error in do_GET: {e}')
            import traceback
            traceback.print_exc()
            send_json_response(self, 500, {'error': 'Internal server error'})

    def do_POST(self):
        """Handle POST requests for download API and cookie operations."""
        path = urlparse(self.path).path
        
        try:
            bot_module = __import__('Bot')
            if getattr(bot_module, 'LOCKOFF_MODE', False):
                send_json_response(self, 403, {
                    'error': 'System lock-off active',
                    'lockoff_mode': True,
                    'complete_lockoff': getattr(bot_module, 'COMPLETE_LOCKOFF_MODE', False),
                    'state_reestablished': getattr(bot_module, 'LOCKOFF_STATE_REESTABLISHED', False),
                    'message': getattr(bot_module, 'LOCKOFF_REASON', '') or LOCKOFF_MESSAGE,
                })
                return
            record_connected_device(self)
            if path == '/api/auth/login':
                content_length = int(self.headers.get('Content-Length', 0))
                payload = json.loads(self.rfile.read(content_length).decode('utf-8')) if content_length else {}
                authenticate(self, str(payload.get('username', '')), str(payload.get('password', '')))
                return
            if path == '/api/auth/logout':
                record_activity(self, 'sign_out')
                sign_out(self)
                return
            if path == '/api/preferences':
                if not require_auth(self):
                    return
                content_length = int(self.headers.get('Content-Length', 0))
                payload = json.loads(self.rfile.read(content_length).decode('utf-8')) if content_length else {}
                try:
                    preferences = save_dashboard_preferences(self, payload)
                    record_activity(self, 'preferences_updated', json.dumps(preferences, sort_keys=True))
                    send_json_response(self, 200, {'preferences': preferences})
                except (TypeError, ValueError, json.JSONDecodeError) as exc:
                    send_json_response(self, 400, {'error': str(exc)})
                return
            if path == '/api/spotify/download':
                if not require_auth(self, 'download'):
                    return
                content_length = int(self.headers.get('Content-Length', 0))
                payload = json.loads(self.rfile.read(content_length).decode('utf-8')) if content_length else {}
                spotify_url = str(payload.get('url', '')).strip()
                if not re.match(r'^https?://open\.spotify\.com/(track|album|playlist|artist)/', spotify_url, re.IGNORECASE):
                    send_json_response(self, 400, {'error': 'Enter a Spotify track, album, playlist, or artist URL'})
                    return
                job_id = secrets.token_urlsafe(12)
                with SPOTIFY_JOBS_LOCK:
                    SPOTIFY_JOBS[job_id] = {
                        'id': job_id, 'url': spotify_url, 'status': 'queued',
                        'created_at': time.time(), 'files': [], 'metadata_source': 'spotdl',
                    }
                record_activity(self, 'spotify_download_queued', spotify_url)
                threading.Thread(target=run_spotify_job, args=(job_id, spotify_url), daemon=True).start()
                send_json_response(self, 202, {'job': spotify_job_snapshot(job_id)})
                return
            if path == '/api/auth/create':
                content_length = int(self.headers.get('Content-Length', 0))
                payload = json.loads(self.rfile.read(content_length).decode('utf-8')) if content_length else {}
                created, result = create_account(self, payload)
                if not created:
                    send_json_response(self, 400, {'error': result})
                    return
                send_json_response(self, 201, {
                    'created': True,
                    'username': result,
                    'permissions': ['view'],
                })
                return
            if path == '/api/auth/guest':
                authenticate_guest(self)
                return
            if path == '/api/root/devices/permission':
                content_length = int(self.headers.get('Content-Length', 0))
                payload = json.loads(self.rfile.read(content_length).decode('utf-8')) if content_length else {}
                update_device_permission(self, payload)
                return
            if path == '/api/root/accounts/permissions':
                content_length = int(self.headers.get('Content-Length', 0))
                payload = json.loads(self.rfile.read(content_length).decode('utf-8')) if content_length else {}
                update_account_permissions(self, payload)
                return
            if path == '/api/auth/root-password':
                content_length = int(self.headers.get('Content-Length', 0))
                payload = json.loads(self.rfile.read(content_length).decode('utf-8')) if content_length else {}
                change_root_password(self, payload)
                return
            if path == '/api/root-terminal':
                content_length = int(self.headers.get('Content-Length', 0))
                payload = json.loads(self.rfile.read(content_length).decode('utf-8')) if content_length else {}
                run_root_terminal_command(self, payload)
                return
            permission = 'download' if path in ('/api/download', '/download') else None
            if (path.startswith('/api/') or path == '/download') and not require_auth(self, permission):
                return
            # Download requests
            if path in ('/api/download', '/download'):
                # Read request body
                content_length = int(self.headers.get('Content-Length', 0))
                if content_length == 0:
                    send_json_response(self, 400, {'error': 'Empty request body'})
                    return

                body = self.rfile.read(content_length)

                # Parse JSON payload
                try:
                    payload = json.loads(body.decode('utf-8'))
                except json.JSONDecodeError:
                    send_json_response(self, 400, {'error': 'Invalid JSON payload'})
                    return

                # Validate URL
                url = normalize_download_target(payload.get('url', ''))
                if not url:
                    send_json_response(self, 400, {
                        'error': 'Enter a valid http:// or https:// video, playlist, or Spotify URL',
                    })
                    return
                record_device_download(self)
                record_activity(self, 'download_queued', url)

                # Build download options from payload
                options = build_download_options(payload)
                options['progress_id'] = secrets.token_urlsafe(12)
                set_download_progress(options['progress_id'], {
                    'status': 'queued',
                    'stage': 'queued',
                    'title': url,
                    'url': url,
                })

                # Process download in background thread
                thread = threading.Thread(
                    target=process_download_request,
                    args=(url, options),
                    daemon=True
                )
                thread.start()

                # Return success response
                send_json_response(self, 202, {
                    'status': 'queued',
                    'message': 'Download request accepted and queued for processing.',
                })
                return

            if path in ('/api/download/cleanup', '/download/cleanup'):
                content_length = int(self.headers.get('Content-Length', 0))
                payload = json.loads(self.rfile.read(content_length).decode('utf-8')) if content_length else {}
                days = max(1, int(payload.get('days') or load_config().get('auto_cleanup_days') or 30))
                config = load_config()
                output_dir = resolve_configured_directory(
                    config.get('output_directory'),
                    './downloads/Single Videos',
                )
                cutoff = time.time() - days * 86400
                removed = 0
                freed = 0
                if output_dir.exists():
                    for item in output_dir.rglob('*'):
                        if item.is_file() and item.stat().st_mtime < cutoff:
                            size = item.stat().st_size
                            item.unlink()
                            removed += 1
                            freed += size
                send_json_response(self, 200, {'removed_files': removed, 'freed_bytes': freed, 'days': days})
                record_activity(self, 'downloads_cleaned', f'{removed} files, {freed} bytes')
                return

            if path in ('/api/download/delete', '/download/delete'):
                content_length = int(self.headers.get('Content-Length', 0))
                if content_length == 0:
                    send_json_response(self, 400, {'error': 'Empty request body'})
                    return
                try:
                    payload = json.loads(self.rfile.read(content_length).decode('utf-8'))
                    video_id = str(payload.get('video_id') or '').strip()
                    url = str(payload.get('url') or '').strip()
                    if not video_id and not url:
                        send_json_response(self, 400, {'error': 'Missing video_id or url'})
                        return
                    send_json_response(self, 200, delete_download_record(video_id, url))
                    record_activity(self, 'download_deleted', video_id or url)
                except FileNotFoundError as exc:
                    send_json_response(self, 404, {'error': str(exc)})
                except (ValueError, json.JSONDecodeError) as exc:
                    send_json_response(self, 400, {'error': str(exc)})
                return

            if path == '/api/download/play':
                if not require_auth(self, 'download'):
                    return
                content_length = int(self.headers.get('Content-Length', 0))
                payload = json.loads(self.rfile.read(content_length).decode('utf-8')) if content_length else {}
                try:
                    send_json_response(self, 200, launch_media_player(str(payload.get('file_path') or '')))
                    record_activity(self, 'media_played', str(payload.get('file_path') or ''))
                except FileNotFoundError as exc:
                    send_json_response(self, 404, {'error': str(exc)})
                except OSError as exc:
                    send_json_response(self, 409, {'error': str(exc)})
                return

            # API Endpoint: Pause a running or queued download
            if path in ('/api/download/pause', '/download/pause'):
                try:
                    content_length = int(self.headers.get('Content-Length', 0))
                    if content_length == 0:
                        send_json_response(self, 400, {'error': 'Empty request body'})
                        return
                    body = self.rfile.read(content_length)
                    payload = json.loads(body.decode('utf-8'))
                    vids = []
                    if isinstance(payload.get('video_id'), str):
                        vids = [payload.get('video_id')]
                    elif isinstance(payload.get('video_ids'), list):
                        vids = payload.get('video_ids')
                    else:
                        send_json_response(self, 400, {'error': 'Missing video_id or video_ids'})
                        return
                    updated = []
                    for vid in vids:
                        set_download_progress(vid, {'requested_action': 'pause'})
                        updated.append(vid)
                    record_activity(self, 'download_paused', ','.join(updated))
                    send_json_response(self, 200, {'paused': updated})
                except Exception as e:
                    send_json_response(self, 500, {'error': str(e)})
                return

            # API Endpoint: Resume a paused download
            if path in ('/api/download/resume', '/download/resume'):
                try:
                    content_length = int(self.headers.get('Content-Length', 0))
                    if content_length == 0:
                        send_json_response(self, 400, {'error': 'Empty request body'})
                        return
                    body = self.rfile.read(content_length)
                    payload = json.loads(body.decode('utf-8'))
                    vids = []
                    if isinstance(payload.get('video_id'), str):
                        vids = [payload.get('video_id')]
                    elif isinstance(payload.get('video_ids'), list):
                        vids = payload.get('video_ids')
                    else:
                        send_json_response(self, 400, {'error': 'Missing video_id or video_ids'})
                        return
                    updated = []
                    for vid in vids:
                        # Clear requested action and mark downloading; progress_hook will resume if paused
                        set_download_progress(vid, {'requested_action': None, 'status': 'downloading', 'stage': 'downloading'})
                        updated.append(vid)
                    record_activity(self, 'download_resumed', ','.join(updated))
                    send_json_response(self, 200, {'resumed': updated})
                except Exception as e:
                    send_json_response(self, 500, {'error': str(e)})
                return

            # API Endpoint: Cancel a running or queued download
            if path in ('/api/download/cancel', '/download/cancel'):
                try:
                    content_length = int(self.headers.get('Content-Length', 0))
                    if content_length == 0:
                        send_json_response(self, 400, {'error': 'Empty request body'})
                        return
                    body = self.rfile.read(content_length)
                    payload = json.loads(body.decode('utf-8'))
                    vids = []
                    if isinstance(payload.get('video_id'), str):
                        vids = [payload.get('video_id')]
                    elif isinstance(payload.get('video_ids'), list):
                        vids = payload.get('video_ids')
                    else:
                        send_json_response(self, 400, {'error': 'Missing video_id or video_ids'})
                        return
                    updated = []
                    for vid in vids:
                        # Preserve the visible job metadata while asking the worker to stop.
                        current = get_all_download_progress().get(str(vid), {})
                        state = dict(current) if isinstance(current, dict) else {}
                        state['requested_action'] = 'cancel'
                        set_download_progress(vid, state)
                        updated.append(vid)
                    record_activity(self, 'download_cancel_requested', ','.join(updated))
                    send_json_response(self, 200, {'cancel_requested': updated})
                except Exception as e:
                    send_json_response(self, 500, {'error': str(e)})
                return

            # Cookie upload endpoint (accept base64 JSON payload)
            if path == '/api/cookies/upload':
                content_length = int(self.headers.get('Content-Length', 0))
                if content_length == 0:
                    send_json_response(self, 400, {'error': 'Empty request body'})
                    return
                body = self.rfile.read(content_length)
                try:
                    payload = json.loads(body.decode('utf-8'))
                except Exception:
                    send_json_response(self, 400, {'error': 'Invalid JSON payload'})
                    return
                b64 = payload.get('content_base64')
                filename = payload.get('filename') or 'cookies.txt'
                if not b64:
                    send_json_response(self, 400, {'error': 'Missing content_base64'})
                    return
                try:
                    data = base64.b64decode(b64)
                except Exception as e:
                    send_json_response(self, 400, {'error': 'Invalid base64 content', 'message': str(e)})
                    return
                try:
                    tmp = tempfile.NamedTemporaryFile(delete=False, suffix='.cookies.txt')
                    tmp.close()
                    with open(tmp.name, 'wb') as f:
                        f.write(data)
                    # Extract domains for metadata
                    domains = []
                    try:
                        with open(tmp.name, 'r', encoding='utf-8', errors='ignore') as rf:
                            for ln in rf:
                                ln = ln.strip()
                                if not ln or ln.startswith('#'):
                                    continue
                                parts = ln.split('\t')
                                if parts:
                                    domains.append(parts[0])
                    except Exception:
                        domains = []
                    cid = str(uuid.uuid4())
                    with TEMP_COOKIES_LOCK:
                        TEMP_COOKIES[cid] = {'path': tmp.name, 'created_at': time.time(), 'source': 'upload', 'domains': domains}
                    send_json_response(self, 201, {'cookie_id': cid, 'expires_in': COOKIE_TTL})
                    return
                except Exception as e:
                    send_json_response(self, 500, {'error': 'Failed to save uploaded cookie file', 'message': str(e)})
                    return

            # Use browser cookies (auto-extract) - currently supports Opera via helper
            if path == '/api/cookies/use-browser':
                content_length = int(self.headers.get('Content-Length', 0))
                if content_length == 0:
                    send_json_response(self, 400, {'error': 'Empty request body'})
                    return
                body = self.rfile.read(content_length)
                try:
                    payload = json.loads(body.decode('utf-8'))
                except Exception:
                    send_json_response(self, 400, {'error': 'Invalid JSON payload'})
                    return
                browser = (payload.get('browser') or 'auto').lower()
                # For now, only Opera auto-detect is implemented
                if browser in ('opera', 'auto') and export_opera_cookies_netscape:
                    try:
                        cf = export_opera_cookies_netscape()
                        if not cf:
                            send_json_response(self, 502, {'error': 'No cookies found or extraction failed'})
                            return
                        # Read domains
                        domains = []
                        try:
                            with open(cf, 'r', encoding='utf-8', errors='ignore') as rf:
                                for ln in rf:
                                    ln = ln.strip()
                                    if not ln or ln.startswith('#'):
                                        continue
                                    parts = ln.split('\t')
                                    if parts:
                                        domains.append(parts[0])
                        except Exception:
                            domains = []
                        cid = str(uuid.uuid4())
                        with TEMP_COOKIES_LOCK:
                            TEMP_COOKIES[cid] = {'path': cf, 'created_at': time.time(), 'source': 'opera_auto', 'domains': domains}
                        send_json_response(self, 201, {'cookie_id': cid, 'expires_in': COOKIE_TTL})
                        return
                    except Exception as e:
                        send_json_response(self, 500, {'error': 'Extraction failed', 'message': str(e)})
                        return
                else:
                    send_json_response(self, 400, {'error': 'Unsupported browser for auto-extraction'})
                    return

            # Enqueue an analysis job
            if path == '/api/video/analyze':
                content_length = int(self.headers.get('Content-Length', 0))
                if content_length == 0:
                    send_json_response(self, 400, {'error': 'Empty request body'})
                    return
                body = self.rfile.read(content_length)
                try:
                    payload = json.loads(body.decode('utf-8'))
                except Exception:
                    send_json_response(self, 400, {'error': 'Invalid JSON payload'})
                    return
                url = payload.get('url', '').strip()
                if not url:
                    send_json_response(self, 400, {'error': 'Missing url'})
                    return
                # Create job
                job_id = str(uuid.uuid4())
                with JOBS_LOCK:
                    JOBS[job_id] = {'status': 'queued', 'created_at': time.time(), 'progress': []}
                # Start worker thread
                t = threading.Thread(target=analyze_job_worker, args=(job_id, url, payload), daemon=True)
                t.start()
                send_json_response(self, 202, {'status': 'queued', 'job_id': job_id})
                return
                content_length = int(self.headers.get('Content-Length', 0))
                if content_length == 0:
                    send_json_response(self, 400, {'error': 'Empty request body'})
                    return
                body = self.rfile.read(content_length)
                try:
                    payload = json.loads(body.decode('utf-8'))
                except Exception:
                    send_json_response(self, 400, {'error': 'Invalid JSON payload'})
                    return
                url = payload.get('url', '').strip()
                if not url:
                    send_json_response(self, 400, {'error': 'Missing url'})
                    return
                # Create job
                job_id = str(uuid.uuid4())
                with JOBS_LOCK:
                    JOBS[job_id] = {'status': 'queued', 'created_at': time.time(), 'progress': []}
                # Start worker thread
                t = threading.Thread(target=analyze_job_worker, args=(job_id, url, payload), daemon=True)
                t.start()
                send_json_response(self, 202, {'status': 'queued', 'job_id': job_id})
                return

            # Unknown POST path
            send_json_response(self, 404, {'error': 'Not found'})
            return

        except Exception as e:
            if is_client_disconnect(e):
                return
            print(f'Error in do_POST: {e}')
            import traceback
            traceback.print_exc()
            send_json_response(self, 500, {'error': 'Internal server error'})

    def do_DELETE(self):
        path = unquote(urlparse(self.path).path)
        try:
            # Expect: /api/cookies/{cookie_id}
            if path.startswith('/api/cookies/'):
                parts = path.split('/')
                if len(parts) >= 3:
                    cid = parts[2]
                    with TEMP_COOKIES_LOCK:
                        meta = TEMP_COOKIES.pop(cid, None)
                    if meta and meta.get('path'):
                        try:
                            os.unlink(meta.get('path'))
                        except Exception:
                            pass
                    send_json_response(self, 200, {'deleted': cid})
                    return
            send_json_response(self, 404, {'error': 'Not found'})
        except Exception as e:
            print(f'Error in do_DELETE: {e}')
            send_json_response(self, 500, {'error': 'Internal server error'})
            return

    def log_message(self, format: str, *args) -> None:
        """Suppress default logging (we use print statements)."""
        return


def create_http_server(host: str = HOST, port: int = PORT, nginx_socket_path: Optional[str] = None):
    """Create a server bound to either a TCP port or a Unix socket for NGINX proxying."""
    if nginx_socket_path and hasattr(socket, 'AF_UNIX'):
        unix_socket = str(nginx_socket_path)
        return UnixThreadingHTTPServer(unix_socket, BotApiHandler)

    return LanThreadingHTTPServer((host, port), BotApiHandler)


def resolve_nginx_binary() -> Optional[str]:
    """Locate an nginx executable or return None when unavailable."""
    env_path = os.environ.get('NGINX_BIN') or os.environ.get('VIDEO_RETRIEVER_NGINX_BIN')
    if env_path:
        if os.path.exists(env_path):
            return env_path
        resolved = shutil.which(env_path)
        if resolved:
            return resolved

    candidates = []
    executable = shutil.which('nginx')
    if executable:
        candidates.append(executable)

    if os.name == 'nt':
        candidates.extend([
            os.path.join(WORKSPACE_ROOT, 'nginx', 'nginx.exe'),
            os.path.join(WORKSPACE_ROOT, 'nginx-1.31.5', 'nginx-1.31.5', 'nginx.exe'),
            os.path.join(os.environ.get('ProgramFiles', 'C:/Program Files'), 'nginx', 'nginx.exe'),
            os.path.join(os.environ.get('ProgramFiles(x86)', 'C:/Program Files (x86)'), 'nginx', 'nginx.exe'),
            os.path.join(os.path.expanduser('~'), 'Downloads', 'nginx-1.31.5', 'nginx-1.31.5', 'nginx.exe'),
        ])

    for candidate in candidates:
        if candidate and os.path.exists(candidate):
            return candidate
    return None


def resolve_nginx_config_path(config_path: Optional[str] = None) -> Optional[str]:
    """Locate the nginx config file for this project."""
    if config_path:
        if os.path.exists(config_path):
            return os.path.abspath(config_path)
    project_root = Path(WORKSPACE_ROOT)
    defaults = [
        project_root / 'config' / 'nginx-video-retriever.conf',
        project_root / 'nginx-video-retriever.conf',
        project_root / 'nginx' / 'nginx.conf',
        project_root.parent / 'nginx-video-retriever.conf',
    ]
    for candidate in defaults:
        if candidate.exists():
            return str(candidate)
    return None


def print_nginx_install_prompt() -> None:
    """Print safe, copy-paste installation commands for the current platform."""
    print('NGINX is not installed or could not be located.')
    if os.name == 'nt':
        print('Install with Windows Package Manager (PowerShell):')
        print('  winget install --id=NGINX.NGINX -e')
        print('Or with Chocolatey (PowerShell as Administrator):')
        print('  choco install nginx -y')
        print('Then restart server.py, or set NGINX_BIN to the full nginx.exe path.')
    else:
        print('Install with your distribution package manager:')
        print('  sudo apt-get update && sudo apt-get install -y nginx')
        print('  # Fedora/RHEL: sudo dnf install -y nginx')
        print('  # Arch: sudo pacman -S --needed nginx')
        print('Then restart server.py.')


def ensure_nginx_runtime_dirs(config_path: str) -> None:
    """Create the minimal directories nginx expects when started from this project."""
    config_dir = Path(config_path).resolve().parent
    logs_dir = config_dir / 'logs'
    temp_dir = config_dir / 'temp'
    logs_dir.mkdir(exist_ok=True, parents=True)
    temp_dir.mkdir(exist_ok=True, parents=True)
    for sub in ['client_body_temp', 'proxy_temp', 'fastcgi_temp', 'uwsgi_temp', 'scgi_temp']:
        (temp_dir / sub).mkdir(exist_ok=True, parents=True)


def launch_nginx(config_path: Optional[str] = None, binary_path: Optional[str] = None, daemonize: bool = True) -> Optional[subprocess.Popen]:
    """Launch nginx in the background if the binary and config are available."""
    try:
        with socket.create_connection((detect_private_ip(), 80), timeout=0.5):
            print('NGINX already appears to be listening on port 80; skipping duplicate launch.')
            return None
    except OSError:
        pass
    resolved_bin = binary_path or resolve_nginx_binary()
    resolved_conf = resolve_nginx_config_path(config_path)
    if not resolved_bin:
        print_nginx_install_prompt()
        print('Skipping automatic NGINX launch.')
        return None
    if not resolved_conf:
        print('NGINX config not found; skipping automatic launch.')
        return None

    ensure_nginx_runtime_dirs(resolved_conf)
    cmd = [resolved_bin, '-c', resolved_conf]
    if daemonize and os.name == 'nt':
        try:
            proc = subprocess.Popen(cmd, cwd=str(Path(resolved_conf).resolve().parent), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0x08000000), close_fds=True)
            print(f'NGINX launched: {resolved_bin} -c {resolved_conf}')
            return proc
        except Exception as exc:
            print(f'Failed to launch nginx: {exc}')
            return None

    try:
        proc = subprocess.Popen(cmd, cwd=str(Path(resolved_conf).resolve().parent), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, close_fds=True)
        print(f'NGINX launched: {resolved_bin} -c {resolved_conf}')
        return proc
    except Exception as exc:
        print(f'Failed to launch nginx: {exc}')
        return None


def parse_server_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description='Run Multimedia Handler behind NGINX or directly on a TCP port.')
    parser.add_argument('--host', default=HOST, help='Host/interface for direct HTTP hosting. Defaults to the detected private IP if available (default: %(default)s)')
    parser.add_argument('--port', type=int, default=PORT, help='TCP port for direct HTTP hosting (default: %(default)s)')
    parser.add_argument('--ports', default=None, help='Comma-separated TCP ports to try when the requested port is busy.')
    parser.add_argument('--nginx-socket', default=NGINX_SOCKET_PATH, help='Optional Unix socket path for NGINX to proxy to (e.g. /run/video_retriever.sock)')
    parser.add_argument('--nginx-bin', default=None, help='Optional explicit path to the nginx binary.')
    parser.add_argument('--nginx-config', default=None, help='Optional explicit path to the nginx configuration file.')
    parser.add_argument('--start-nginx', action='store_true', help='Launch nginx using the detected config before starting the Python server.')
    parser.add_argument('--no-nginx', action='store_true', help='Skip starting nginx even if the binary and config are available.')
    return parser.parse_args()


def run_server(host: str = HOST, port: int = PORT, nginx_socket_path: Optional[str] = None, ports: Optional[tuple[int, ...]] = None) -> None:
    """Run the HTTP server. When an NGINX socket is provided, bind to it instead of a TCP port."""
    if host in ('0.0.0.0', '::', 'localhost', '127.0.0.1', '::1'):
        host = detect_private_ip()
    if nginx_socket_path and hasattr(socket, 'AF_UNIX'):
        httpd = create_http_server(host=host, port=port, nginx_socket_path=nginx_socket_path)
        print(f'Multimedia Handler API server listening on Unix socket: {nginx_socket_path}')
        print(f'Dashboard available via NGINX at /dashboard')
        print(f'Detected host fallback: {host}')
        print('Press Ctrl+C to stop the server')
    else:
        candidate_ports = tuple(dict.fromkeys(ports or (port, *PORTS)))
        bind_error = None
        for candidate_port in candidate_ports:
            try:
                httpd = LanThreadingHTTPServer((host, candidate_port), BotApiHandler)
                port = candidate_port
                break
            except OSError as exc:
                bind_error = exc
                if getattr(exc, 'winerror', None) not in (10013, 10048) and getattr(exc, 'errno', None) not in (13, 98):
                    raise
        else:
            raise RuntimeError(
                f'Unable to bind API server to {host}. Tried ports: '
                f'{", ".join(str(value) for value in candidate_ports)}.'
            ) from bind_error
        print(f'Multimedia Handler API server listening on http://{host}:{port}')
        print(f'Detected private IP for local access: {host}')
        try:
            print(f'Workspace root: {WORKSPACE_ROOT}')
        except Exception:
            pass
        advertised_host = detect_private_ip() if host in ('0.0.0.0', '::') else host
        print(f'Dashboard available at http://{advertised_host}:{port}/dashboard')
        print('Press Ctrl+C to stop the server')
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print('\nServer stopped.')
    finally:
        httpd.server_close()


if __name__ == '__main__':
    args = parse_server_args()
    if not args.no_nginx:
        auto_config = resolve_nginx_config_path(args.nginx_config)
        if auto_config and not resolve_nginx_binary():
            print_nginx_install_prompt()
        if args.start_nginx or (auto_config and resolve_nginx_binary()):
            launch_nginx(config_path=auto_config, binary_path=args.nginx_bin)
    requested_ports = tuple(
        int(value.strip()) for value in args.ports.split(',') if value.strip()
    ) if args.ports else None
    run_server(host=args.host, port=args.port, nginx_socket_path=args.nginx_socket, ports=requested_ports)
