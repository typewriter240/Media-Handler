param([string]$Destination = '')
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if (-not $Destination) { $Destination = Join-Path $Root ('backups\video-retriever-' + (Get-Date -Format 'yyyyMMdd-HHmmss')) }
New-Item -ItemType Directory -Path $Destination -Force | Out-Null
foreach ($relative in @('config\config.json','config\nginx-video-retriever.conf','data','read.md')) {
    $source = Join-Path $Root $relative
    if (Test-Path -LiteralPath $source) {
        $target = Join-Path $Destination $relative
        if ((Get-Item -LiteralPath $source).PSIsContainer) { Copy-Item -LiteralPath $source -Destination $target -Recurse -Force }
        else { New-Item -ItemType Directory -Path (Split-Path $target) -Force | Out-Null; Copy-Item -LiteralPath $source -Destination $target -Force }
    }
}
Write-Host "Backup created at $Destination"
