$ErrorActionPreference = 'Continue'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
foreach ($name in @('python-server','nginx')) {
    $pidFile = Join-Path $Root "data\state\$name.pid"
    if (Test-Path -LiteralPath $pidFile) {
        $processId = [int](Get-Content -LiteralPath $pidFile -Raw)
        $process = Get-Process -Id $processId -ErrorAction SilentlyContinue
        if ($process) { Stop-Process -Id $processId }
        Remove-Item -LiteralPath $pidFile -Force
    }
}
Write-Host "Managed services stopped."
