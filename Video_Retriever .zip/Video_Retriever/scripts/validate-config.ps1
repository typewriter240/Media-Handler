$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$configPath = Join-Path $Root 'config\config.json'
$settings = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
if (-not $settings.spotify_client_id -or -not $settings.spotify_client_secret) { Write-Warning "Spotify API credentials are not configured." }
if (-not $settings.youtube_api_key) { Write-Warning "YouTube API key is not configured." }
foreach ($property in $settings.PSObject.Properties) {
    if ($property.Name -like '*_directory') {
        $value = [Environment]::ExpandEnvironmentVariables([string]$property.Value)
        if (-not [IO.Path]::IsPathRooted($value)) { $value = Join-Path $Root $value }
        if (-not (Test-Path -LiteralPath $value -PathType Container)) { Write-Warning "Missing directory: $value" }
    }
}
Write-Host "Configuration JSON is valid: $configPath"
