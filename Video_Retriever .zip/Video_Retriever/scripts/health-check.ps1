$ErrorActionPreference = 'Continue'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Write-Host "Video Retriever health check"
foreach ($command in @('python','yt-dlp','ffmpeg','spotdl','nginx')) {
    $found = Get-Command $command -ErrorAction SilentlyContinue
    Write-Host ("{0}: {1}" -f $command, $(if ($found) { $found.Source } else { 'NOT FOUND' }))
}
if (-not (Get-Command nginx -ErrorAction SilentlyContinue)) {
    Write-Host "Nginx install prompt:"
    Write-Host "  winget install --id=NGINX.NGINX -e"
    Write-Host "  choco install nginx -y"
}
if (Test-Path (Join-Path $Root 'config\config.json')) { & (Join-Path $PSScriptRoot 'validate-config.ps1') }
try {
    $response = Invoke-WebRequest -Uri 'http://127.0.0.1:5000/api/health' -UseBasicParsing -TimeoutSec 5
    Write-Host "Python API: $($response.StatusCode)"
} catch { Write-Warning "Python API is not responding on port 5000." }
