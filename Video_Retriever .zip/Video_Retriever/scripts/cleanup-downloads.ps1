param([int]$Days = 30, [switch]$WhatIf)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$settings = Get-Content (Join-Path $Root 'config\config.json') -Raw | ConvertFrom-Json
$path = [Environment]::ExpandEnvironmentVariables([string]$settings.output_directory)
if (-not [IO.Path]::IsPathRooted($path)) { $path = Join-Path $Root $path }
$cutoff = (Get-Date).AddDays(-[math]::Abs($Days))
Get-ChildItem -LiteralPath $path -File -Recurse | Where-Object LastWriteTime -lt $cutoff | ForEach-Object {
    if ($WhatIf) { Write-Host "Would remove $($_.FullName)" } else { Remove-Item -LiteralPath $_.FullName -Force }
}
