param([switch]$Nginx)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$hostIp = (Get-NetIPAddress -AddressFamily IPv4 -PrefixOrigin Dhcp -SuffixOrigin Dhcp |
    Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
    Select-Object -First 1 -ExpandProperty IPAddress)
if (-not $hostIp) {
    throw 'Unable to determine a non-loopback host IP.'
}
$existingBackend = Get-NetTCPConnection -State Listen -LocalPort 5000 -ErrorAction SilentlyContinue
if ($existingBackend) {
    Write-Host "Python API already listening on port 5000 (PID $($existingBackend[0].OwningProcess)); not starting a duplicate."
} else {
    $python = Start-Process python -ArgumentList (Join-Path $Root 'server.py'), '--host', $hostIp, '--port', '5000', '--ports', '5000' -WorkingDirectory $Root -PassThru
    $python.Id | Set-Content -LiteralPath (Join-Path $Root 'data\state\python-server.pid')
}
if ($Nginx) {
    $nginxCommand = Get-ChildItem -LiteralPath $Root -Filter nginx.exe -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $nginxCommand) {
        $nginxCommand = Get-Command nginx -ErrorAction SilentlyContinue
    }
    if (-not $nginxCommand) {
        Write-Warning "Nginx was not found."
        Write-Host "Install with Windows Package Manager:"
        Write-Host "  winget install --id=NGINX.NGINX -e"
        Write-Host "Or with Chocolatey (Administrator PowerShell):"
        Write-Host "  choco install nginx -y"
        throw "Nginx is required when -Nginx is specified."
    }
    $nginxPath = if ($nginxCommand.PSObject.Properties.Name -contains 'FullName') { $nginxCommand.FullName } else { $nginxCommand.Source }
    $nginxDirectory = Split-Path $nginxPath -Parent
    $nginxConfig = Join-Path $Root 'config\nginx-video-retriever.conf'
    $existingNginx = Get-NetTCPConnection -State Listen -LocalPort 80 -ErrorAction SilentlyContinue
    if ($existingNginx) {
        & $nginxPath -t -c $nginxConfig
        & $nginxPath -s reload -c $nginxConfig
        Write-Host "Nginx reloaded with the current configuration."
    } else {
        $process = Start-Process $nginxPath -ArgumentList '-c', $nginxConfig -WorkingDirectory $nginxDirectory -PassThru
        $process.Id | Set-Content -LiteralPath (Join-Path $Root 'data\state\nginx.pid')
    }
}
for ($attempt = 1; $attempt -le 20; $attempt++) {
    $listener = Get-NetTCPConnection -State Listen -LocalAddress $hostIp -LocalPort 5000 -ErrorAction SilentlyContinue
    if ($listener) {
        Write-Host "Python API listener is ready on $hostIp`:5000."
        $apiReady = $true
        break
    }
    if ($attempt -eq 20) { throw "Python API did not bind to $hostIp`:5000." }
    Start-Sleep -Milliseconds 500
}
if ($Nginx) {
    & $nginxPath -t -c $nginxConfig
    & $nginxPath -s reload -c $nginxConfig
    Write-Host "Nginx reloaded after backend health confirmation."
}
Write-Host "Services ready."
