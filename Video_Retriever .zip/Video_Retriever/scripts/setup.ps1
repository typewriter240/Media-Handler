param([switch]$InstallDependencies)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Config = Join-Path $Root 'config\config.json'
$settings = Get-Content -LiteralPath $Config -Raw | ConvertFrom-Json
$properties = @('downloads_directory','output_directory','spotify_output_directory','download_pages_directory','thumbnails_directory','logs_directory','nginx_temp_directory','sql_directory','web_directory','favicon_directory','config_directory','failed_downloads_directory','history_directory','state_directory','cache_directory','modules_directory','scripts_directory','docs_directory','extensions_directory')
foreach ($name in $properties) {
    $value = [Environment]::ExpandEnvironmentVariables([string]$settings.$name)
    if (-not [IO.Path]::IsPathRooted($value)) { $value = Join-Path $Root $value }
    New-Item -ItemType Directory -Path $value -Force | Out-Null
}
if ($InstallDependencies) {
    & python -m pip install -r (Join-Path $Root 'requirements.txt')
    if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed." }
}
Write-Host "Directories are ready. Use -InstallDependencies to install Python packages."
