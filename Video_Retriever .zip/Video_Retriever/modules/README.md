# Application modules

Place reusable Python packages here when functionality is shared by
`Bot.py`, `server.py`, scripts, or future integrations.

Recommended boundaries:

```text
modules/
  auth/           Sessions, accounts, and permissions
  downloads/      Queue and output helpers
  spotify/        Spotify metadata and fallback handling
  youtube/        YouTube inspection and metadata helpers
  shared/         Typed models and cross-cutting utilities
```

Modules should expose small, testable functions, avoid importing the HTTP
server at module import time, and read paths through the central configuration
helpers. Keep secrets, generated files, and browser-extension source outside
this directory.

